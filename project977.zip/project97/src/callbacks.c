#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "agent.h"
#include"loginagent.h"



void
on_button2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window111;
	GtkWidget *window333;
	window111=lookup_widget(objet,"window111");	
	window333 = create_window333();
	gtk_widget_destroy(window111);
	gtk_widget_show(window333);
}


void
on_button1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
Agent A;
GtkWidget *entry1;
	GtkWidget *entry2;
	GtkWidget *entry3;
	GtkWidget *entry4;
        GtkWidget *entry5;
	GtkWidget *entry6;
	GtkWidget *entry7;
	GtkWidget *window111;
  	//GtkWidget *window9;

	window111=lookup_widget(objet,"window111");	
	entry1=lookup_widget(objet, "entry1");
	entry2=lookup_widget(objet, "entry2");
	entry3=lookup_widget(objet, "entry3");
	entry4=lookup_widget(objet, "entry4");
        entry5=lookup_widget(objet, "entry5");
	entry6=lookup_widget(objet, "entry6");
	entry7=lookup_widget(objet, "entry7");


	strcpy(A.nom,gtk_entry_get_text(GTK_ENTRY(entry1)));
	strcpy(A.prenom,gtk_entry_get_text(GTK_ENTRY(entry2)));
	strcpy(A.cin,gtk_entry_get_text(GTK_ENTRY(entry3)));
	strcpy(A.mail,gtk_entry_get_text(GTK_ENTRY(entry4)));
	strcpy(A.adresse,gtk_entry_get_text(GTK_ENTRY(entry5)));
	strcpy(A.datenaissance,gtk_entry_get_text(GTK_ENTRY(entry6)));
	strcpy(A.sexe,gtk_entry_get_text(GTK_ENTRY(entry7)));
        ajouter_agent(A);
}


void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
Agent A;
GtkWidget *treeview1;
//GtkWidget *window2;

//window2=lookup_widget(objet,"window2");	
		//window1= create_window1();
		//gtk_widget_destroy(window1);
//gtk_widget_show(window2);
treeview1=lookup_widget(objet,"treeview1");
afficher_agent(treeview1);
}


void
on_button5_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window222;
GtkWidget *window555;
		window222=lookup_widget(objet,"window222");	
		window555 = create_window555();
		gtk_widget_destroy(window222);
		gtk_widget_show(window555);
}


void
on_button6_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window222;
	GtkWidget *window444;
	window222=lookup_widget(objet,"window222");	
	window444 = create_window444();
	gtk_widget_destroy(window222);
	gtk_widget_show(window444);
}


void
on_button4_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window111;
	GtkWidget *window222;
	window222=lookup_widget(objet,"window222");	
	window111 = create_window111();
	gtk_widget_destroy(window222);
	gtk_widget_show(window111);
}


void
on_button7_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window222;
	GtkWidget *window333;
	window333=lookup_widget(objet,"window333");	
	window222 = create_window222();
	gtk_widget_destroy(window333);
	gtk_widget_show(window222);
}


void
on_button8_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window888;
	GtkWidget *window333;
	window333=lookup_widget(objet,"window333");	
	window888 = create_window888();
	gtk_widget_destroy(window333);
	gtk_widget_show(window888);
}


void
on_button9_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window222;
	GtkWidget *window444;
	window444=lookup_widget(objet,"window444");	
	window222 = create_window222();
	gtk_widget_destroy(window444);
	gtk_widget_show(window222);
}


void
on_button10_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
//GtkWidget *window4;
  	//GtkWidget *entry8;

	//window4=lookup_widget(objet,"window4");	
	//entry8=lookup_widget(objet, "entry8");
GtkWidget *entry20;
GtkWidget *output17;
Agent A;
char refer[20];
entry20=lookup_widget(objet,"entry8");
output17=lookup_widget(objet,"label26");
strcpy(refer,gtk_entry_get_text(GTK_ENTRY(entry20)));
if(verifier_id(refer)==0)
gtk_label_set_text(GTK_LABEL(output17),"agent inexistante");
else
{
supprimer_agent(refer);
gtk_label_set_text(GTK_LABEL(output17),"agent supprimé");
}
	
}


void
on_button11_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window222;
		GtkWidget *window555;
		window555=lookup_widget(objet,"window555");	
		window222 = create_window222();
		gtk_widget_destroy(window555);
		gtk_widget_show(window222);
}


void
on_button12_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{

		   //window5=lookup_widget(objet,"window5");	
		  // entry9=lookup_widget(objet, "entry9");
		   //label26=lookup_widget(objet, "label13");
                  // window6 = create_window6();
		  // gtk_widget_destroy(window5);
char ID[20];
int test;
Agent A;
GtkWidget *entry1,*entry10,*entry11,*entry12,*entry13,*entry14,*entry15, *entry16;
GtkWidget *window555,*window666;
GtkWidget *output;
window666=create_window666();
entry1=lookup_widget(objet,"entry9");
entry10=lookup_widget(window666,"entry10");
entry11=lookup_widget(window666,"entry11");
entry12=lookup_widget(window666,"entry12");
entry13=lookup_widget(window666,"entry13");
entry14=lookup_widget(window666,"entry14");
entry15=lookup_widget(window666,"entry15");
entry16=lookup_widget(window666,"entry16");

output= lookup_widget(objet,"label24");
strcpy(ID,gtk_entry_get_text(GTK_ENTRY(entry1)));
if (verifier_id(ID)==0)
gtk_label_set_text(GTK_LABEL(output),"agent n'existe pas");
else
{
FILE *f2;
f2=fopen("utilisateur.txt","r"); 
if (f2!=NULL)
{while (fscanf(f2,"%s %s %s %s %s %s %s \n",A.nom,A.prenom,A.cin,A.mail,A.adresse,A.datenaissance,A.sexe)!=EOF)
{if (strcmp(A.cin,ID)==0) 
{ gtk_widget_show(window666);
gtk_entry_set_text(GTK_ENTRY(entry10),A.nom) ;
gtk_entry_set_text(GTK_ENTRY(entry11),A.prenom) ;
gtk_entry_set_text(GTK_ENTRY(entry12),A.cin) ;
gtk_entry_set_text(GTK_ENTRY(entry13),A.mail) ;
gtk_entry_set_text(GTK_ENTRY(entry14),A.adresse) ;
gtk_entry_set_text(GTK_ENTRY(entry15),A.datenaissance) ;
gtk_entry_set_text(GTK_ENTRY(entry16),A.sexe) ;
break ;}}
}
fclose(f2);
}		// gtk_widget_show(window6);
}
	   
		 

void
on_button13_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{ 
//Agent A;
//GtkWidget *entry10,*entry11,*entry12,*entry13,*entry14,*entry15,*entry16;//*entry9;
//GtkWidget *output;
//GtkWidget *window6;
//GtkWidget *window5;
//window5=lookup_widget(objet,"window5");	
//window6 = create_window6();
//gtk_widget_destroy(window5);
//gtk_widget_show(window6);
Agent a;
GtkWidget *entry10,*entry11,*entry12,*entry13,*entry14,*entry15,*entry16;
GtkWidget *output;
entry10=lookup_widget(objet,"entry10");
entry11=lookup_widget(objet,"entry11");
entry12=lookup_widget(objet,"entry12");
entry13=lookup_widget(objet,"entry13");
entry14=lookup_widget(objet,"entry14");
entry15=lookup_widget(objet,"entry15");
entry16=lookup_widget(objet,"entry16");
output=lookup_widget(objet,"label23");
strcpy(a.nom,gtk_entry_get_text(GTK_ENTRY(entry10)));
strcpy(a.prenom,gtk_entry_get_text(GTK_ENTRY(entry11)));
strcpy(a.cin,gtk_entry_get_text(GTK_ENTRY(entry12)));
strcpy(a.mail,gtk_entry_get_text(GTK_ENTRY(entry13)));
strcpy(a.adresse,gtk_entry_get_text(GTK_ENTRY(entry14)));
strcpy(a.datenaissance,gtk_entry_get_text(GTK_ENTRY(entry15)));
strcpy(a.sexe,gtk_entry_get_text(GTK_ENTRY(entry16)));

modifier_agent(a);
gtk_label_set_text(GTK_LABEL(output),"modifié avec succés") ;
}


void
on_button14_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
Login_agent L;
GtkWidget *entry18;
	GtkWidget *entry19;
GtkWidget *window777;
	
	window777=lookup_widget(objet,"window777");	
	entry18=lookup_widget(objet, "entry18");
	entry19=lookup_widget(objet, "entry19");
	


	strcpy(L.login,gtk_entry_get_text(GTK_ENTRY(entry18)));
	strcpy(L.password,gtk_entry_get_text(GTK_ENTRY(entry19)));
	
 ajouter_loginagent(L);
}


void
on_button15_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window777;
		GtkWidget *window333;
		window777=lookup_widget(objet,"window777");	
		window333 = create_window333();
		gtk_widget_destroy(window777);
		gtk_widget_show(window333);
}


void
on_button16_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window333;
		GtkWidget *window888;
		window888=lookup_widget(objet,"window888");	
		window333 = create_window333();
		gtk_widget_destroy(window888);
		gtk_widget_show(window333);
}


void
on_button17_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
char ID1[20];
int test;
Agent A;
GtkWidget *input1;
GtkWidget *window111,*window222;
GtkWidget *output1;
window111=lookup_widget(objet,"window888");
input1=lookup_widget(objet,"entry20");
output1= lookup_widget(objet,"label54");
strcpy(ID1,gtk_entry_get_text(GTK_ENTRY(input1)));
if (verifier_id1(ID1)==0)
gtk_label_set_text(GTK_LABEL(output1),"agent n'existe pas");
else
{window222=create_window777();
gtk_widget_show(window222);
gtk_widget_hide(window111);


}}
	



