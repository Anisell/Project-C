#include<gtk/gtk.h>

typedef struct
{
char login[20];
char password[30];


}Login_agent;
int verifier_id1(char ID1[]);
void ajouter_loginagent(Login_agent L);
