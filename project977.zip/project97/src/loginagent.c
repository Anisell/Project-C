#include<stdio.h>
#include<string.h>
#include"loginagent.h"
#include <gtk/gtk.h>
#include"agent.h"

enum
{
	LOGIN,
	PASSWORD,
	COLUMNS
};

int verifier_id1(char ID1[])
{Agent A;
FILE *f;
int test = 0 ; 
f=fopen("utilisateur.txt","r");
if(f!=NULL) { 
while(fscanf(f,"%s %s %s %s %s %s %s\n",A.nom,A.prenom,A.cin,A.mail,A.adresse,A.datenaissance,A.sexe)!=EOF) 
{ 
if((strcmp(A.cin,ID1)==0))
test=1 ;
 } }
fclose(f);
 
return test;
}


void ajouter_loginagent(Login_agent L)
{
FILE *f;
int role=3;
f=fopen("login_agent.txt","a+");
if (f!=NULL)
{ fprintf(f,"%s %s %d\n",L.login,L.password,role);
fclose(f);
}}
