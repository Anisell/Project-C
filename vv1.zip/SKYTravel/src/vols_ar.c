#include<gtk/gtk.h>
#include<stdio.h>
#include<string.h>
#include"vols_ar.h"


enum 
{
DEPART_ALLER,
ARRIVEE_ALLER,
DATE_ALLER,
HEURE_DEPART_ALLER,
HEURE_ARRIVEE_ALLER,
DEPART_RETOUR,
ARRIVEE_RETOUR,
DATE_RETOUR,
HEURE_DEPART_RETOUR,
HEURE_ARRIVEE_RETOUR,
COMPAGNIE_AERIENNE,
PRIX,
REFERENCE_VOLS,
COLUMNS
};

void ajouter_vol_ar(vole v)
{
FILE *f;
f=fopen("vols_ar.txt","a+");
if (f!=NULL)
{ 
fprintf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",v.depart_aller,v.arrivee_aller,v.date_aller,v.hd_aller,v.ha_aller,v.depart_retour,v.arrivee_retour,v.date_retour,v.hd_retour,v.ha_retour,v.com_aer,v.priix,v.ref_vols);
fclose(f);
}
}


void afficher_vols_ar(GtkWidget *liste)
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char Depart_aller[20];
char Arrivee_aller[20];
char Date_aller[50];
char HD_aller[20];
char HA_aller[20];
char Depart_retour[20];
char Arrivee_retour[20];
char Date_retour[20];
char HD_retour[20];
char HA_retour[20];
char Com_aer[20];
char Priix[20];
char Ref_vols[20];

FILE*f;
store==NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Depart Aller",renderer,"text",DEPART_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Arrivee Aller",renderer,"text",ARRIVEE_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date aller",renderer,"text",DATE_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("H Depart A",renderer,"text",HEURE_DEPART_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("H Arrivee A",renderer,"text",HEURE_ARRIVEE_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Derpat R",renderer,"text",DEPART_RETOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Arrivee R",renderer,"text",ARRIVEE_RETOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date Retour",renderer,"text",DATE_RETOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("H depart R",renderer,"text",HEURE_DEPART_RETOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("H aller R",renderer,"text",HEURE_ARRIVEE_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Compagnie Aerienne",renderer,"text",COMPAGNIE_AERIENNE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Prix",renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Reference",renderer,"text",REFERENCE_VOLS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
}

store=gtk_list_store_new (13, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f = fopen("vols_ar.txt","r");
if (f==NULL)
{ return; }
else 
{f= fopen("vols_ar.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",Depart_aller,Arrivee_aller,Date_aller,HD_aller,HA_aller,Depart_retour,Arrivee_retour,Date_retour,HD_retour,HA_retour,Com_aer,Priix,Ref_vols)!=EOF)
{ 
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,DEPART_ALLER,Depart_aller,ARRIVEE_ALLER,Arrivee_aller,DATE_ALLER,Date_aller,HEURE_DEPART_ALLER,HD_aller,HEURE_ARRIVEE_ALLER,HA_aller,DEPART_RETOUR,Depart_retour,
ARRIVEE_RETOUR,Arrivee_retour,DATE_RETOUR,Date_retour,HEURE_DEPART_RETOUR,HD_retour,HEURE_ARRIVEE_RETOUR,HA_retour,COMPAGNIE_AERIENNE,Com_aer,PRIX,Priix, REFERENCE_VOLS,Ref_vols,-1);}
fclose(f);}
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}


int verifier_reference(char refer[])

{vole b;
FILE *f;
int test = 0 ; 
f=fopen("vols_ar.txt","r");
if(f!=NULL) { 
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",b.depart_aller,b.arrivee_aller,b.date_aller,b.hd_aller,b.ha_aller,b.depart_retour,b.arrivee_retour,b.date_retour,b.hd_retour,b.ha_retour,b.com_aer,b.priix,b.ref_vols)!=EOF) 
{ 
if((strcmp(b.ref_vols,refer)==0))
test=1 ;
 } }
fclose(f);
 
return test;
}

void modifier_vol_ar(vole p)
{
vole c;
FILE *f;
FILE *f2;
f=fopen("vols_ar.txt","r");
f2=fopen("vol_artmp.txt","a+"); 
if (f!=NULL)
{
if (f2!=NULL)

{ 
     while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",c.depart_aller,c.arrivee_aller,c.date_aller,c.hd_aller,c.ha_aller,c.depart_retour,c.arrivee_retour,c.date_retour,c.hd_retour,c.ha_retour,c.com_aer,c.priix,c.ref_vols)!=EOF)
    { 
	if (strcmp(c.ref_vols,p.ref_vols)==0)
{    fprintf(f2,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",p.depart_aller,p.arrivee_aller,p.date_aller,p.hd_aller,p.ha_aller,p.depart_retour,p.arrivee_retour,p.date_retour,p.hd_retour,p.ha_retour,p.com_aer,p.priix,p.ref_vols);
}
	else 	
{	    fprintf(f2,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",c.depart_aller,c.arrivee_aller,c.date_aller,c.hd_aller,c.ha_aller,c.depart_retour,c.arrivee_retour,c.date_retour,c.hd_retour,c.ha_retour,c.com_aer,c.priix,c.ref_vols);
     }

}}
fclose(f2);
fclose(f);
remove("vols_ar.txt");
rename("vol_artmp.txt","vols_ar.txt");

}
}


void supprimer_vols_ar(char refer[])
{
FILE *f,*f1;
vole c;
 
f=fopen("vols_ar.txt","r"); 
f1=fopen("voltemp.txt","w");
 if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",c.depart_aller,c.arrivee_aller,c.date_aller,c.hd_aller,c.ha_aller,c.depart_retour,c.arrivee_retour,c.date_retour,c.hd_retour,c.ha_retour,c.com_aer,c.priix,c.ref_vols)!=EOF) 
{
if(strcmp(refer,c.ref_vols)!=0)
{
fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",c.depart_aller,c.arrivee_aller,c.date_aller,c.hd_aller,c.ha_aller,c.depart_retour,c.arrivee_retour,c.date_retour,c.hd_retour,c.ha_retour,c.com_aer,c.priix,c.ref_vols);
}}
fclose(f) ; 
fclose(f1);}
 
f=fopen("vols_ar.txt","w"); 
f1=fopen("voltemp.txt","r");
if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",c.depart_aller,c.arrivee_aller,c.date_aller,c.hd_aller,c.ha_aller,c.depart_retour,c.arrivee_retour,c.date_retour,c.hd_retour,c.ha_retour,c.com_aer,c.priix,c.ref_vols)!=EOF) 
{
if(strcmp(refer,c.ref_vols)!=0)
{
fprintf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",c.depart_aller,c.arrivee_aller,c.date_aller,c.hd_aller,c.ha_aller,c.depart_retour,c.arrivee_retour,c.date_retour,c.hd_retour,c.ha_retour,c.com_aer,c.priix,c.ref_vols);
}}
fclose(f) ; 
fclose(f1);
}}

void aff_vols_ar(GtkWidget *liste,char ref[])
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char Depart_aller[20];
char Arrivee_aller[20];
char Date_aller[50];
char HD_aller[20];
char HA_aller[20];
char Depart_retour[20];
char Arrivee_retour[20];
char Date_retour[20];
char HD_retour[20];
char HA_retour[20];
char Com_aer[20];
char Priix[20];
char Ref_vols[20];

FILE*f;
store==NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Depart Aller",renderer,"text",DEPART_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Arrivee Aller",renderer,"text",ARRIVEE_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date aller",renderer,"text",DATE_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("H Depart A",renderer,"text",HEURE_DEPART_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("H Arrivee A",renderer,"text",HEURE_ARRIVEE_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Derpat R",renderer,"text",DEPART_RETOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Arrivee R",renderer,"text",ARRIVEE_RETOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date Retour",renderer,"text",DATE_RETOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("H depart R",renderer,"text",HEURE_DEPART_RETOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("H aller R",renderer,"text",HEURE_ARRIVEE_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Compagnie Aerienne",renderer,"text",COMPAGNIE_AERIENNE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Prix",renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Reference",renderer,"text",REFERENCE_VOLS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
}

store=gtk_list_store_new (13, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f = fopen("vols_ar.txt","r");
if (f==NULL)
{ return; }
else 
{f= fopen("vols_ar.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",Depart_aller,Arrivee_aller,Date_aller,HD_aller,HA_aller,Depart_retour,Arrivee_retour,Date_retour,HD_retour,HA_retour,Com_aer,Priix,Ref_vols)!=EOF)
{ if (strcmp(Ref_vols,ref)==0)
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,DEPART_ALLER,Depart_aller,ARRIVEE_ALLER,Arrivee_aller,DATE_ALLER,Date_aller,HEURE_DEPART_ALLER,HD_aller,HEURE_ARRIVEE_ALLER,HA_aller,DEPART_RETOUR,Depart_retour,
ARRIVEE_RETOUR,Arrivee_retour,DATE_RETOUR,Date_retour,HEURE_DEPART_RETOUR,HD_retour,HEURE_ARRIVEE_RETOUR,HA_retour,COMPAGNIE_AERIENNE,Com_aer,PRIX,Priix, REFERENCE_VOLS,Ref_vols,-1);}
fclose(f);}
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}

int ver_volar(char ref[])

{vole b;
FILE *f;
int test = 0 ; 
f=fopen("vols_ar.txt","r");
if(f!=NULL) { 
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",b.depart_aller,b.arrivee_aller,b.date_aller,b.hd_aller,b.ha_aller,b.depart_retour,b.arrivee_retour,b.date_retour,b.hd_retour,b.ha_retour,b.com_aer,b.priix,b.ref_vols)!=EOF) 
{ 
if(strcmp(b.ref_vols,ref)==0)
test=1 ;
 } }
fclose(f);
 
return test;
}





