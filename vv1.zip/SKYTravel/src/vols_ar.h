#include<gtk/gtk.h>


typedef struct
{ 
char depart_aller[20];
char arrivee_aller[20];
char date_aller[50];
char hd_aller[20];
char ha_aller[20];
char depart_retour[20];
char arrivee_retour[20];
char date_retour[20];
char hd_retour[20];
char ha_retour[20];
char com_aer[20];
char priix[20];
char ref_vols[20];
}vole;

void ajouter_vol_ar(vole v);
void afficher_vols_ar(GtkWidget *liste);
int verifier_reference(char refer[]);
void modifier_vol_ar(vole p);
void supprimer_vols_ar(char refer[]);
void aff_vols_ar(GtkWidget *liste,char ref[]);
int ver_volar(char ref[]);


