#include<stdio.h>
#include<string.h>
#include"passagers_ar.h"
#include <gtk/gtk.h>

enum 
{
NOM,
PRENOM,
DATE_NAISSANCE,
NATIONALITE,
PASSEPORT,
DEPART_ALLER,
ARRIVEE_ALLER,
DATE_ALLER,
HEURE_DEPART_ALLER,
HEURE_ARRIVEE_ALLER,
DEPART_RETOUR,
ARRIVEE_RETOUR,
DATE_RETOUR,
HEURE_DEPART_RETOUR,
HEURE_ARRIVEE_RETOUR,
COMPAGNIE_AERIENNE,
PRIX,
REFERENCE_VOLS,
COLUMNS
};
void ajouter_pas(pass p)
{FILE *f;
f=fopen("pass.txt","a+");
if (f!=NULL)
{ 
fprintf(f,"%s %s %d/%d/%d %s %s\n",p.Nom,p.Prenom,p.dt_naiss.Jour,p.dt_naiss.Mois,p.dt_naiss.Annee,p.Nat,p.Passeport);
fclose(f);
}
}


void afficher_client_ar(GtkWidget *liste)
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char nom[20];
char prenom[20];
char date_na[20];
char natio[20];
char passep[20];
char Depart_aller[20];
char Arrivee_aller[20];
char Date_aller[50];
char HD_aller[20];
char HA_aller[20];
char Depart_retour[20];
char Arrivee_retour[20];
char Date_retour[20];
char HD_retour[20];
char HA_retour[20];
char Com_aer[20];
char Priix[20];
char Ref_vols[20];

FILE*f;
store==NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date naissance",renderer,"text",DATE_NAISSANCE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Nationalité",renderer,"text",NATIONALITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Passeport",renderer,"text",PASSEPORT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Depart Aller",renderer,"text",DEPART_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Arrivee Aller",renderer,"text",ARRIVEE_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date aller",renderer,"text",DATE_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("H Depart A",renderer,"text",HEURE_DEPART_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("H Arrivee A",renderer,"text",HEURE_ARRIVEE_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Derpat R",renderer,"text",DEPART_RETOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Arrivee R",renderer,"text",ARRIVEE_RETOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date Retour",renderer,"text",DATE_RETOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("H depart R",renderer,"text",HEURE_DEPART_RETOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("H aller R",renderer,"text",HEURE_ARRIVEE_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Compagnie Aerienne",renderer,"text",COMPAGNIE_AERIENNE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Prix",renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Reference",renderer,"text",REFERENCE_VOLS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
}

store=gtk_list_store_new (18, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("pass.txt","r");
if (f==NULL)
{ return; }
else 
{f= fopen("pass.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s\n",Depart_aller,Arrivee_aller,Date_aller,HD_aller,HA_aller,Depart_retour,Arrivee_retour,Date_retour,HD_retour,HA_retour,Com_aer,Priix,Ref_vols,nom,prenom,date_na,natio,passep)!=EOF)
{ 
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,NOM,nom,PRENOM,prenom,DATE_NAISSANCE,date_na,NATIONALITE,natio,PASSEPORT,passep,DEPART_ALLER,Depart_aller,ARRIVEE_ALLER,Arrivee_aller,DATE_ALLER,Date_aller,HEURE_DEPART_ALLER,HD_aller,HEURE_ARRIVEE_ALLER,HA_aller,DEPART_RETOUR,Depart_retour,
ARRIVEE_RETOUR,Arrivee_retour,DATE_RETOUR,Date_retour,HEURE_DEPART_RETOUR,HD_retour,HEURE_ARRIVEE_RETOUR,HA_retour,COMPAGNIE_AERIENNE,Com_aer,PRIX,Priix, REFERENCE_VOLS,Ref_vols,-1);}
fclose(f);}
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}


void afficher_client_allerretour(GtkWidget *liste,char pa[])
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char nom[20];
char prenom[20];
char date_na[20];
char natio[20];
char passep[20];
char Depart_aller[20];
char Arrivee_aller[20];
char Date_aller[50];
char HD_aller[20];
char HA_aller[20];
char Depart_retour[20];
char Arrivee_retour[20];
char Date_retour[20];
char HD_retour[20];
char HA_retour[20];
char Com_aer[20];
char Priix[20];
char Ref_vols[20];

FILE*f;
store==NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date naissance",renderer,"text",DATE_NAISSANCE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Nationalité",renderer,"text",NATIONALITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Passeport",renderer,"text",PASSEPORT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Depart Aller",renderer,"text",DEPART_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Arrivee Aller",renderer,"text",ARRIVEE_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date aller",renderer,"text",DATE_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("H Depart A",renderer,"text",HEURE_DEPART_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("H Arrivee A",renderer,"text",HEURE_ARRIVEE_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Derpat R",renderer,"text",DEPART_RETOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Arrivee R",renderer,"text",ARRIVEE_RETOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date Retour",renderer,"text",DATE_RETOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("H depart R",renderer,"text",HEURE_DEPART_RETOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("H aller R",renderer,"text",HEURE_ARRIVEE_ALLER,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Compagnie Aerienne",renderer,"text",COMPAGNIE_AERIENNE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Prix",renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Reference",renderer,"text",REFERENCE_VOLS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
}

store=gtk_list_store_new (18, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("pass.txt","r");
if (f==NULL)
{ return; }
else 
{f= fopen("pass.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s\n",Depart_aller,Arrivee_aller,Date_aller,HD_aller,HA_aller,Depart_retour,Arrivee_retour,Date_retour,HD_retour,HA_retour,Com_aer,Priix,Ref_vols,nom,prenom,date_na,natio,passep)!=EOF)
{ 
if (strcmp(passep,pa)==0)
{
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,NOM,nom,PRENOM,prenom,DATE_NAISSANCE,date_na,NATIONALITE,natio,PASSEPORT,passep,DEPART_ALLER,Depart_aller,ARRIVEE_ALLER,Arrivee_aller,DATE_ALLER,Date_aller,HEURE_DEPART_ALLER,HD_aller,HEURE_ARRIVEE_ALLER,HA_aller,DEPART_RETOUR,Depart_retour,
ARRIVEE_RETOUR,Arrivee_retour,DATE_RETOUR,Date_retour,HEURE_DEPART_RETOUR,HD_retour,HEURE_ARRIVEE_RETOUR,HA_retour,COMPAGNIE_AERIENNE,Com_aer,PRIX,Priix, REFERENCE_VOLS,Ref_vols,-1);}}
fclose(f);}
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}

int ver_clienar(char passe[])

{pass b;
FILE *f;
char dae[20];
int test = 0 ; 
f=fopen("pass.txt","r");
if(f!=NULL) { 
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s\n",b.depart_all,b.arrivea,b.datea,b.h_depa,b.h_arra,b.departr,b.departa,b.dater,b.h_depr,b.h_dep,b.compagnie,b.Prix,b.Ref,b.Nom,b.Prenom,b.Nat,dae,b.Passeport)!=EOF) 
{ 
if(strcmp(b.Passeport,passe)==0)
test=1 ;
 } }
fclose(f);
 
return test;
}


