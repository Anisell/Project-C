#include<gtk/gtk.h>


int verifier_volar(char depp[],char ar[],char da[],char dr[]);
void afficher_allerretour(GtkWidget *liste,char dep[],char arr[],char d_a[], char d_r[]);
