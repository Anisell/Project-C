#include<gtk/gtk.h>
typedef struct
{
int Jour;
int Mois;
int Annee;
}da;
typedef struct
{
char Nom[20];
char Prenom[20];
da dt_naiss;
char Nat[20];
char Passeport[30];
char depart_all[20];
char arrivea[20];
char datea[20];
char h_depa[20];
char h_arra[20];
char departr[20];
char departa[20];
char dater[20];
char h_depr[20];
char h_dep[20];
char compagnie[20];
char Prix[20];
char Ref[20];
}pass;
void ajouter_pas(pass p);
void afficher_client_ar(GtkWidget *liste);
int ver_clienar(char passe[]);
void afficher_client_allerretour(GtkWidget *liste,char pa[]);

