#include<gtk/gtk.h>
typedef struct
{
int jour;
int mois;
int annee;
}date;

typedef struct
{
char nom[20];
char prenom[20];
date dt_nai;
char nat[20];
char passeport[30];
char departt[20];
char arrives[20];
char datte[20];
char h_dep[20];
char h_arr[20];
char compagnie[20];
char Prix[20];
char Ref[20];
}passagers;

void ajouter_passagers(passagers p);
void afficher_client(GtkWidget *liste);
void modifier_client(passagers m,char dd[]);

void supprimer_client(char passep[]);
