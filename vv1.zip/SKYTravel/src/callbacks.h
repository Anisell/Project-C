#include <gtk/gtk.h>


void
on_confirmer100_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour102_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retour105_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_confirmer103_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour106_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_confirmer108_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_quitter108_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_gestionclient_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void 
on_gestionduvols_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retour110_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_rechercher111_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer100_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifier100_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_Rechercher115_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer110_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_modifier110_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ajouter120_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retour117_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retour121_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_confirmer130_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_rechercher101_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_quitter101_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobuttonaller_toggled            (GtkWidget 	*objet_graphique,
                                        gpointer         user_data);

void
on_radiobuttonallerretour11_toggled    (GtkWidget 	*objet_graphique,
                                        gpointer         user_data);

void
on_Rechercher100_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retour114_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_confirmer_modifier_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retour131_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_supprimer_vol_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retour130_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);



void
on_modifier400_clicked                 (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretour12_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_radioallerretour_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_radioallersimple_clicked            (GtkWidget      *Objet_graphique,
                                        gpointer         user_data);

void
on_buttonretour150_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonajouter140_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
on_buttonretour141_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonmodifier141_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonajouter141_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);





void
on_buttonmodifier154_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretour154_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimer114_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretour156_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonmodifier152_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretour152_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_buttonsupprimer142_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeviewvolsdisponible_row_activated
                                        (GtkWidget    *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,

						gpointer         user_data);

void
on_volsallerdisponible_row_activated   (GtkWidget *objet_graphique,GtkTreePath *path,GtkTreeViewColumn *column, gpointer  user_data);






void
on_buttonretour160_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_confirmerreservation_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_radiobuttonalar_toggled             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
on_retour14111_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobuttonall_toggled            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeviewclinetar_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_liste_des_clients_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonrrr_enter                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonmmm_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_buttonsss_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_rrrr111_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_rech144_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_rechercherr144_clicked              (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_afficher14_clicked                 (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_AFF144_clicked                       (GtkWidget      *objet_graphique,
                                        gpointer         user_data);




void
on_buttonMODDD_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonSUPP_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_Retour1444_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_Rechercher447_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_afficher999_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
on_rech999_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

                 

void
on_afficher400_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
