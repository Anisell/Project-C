#include<stdio.h>
#include<string.h>
#include"passagers.h"
#include <gtk/gtk.h>
enum 
{
NOM,
PRENOM,
DATE_NAISSANCE,
NATIONALITE,
PASSEPORT,
DEPART,
ARRIVEE,
DATE,
HEURE_DEPART,
HEURE_ARRIVEE,
COMPAGNIE_AERIENNE,
PRIX,
REFERENCE_VOLS,
COLUMNS
};


void ajouter_passagers(passagers p)
{FILE *f;
f=fopen("passagers.txt","a+");
if (f!=NULL)
{ 
fprintf(f,"%s %s %d/%d/%d %s %s\n",p.nom,p.prenom,p.dt_nai.jour,p.dt_nai.mois,p.dt_nai.annee,p.nat,p.passeport);
fclose(f);
}
}

void afficher_client(GtkWidget *liste)
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char Depart[20];
char Arrivee[20];
char Date[50];
char Heure_depart[20];
char Heure_arrivee[20];
char Compagnie_aerienne[20];
char Prix[20];
char Reference_vols[20];
char Nom[20];
char Prenom[20];
char date[20];
char nat[20];
char pass[20];
FILE*f;
store==NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date_naissance",renderer,"text",DATE_NAISSANCE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Nationalité",renderer,"text",NATIONALITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Passeport",renderer,"text",PASSEPORT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Depart",renderer,"text",DEPART,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Arrivee",renderer,"text",ARRIVEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date",renderer,"text",DATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Heure_Depart",renderer,"text",HEURE_DEPART,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Heure_arrivee",renderer,"text",HEURE_ARRIVEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Compagnie_Aerienne",renderer,"text",COMPAGNIE_AERIENNE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Prix",renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Reference",renderer,"text",REFERENCE_VOLS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

}
store=gtk_list_store_new (13, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("passagers.txt","r");
if (f==NULL)
{ return; }
else 
{ 
f= fopen("passagers.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",Depart,Arrivee,Date,Heure_depart,Heure_arrivee,Compagnie_aerienne,Prix,Reference_vols,Nom,Prenom,date,nat,pass)!=EOF)
{ 
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,NOM,Nom,PRENOM,Prenom,DATE_NAISSANCE,date,NATIONALITE,nat,PASSEPORT,pass,DEPART,Depart,ARRIVEE,Arrivee,DATE,Date,HEURE_DEPART,Heure_depart,HEURE_ARRIVEE,Heure_arrivee,COMPAGNIE_AERIENNE,Compagnie_aerienne,PRIX,Prix, REFERENCE_VOLS,Reference_vols,-1);}
fclose(f);}
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}



void modifier_client(passagers m,char dd[])
{
passagers a ;
char da[20];
FILE *f;
FILE *f2;
f=fopen("passagers.txt","r");
f2=fopen("passagers_tmp.txt","a+"); 
if (f!=NULL)
{
if (f2!=NULL)

{ 
     while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",a.departt,a.arrives,a.datte,a.h_dep,a.h_arr,a.compagnie,a.Prix,a.Ref,a.nom,a.prenom,da,a.nat,a.passeport)!=EOF)
    { 
	if (strcmp(a.passeport,m.passeport)==0)
{    fprintf(f2,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",m.departt,m.arrives,m.datte,m.h_dep,m.h_arr,m.compagnie,m.Prix,m.Ref,m.nom,m.prenom,dd,m.nat,m.passeport);
}
	else 	
{	    fprintf(f2,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",a.departt,a.arrives,a.datte,a.h_dep,a.h_arr,a.compagnie,a.Prix,a.Ref,a.nom,a.prenom,da,a.nat,a.passeport);
     }

}}
fclose(f2);
fclose(f);
remove("passagers.txt");
rename("passagers_tmp.txt","passagers.txt");
}
}

void supprimer_client(char passep[])
{
passagers a;
char da[20];
FILE *f,*f1;

 
f=fopen("passagers.txt","a+"); 
f1=fopen("passagerstemp.txt","a+");

while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",a.departt,a.arrives,a.datte,a.h_dep,a.h_arr,a.compagnie,a.Prix,a.Ref,a.nom,a.prenom,da,a.nat,a.passeport)!=EOF) 
{
if(strcmp(passep,a.passeport)!=0)
{
fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",a.departt,a.arrives,a.datte,a.h_dep,a.h_arr,a.compagnie,a.Prix,a.Ref,a.nom,a.prenom,da,a.nat,a.passeport);
break;
}}
fclose(f) ; 
fclose(f1);
 
remove("passagers.txt");
rename("passagerstemp.txt","passagers.txt");

}







