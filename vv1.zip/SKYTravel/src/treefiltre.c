#include<stdio.h>
#include<string.h>
#include"vols.h"
#include <gtk/gtk.h>

enum 
{
DEPART,
ARRIVEE,
DATE,
HEURE_DEPART,
HEURE_ARRIVEE,
COMPAGNIE_AERIENNE,
PRIX,
REFERENCE_VOLS,
COLUMNS
};

int verifier_vols(char dep[],char arr[],char da[])
{vols m;
FILE *f;
int test = 0 ; 
f=fopen("vols_disponible.txt","r");
if(f!=NULL) { 
while(fscanf(f,"%s %s %s %s %s %s %s %s\n",m.depart,m.arrivee,m.date,m.heure_depart,m.heure_arrivee,m.compagnie_aerienne,m.prix,m.reference_vols)!=EOF) 
{ 
if((strcmp(m.depart,dep)==0)&&(strcmp(m.arrivee,arr)==0)&&(strcmp(m.date,da)==0))
test=1 ;
 } }
fclose(f);
 
return test;
}

void afficher_vols(GtkWidget *liste,char depar[],char arri[],char Dat[])
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char Depart[20];
char Arrivee[20];
char Date[50];
char Heure_depart[20];
char Heure_arrivee[20];
char Compagnie_aerienne[20];
char Prix[20];
char Reference_vols[20];
FILE*f;
store==NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Depart",renderer,"text",DEPART,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Arrivee",renderer,"text",ARRIVEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date",renderer,"text",DATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Heure_Depart",renderer,"text",HEURE_DEPART,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Heure_arrivee",renderer,"text",HEURE_ARRIVEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Compagnie_Aerienne",renderer,"text",COMPAGNIE_AERIENNE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Prix",renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Reference",renderer,"text",REFERENCE_VOLS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

}
store=gtk_list_store_new (8, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("vols_disponible.txt","r");
if (f==NULL)
{ return; }
else 
{ 
f= fopen("vols_disponible.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s\n",Depart,Arrivee,Date,Heure_depart,Heure_arrivee,Compagnie_aerienne,Prix,Reference_vols)!=EOF)
{
if ((strcmp(Depart,depar)==0)&&(strcmp(Arrivee,arri)==0)&&(strcmp(Date,Dat)==0))
{
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,DEPART,Depart,ARRIVEE,Arrivee,DATE,Date,HEURE_DEPART,Heure_depart,HEURE_ARRIVEE,Heure_arrivee,COMPAGNIE_AERIENNE,Compagnie_aerienne,PRIX,Prix, REFERENCE_VOLS,Reference_vols,-1);}}
fclose(f);}
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}

void rechercher_vols(GtkWidget *liste,char ref[])
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char Depart[20];
char Arrivee[20];
char Date[50];
char Heure_depart[20];
char Heure_arrivee[20];
char Compagnie_aerienne[20];
char Prix[20];
char Reference_vols[20];
FILE*f;
store==NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Depart",renderer,"text",DEPART,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Arrivee",renderer,"text",ARRIVEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date",renderer,"text",DATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Heure_Depart",renderer,"text",HEURE_DEPART,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Heure_arrivee",renderer,"text",HEURE_ARRIVEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Compagnie_Aerienne",renderer,"text",COMPAGNIE_AERIENNE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Prix",renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Reference",renderer,"text",REFERENCE_VOLS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

}
store=gtk_list_store_new (8, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("vols_disponible.txt","r");
if (f==NULL)
{ return; }
else 
{ 
f= fopen("vols_disponible.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s\n",Depart,Arrivee,Date,Heure_depart,Heure_arrivee,Compagnie_aerienne,Prix,Reference_vols)!=EOF)
{
if ((strcmp(Reference_vols,ref)==0))
{
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,DEPART,Depart,ARRIVEE,Arrivee,DATE,Date,HEURE_DEPART,Heure_depart,HEURE_ARRIVEE,Heure_arrivee,COMPAGNIE_AERIENNE,Compagnie_aerienne,PRIX,Prix, REFERENCE_VOLS,Reference_vols,-1);}}
fclose(f);}
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
int ver_vols(char ref[])
{vols m;
FILE *f;
int test = 0 ; 
f=fopen("vols_disponible.txt","r");
if(f!=NULL) { 
while(fscanf(f,"%s %s %s %s %s %s %s %s\n",m.depart,m.arrivee,m.date,m.heure_depart,m.heure_arrivee,m.compagnie_aerienne,m.prix,m.reference_vols)!=EOF) 
{ 
if(strcmp(m.reference_vols,ref)==0)
test=1 ;
 } }
fclose(f);
 
return test;
}



