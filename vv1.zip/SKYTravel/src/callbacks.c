#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include "vols.h"
#include "vols_ar.h"
#include "treefiltre.h"
#include "treeviewar.h"
#include "passagers_ar.h"
#include "passagers.h"
#include "treeclient.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"


void
on_confirmer100_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
}




void
on_retour102_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
window1=lookup_widget(objet_graphique,"vols_disponible_aller_retour");
window2=create_interfacevols();
gtk_widget_show(window2);
gtk_widget_hide(window1);

}


void
on_retour105_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *window1;
GtkWidget *window2;
window1=lookup_widget(objet_graphique,"vols_disponible_allersimple");


window2=create_interfacevolsallersimple();
gtk_widget_show(window2);
gtk_widget_hide(window1);

}


void
on_confirmer103_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}
void
on_retour106_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *info_passagers;
GtkWidget *vols_disponible_allersimple;
info_passagers=lookup_widget(objet_graphique,"info_passagers");
gtk_widget_destroy(info_passagers);
vols_disponible_allersimple=lookup_widget(objet_graphique,"vols_disponible_allersimple");
vols_disponible_allersimple=create_vols_disponible_allersimple();
gtk_widget_show(vols_disponible_allersimple);
gtk_widget_hide(info_passagers);

}


void
on_confirmer108_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1,*input2,*input3,*input4,*combobox1,*combobox2,*combobox3;
GtkWidget *window1,*window2;
window1=lookup_widget(objet_graphique,"info_passagers");
window2=create_reservationreussite();
passagers p;
input1=lookup_widget(objet_graphique,"nompassagers");
input2=lookup_widget(objet_graphique,"prenompassager");
input3=lookup_widget(objet_graphique,"nationalite");
input4=lookup_widget(objet_graphique,"pass100");
combobox1=lookup_widget(objet_graphique,"jour10");
combobox2=lookup_widget(objet_graphique,"mois10");
combobox3=lookup_widget(objet_graphique,"annee10");
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.nat,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(p.passeport,gtk_entry_get_text(GTK_ENTRY(input4)));
p.dt_nai.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(combobox1));
p.dt_nai.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(combobox2));
p.dt_nai.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(combobox3));
ajouter_passagers(p);
gtk_widget_hide(window1);
gtk_widget_show(window2);
}


void
on_quitter108_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_gestionclient_clicked               (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *tree1; 
window1=lookup_widget(objet_graphique,"gestionduvols_agent");
window2=create_liste_des_clients11();
gtk_widget_show(window2);
gtk_widget_hide(window1);
tree1=lookup_widget(window2,"liste_des_clients") ; 
afficher_client(tree1);

}


void
on_gestionduvols_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *tree; 
window1=lookup_widget(objet_graphique,"gestionduvols_agent");
window2=create_liste_des_vols();
gtk_widget_show(window2);
gtk_widget_hide(window1);
tree=lookup_widget(window2,"vols_disponible") ; 
afficher_vols_agent(tree);


}


void
on_retour110_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_rechercher111_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_supprimer100_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Modifier100_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Rechercher115_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_supprimer110_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *window1, *window2;

window1=lookup_widget(objet_graphique,"liste_des_vols");
gtk_widget_hide(window1);
window2 = create_supprimer_vol1();
gtk_widget_show (window2);

}


void
on_modifier110_clicked                 (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *window1, *window2;

window1=lookup_widget(objet_graphique,"liste_des_vols");
gtk_widget_hide(window1);
window2 = create_modifier_vol();
gtk_widget_show (window2);

}


void
on_ajouter120_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
window1=lookup_widget(objet_graphique,"liste_des_vols");
window2=create_ajouter_vols();
gtk_widget_show(window2);
gtk_widget_hide(window1);

}


void
on_retour117_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *window1;
GtkWidget *window2;
window1=lookup_widget(objet_graphique,"liste_des_vols");
window2=create_gestionduvols_agent();
gtk_widget_show(window2);
gtk_widget_hide(window1);

}


void
on_retour121_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *window11;
GtkWidget *window12;
GtkWidget *treeview;
window11=lookup_widget(objet_graphique,"ajouter_vols");
window12=create_liste_des_vols();
gtk_widget_show(window12);
gtk_widget_hide(window11);
treeview=lookup_widget(window12,"vols_disponible");
afficher_vols_agent(treeview);

}


void
on_confirmer130_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
vols v;
GtkWidget *Depart, *Arrivee, *Date,*h_depart,*h_arrivee,*compagnie_aer,*prixvols,*reference;
GtkWidget *output;
GtkWidget *ajouter_vols;
ajouter_vols=lookup_widget(objet_graphique,"ajouter_vols");
Depart=lookup_widget(objet_graphique,"depart110");
Arrivee=lookup_widget(objet_graphique,"arrivee110");
Date=lookup_widget(objet_graphique,"date_vols");
h_depart=lookup_widget(objet_graphique,"heure_depart");
h_arrivee=lookup_widget(objet_graphique,"heure_arrivee");
compagnie_aer=lookup_widget(objet_graphique,"compagnie_aerienne");
prixvols=lookup_widget(objet_graphique,"Prix_vols");
reference=lookup_widget(objet_graphique,"reference_vol");
output=lookup_widget(objet_graphique,"label1123");
strcpy(v.depart,gtk_entry_get_text(GTK_ENTRY(Depart)));
strcpy(v.arrivee,gtk_entry_get_text(GTK_ENTRY(Arrivee)));
strcpy(v.date,gtk_entry_get_text(GTK_ENTRY(Date)));
strcpy(v.heure_depart,gtk_entry_get_text(GTK_ENTRY(h_depart)));
strcpy(v.heure_arrivee,gtk_entry_get_text(GTK_ENTRY(h_arrivee)));
strcpy(v.compagnie_aerienne,gtk_entry_get_text(GTK_ENTRY(compagnie_aer)));
strcpy(v.prix,gtk_entry_get_text(GTK_ENTRY(prixvols)));
strcpy(v.reference_vols,gtk_entry_get_text(GTK_ENTRY(reference)));
ajouter_vol(v);
gtk_label_set_text(GTK_LABEL(output),"vol ajouter avec succés");
	gtk_entry_set_text(GTK_ENTRY(Depart),"");
	gtk_entry_set_text(GTK_ENTRY(Arrivee),"");
	gtk_entry_set_text(GTK_ENTRY(Date),"");
	gtk_entry_set_text(GTK_ENTRY(h_depart),"");
	gtk_entry_set_text(GTK_ENTRY(h_arrivee),"");
	gtk_entry_set_text(GTK_ENTRY(compagnie_aer),"");
	gtk_entry_set_text(GTK_ENTRY(prixvols),"");
	gtk_entry_set_text(GTK_ENTRY(reference),"");

}


void
on_rechercher101_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *window1;
GtkWidget *window2;
GtkWidget *input1,*input2,*input3;
GtkWidget *tree1;
GtkWidget *output;
vols v;
char dep[20],arr[20],dates[20];
int test;
window1=lookup_widget(objet_graphique,"interfacevolsallersimple");
window2=create_vols_disponible_allersimple();
input1=lookup_widget(objet_graphique,"depart2");
input2=lookup_widget(objet_graphique,"arrivee2");
input3=lookup_widget(objet_graphique,"da102");
output=lookup_widget(objet_graphique,"label1189");
strcpy(dep,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(arr,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(dates,gtk_entry_get_text(GTK_ENTRY(input3)));
if (verifier_vols(dep,arr,dates)==0)
gtk_label_set_text(GTK_LABEL(output),"vol indisponible");
else {
FILE *f2;
f2=fopen("vols_disponible.txt","r"); 
if (f2!=NULL)
{
while (fscanf(f2,"%s %s %s %s %s %s %s %s\n",v.depart,v.arrivee,v.date,v.heure_depart,v.heure_arrivee,v.compagnie_aerienne,v.prix,v.reference_vols)!=EOF)
{if ((strcmp(v.depart,dep)==0)&&(strcmp(v.arrivee,arr)==0)&&(strcmp(v.date,dates)==0))
{gtk_widget_show(window2);
gtk_widget_hide(window1);
tree1=lookup_widget(window2,"treeviewvolsdisponible");
afficher_vols(tree1,dep,arr,dates);
break;}}}
fclose(f2);
}
}


void
on_quitter101_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_radiobuttonaller_toggled            (GtkWidget *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *window1;
GtkWidget *window2;
window1=lookup_widget(objet_graphique,"interfacevols");
window2=create_interfacevolsallersimple();
gtk_widget_hide(window1);
gtk_widget_show(window2);

}


void
on_radiobuttonallerretour11_toggled    (GtkWidget *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *window1;
GtkWidget *window2;
window1=lookup_widget(objet_graphique,"interfacevolsallersimple");


window2=create_interfacevols();
gtk_widget_hide(window1);
gtk_widget_show(window2);

}


void
on_Rechercher100_clicked               (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *input1,*input2,*input3,*input4;
GtkWidget *treeview1;
GtkWidget *output;
vole v;
char dep[20],arr[20],da_aller[20],da_retour[20];
int test;
window1=lookup_widget(objet_graphique,"interfacevols");
window2=create_vols_disponible_aller_retour();
input1=lookup_widget(objet_graphique,"depart100");
input2=lookup_widget(objet_graphique,"arrivee100");
input3=lookup_widget(objet_graphique,"da100");
input4=lookup_widget(objet_graphique,"dr100");
output=lookup_widget(objet_graphique,"label1186");
strcpy(dep,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(arr,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(da_aller,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(da_retour,gtk_entry_get_text(GTK_ENTRY(input4)));
if (verifier_volar(dep,arr,da_aller,da_retour)==0)
gtk_label_set_text(GTK_LABEL(output),"vol indisponible");
else {
FILE *f1;
f1=fopen("vols_ar.txt","r"); 
if (f1!=NULL)
{
while (fscanf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",v.depart_aller,v.arrivee_aller,v.date_aller,v.hd_aller,v.ha_aller,v.depart_retour,v.arrivee_retour,v.date_retour,v.hd_retour,v.ha_retour,v.com_aer,v.priix,v.ref_vols)!=EOF)
{if ((strcmp(v.depart_aller,dep)==0)&&(strcmp(v.arrivee_aller,arr)==0)&&(strcmp(v.date_aller,da_aller)==0)&&(strcmp(v.date_retour,da_retour)==0))
{gtk_widget_show(window2);
gtk_widget_hide(window1);
treeview1=lookup_widget(window2,"volsallerdisponible");
afficher_allerretour(treeview1,dep,arr,da_aller,da_retour);
break;}}}
fclose(f1);
}
}


void
on_retour114_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *window1;
GtkWidget *window2;
window1=lookup_widget(objet_graphique,"liste_clients11");
window2=lookup_widget(objet_graphique,"gestionduvols_agent");
window2=create_gestionduvols_agent();
gtk_widget_show(window2);
gtk_widget_hide(window1);

}





void
on_confirmer_modifier_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{char refe[20];
int test;
vols v;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9;
GtkWidget *window1,*window2;
GtkWidget *output;
char ref[20];
window2=create_con_modifvols();
input1=lookup_widget(objet_graphique,"reference_vol10");
input2=lookup_widget(window2,"entrydepart100");
input3=lookup_widget(window2,"entryarrivee");
input4=lookup_widget(window2,"entrydate111");
input5=lookup_widget(window2,"entryhdepart");
input6=lookup_widget(window2,"entryharrivee");
input7=lookup_widget(window2,"entrycompa");
input8=lookup_widget(window2,"entryprix11");
input9=lookup_widget(window2,"entryref9");
output= lookup_widget(objet_graphique,"label1120");
strcpy(refe,gtk_entry_get_text(GTK_ENTRY(input1)));
if (verifier_ref(refe)==0)
gtk_label_set_text(GTK_LABEL(output),"Vol inexistante");
else
{
FILE *f2;
f2=fopen("vols_disponible.txt","r"); 
if (f2!=NULL)
{while (fscanf(f2,"%s %s %s %s %s %s %s %s\n",v.depart,v.arrivee,v.date,v.heure_depart,v.heure_arrivee,v.compagnie_aerienne,v.prix,v.reference_vols)!=EOF)
{if (strcmp(v.reference_vols,refe)==0) 
{ gtk_widget_show(window2);
gtk_entry_set_text(GTK_ENTRY(input2),v.depart) ;
gtk_entry_set_text(GTK_ENTRY(input3),v.arrivee) ;
gtk_entry_set_text(GTK_ENTRY(input4),v.date) ;
gtk_entry_set_text(GTK_ENTRY(input5),v.heure_depart) ;
gtk_entry_set_text(GTK_ENTRY(input6),v.heure_arrivee) ;
gtk_entry_set_text(GTK_ENTRY(input7),v.compagnie_aerienne) ;
gtk_entry_set_text(GTK_ENTRY(input8),v.prix) ;
gtk_entry_set_text(GTK_ENTRY(input9),v.reference_vols) ;
gtk_widget_hide(window1);
break ;}}
}
fclose(f2);
}}


void
on_retour131_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *window1, *window2;
GtkWidget *treeview;
window1=lookup_widget(objet_graphique,"modifier_vol");
gtk_widget_hide(window1);
window2 = create_liste_des_vols();
gtk_widget_show (window2);
treeview=lookup_widget(window2,"vols_disponible");
afficher_vols_agent(treeview);

}


void
on_supprimer_vol_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *input100;
GtkWidget *output100;
vols b;
char refer[20];
input100=lookup_widget(objet_graphique,"entry12");
output100=lookup_widget(objet_graphique,"label1122");
strcpy(refer,gtk_entry_get_text(GTK_ENTRY(input100)));
if(verifier_ref(refer)==0)
gtk_label_set_text(GTK_LABEL(output100),"Vol inexistante");
else
{
supprimer_vols(refer);
gtk_label_set_text(GTK_LABEL(output100),"Vol supprimé");
}}

void
on_retour130_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *window1, *window2;
GtkWidget *treeview;
window1=lookup_widget(objet_graphique,"supprimer_vol1");
gtk_widget_hide(window1);
window2 = create_liste_des_vols();
gtk_widget_show (window2);
treeview=lookup_widget(window2,"vols_disponible");
afficher_vols_agent(treeview);
}




void
on_modifier400_clicked                 (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
vols v;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8;
GtkWidget *output;
input1=lookup_widget(objet_graphique,"entrydepart100");
input2=lookup_widget(objet_graphique,"entryarrivee");
input3=lookup_widget(objet_graphique,"entrydate111");
input4=lookup_widget(objet_graphique,"entryhdepart");
input5=lookup_widget(objet_graphique,"entryharrivee");
input6=lookup_widget(objet_graphique,"entrycompa");
input7=lookup_widget(objet_graphique,"entryprix11");
input8=lookup_widget(objet_graphique,"entryref9");
output=lookup_widget(objet_graphique,"label1121");
strcpy(v.depart,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(v.arrivee,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(v.date,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(v.heure_depart,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(v.heure_arrivee,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(v.compagnie_aerienne,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(v.prix,gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(v.reference_vols,gtk_entry_get_text(GTK_ENTRY(input8)));
modifier_vol(v);
gtk_label_set_text(GTK_LABEL(output),"modifié avec succés") ;
	gtk_entry_set_text(GTK_ENTRY(input1),"");
	gtk_entry_set_text(GTK_ENTRY(input2),"");
	gtk_entry_set_text(GTK_ENTRY(input3),"");
	gtk_entry_set_text(GTK_ENTRY(input4),"");
	gtk_entry_set_text(GTK_ENTRY(input5),"");
	gtk_entry_set_text(GTK_ENTRY(input6),"");
	gtk_entry_set_text(GTK_ENTRY(input7),"");
	gtk_entry_set_text(GTK_ENTRY(input8),"");

}


void
on_buttonretour12_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window2;
GtkWidget *treeview2;
window1=lookup_widget(objet_graphique,"con_modifvols");
gtk_widget_hide(window1);
window2=create_liste_des_vols();
gtk_widget_show(window2);
treeview2=lookup_widget(window2,"vols_disponible");
afficher_vols_agent(treeview2);
}




void
on_radioallerretour_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window2;
GtkWidget *treeview1;
window1=lookup_widget(objet_graphique,"liste_des_vols");
gtk_widget_hide(window1);
window2=create_vols_allerretour();
gtk_widget_show(window2);
treeview1=lookup_widget(window2,"volsdispo_allerretour");
afficher_vols_ar(treeview1);

}


void
on_radioallersimple_clicked            (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *window1,*window2;
GtkWidget *treeview2;
window1=lookup_widget(objet_graphique,"vols_allerretour");
gtk_widget_hide(window1);
window2=create_liste_des_vols();
gtk_widget_show(window2);
treeview2=lookup_widget(window2,"vols_disponible");
afficher_vols_agent(treeview2);

}





void
on_buttonretour150_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *treeview;
window1=lookup_widget(objet_graphique,"ajouter_vol_ar");
window2=create_vols_allerretour();
gtk_widget_hide(window1);
gtk_widget_show(window2);
treeview=lookup_widget(window2,"volsdispo_allerretour");
afficher_vols_ar(treeview);

}


void
on_buttonajouter140_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*input10,*input11,*input12,*input13;
GtkWidget *output;
GtkWidget *window1;
vole v;
window1=lookup_widget(objet_graphique,"ajouter_vol_ar");
input1=lookup_widget(objet_graphique,"depart120");
input2=lookup_widget(objet_graphique,"arrivee120");
input3=lookup_widget(objet_graphique,"date120");
input4=lookup_widget(objet_graphique,"h120");
input5=lookup_widget(objet_graphique,"ha120");
input6=lookup_widget(objet_graphique,"depart121");
input7=lookup_widget(objet_graphique,"arrivee121");
input8=lookup_widget(objet_graphique,"date121");
input9=lookup_widget(objet_graphique,"hd121");
input10=lookup_widget(objet_graphique,"ha121");
input11=lookup_widget(objet_graphique,"com120");
input12=lookup_widget(objet_graphique,"prix120");
input13=lookup_widget(objet_graphique,"ref120");
output=lookup_widget(objet_graphique,"label1139");
strcpy(v.depart_aller,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(v.arrivee_aller,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(v.date_aller,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(v.hd_aller,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(v.ha_aller,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(v.depart_retour,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(v.arrivee_retour,gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(v.date_retour,gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(v.hd_retour,gtk_entry_get_text(GTK_ENTRY(input9)));
strcpy(v.ha_retour,gtk_entry_get_text(GTK_ENTRY(input10)));
strcpy(v.com_aer,gtk_entry_get_text(GTK_ENTRY(input11)));
strcpy(v.priix,gtk_entry_get_text(GTK_ENTRY(input12)));
strcpy(v.ref_vols,gtk_entry_get_text(GTK_ENTRY(input13)));
ajouter_vol_ar(v);
gtk_label_set_text(GTK_LABEL(output),"vol ajouter avec succés");
	gtk_entry_set_text(GTK_ENTRY(input1),"");
	gtk_entry_set_text(GTK_ENTRY(input2),"");
	gtk_entry_set_text(GTK_ENTRY(input3),"");
	gtk_entry_set_text(GTK_ENTRY(input4),"");
	gtk_entry_set_text(GTK_ENTRY(input5),"");
	gtk_entry_set_text(GTK_ENTRY(input6),"");
	gtk_entry_set_text(GTK_ENTRY(input7),"");
	gtk_entry_set_text(GTK_ENTRY(input8),"");
	gtk_entry_set_text(GTK_ENTRY(input9),"");
	gtk_entry_set_text(GTK_ENTRY(input10),"");
	gtk_entry_set_text(GTK_ENTRY(input11),"");
	gtk_entry_set_text(GTK_ENTRY(input12),"");
	gtk_entry_set_text(GTK_ENTRY(input13),"");

}



void
on_buttonretour141_clicked             (GtkWidget      *objet_graphique,
                                        gpointer         user_data)

{GtkWidget *window1;
GtkWidget *window2;
window1=lookup_widget(objet_graphique,"vols_allerretour");
window2=create_gestionduvols_agent();
gtk_widget_hide(window1);
gtk_widget_show(window2);
}


void
on_buttonmodifier141_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *window1,*window2;
window1=lookup_widget(objet_graphique,"vols_allerretour");
window2=create_modvolar();
gtk_widget_hide(window1);
gtk_widget_show(window2);

}


void
on_buttonajouter141_clicked            (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
window1=lookup_widget(objet_graphique,"vols_allerretour");
window2=create_ajouter_vol_ar();
gtk_widget_hide(window1);
gtk_widget_show(window2);
}










void
on_buttonmodifier154_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*input10,*input11,*input12,*input13;
GtkWidget *output;
vole v;
input1=lookup_widget(objet_graphique,"depart130");
input2=lookup_widget(objet_graphique,"arrivee130");
input3=lookup_widget(objet_graphique,"date130");
input4=lookup_widget(objet_graphique,"hd130");
input5=lookup_widget(objet_graphique,"ha130");
input6=lookup_widget(objet_graphique,"depart131");
input7=lookup_widget(objet_graphique,"arrivee131");
input8=lookup_widget(objet_graphique,"date131");
input9=lookup_widget(objet_graphique,"hd131");
input10=lookup_widget(objet_graphique,"ha131");
input11=lookup_widget(objet_graphique,"com131");
input12=lookup_widget(objet_graphique,"prix131");
input13=lookup_widget(objet_graphique,"ref131");
output=lookup_widget(objet_graphique,"label1183");
strcpy(v.depart_aller,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(v.arrivee_aller,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(v.date_aller,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(v.hd_aller,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(v.ha_aller,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(v.depart_retour,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(v.arrivee_retour,gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(v.date_retour,gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(v.hd_retour,gtk_entry_get_text(GTK_ENTRY(input9)));
strcpy(v.ha_retour,gtk_entry_get_text(GTK_ENTRY(input10)));
strcpy(v.com_aer,gtk_entry_get_text(GTK_ENTRY(input11)));
strcpy(v.priix,gtk_entry_get_text(GTK_ENTRY(input12)));
strcpy(v.ref_vols,gtk_entry_get_text(GTK_ENTRY(input13)));
modifier_vol_ar(v);
gtk_label_set_text(GTK_LABEL(output),"modifié avec succés") ;
	gtk_entry_set_text(GTK_ENTRY(input1),"");
	gtk_entry_set_text(GTK_ENTRY(input2),"");
	gtk_entry_set_text(GTK_ENTRY(input3),"");
	gtk_entry_set_text(GTK_ENTRY(input4),"");
	gtk_entry_set_text(GTK_ENTRY(input5),"");
	gtk_entry_set_text(GTK_ENTRY(input6),"");
	gtk_entry_set_text(GTK_ENTRY(input7),"");
	gtk_entry_set_text(GTK_ENTRY(input8),"");
	gtk_entry_set_text(GTK_ENTRY(input9),"");
	gtk_entry_set_text(GTK_ENTRY(input10),"");
	gtk_entry_set_text(GTK_ENTRY(input11),"");
	gtk_entry_set_text(GTK_ENTRY(input12),"");
	gtk_entry_set_text(GTK_ENTRY(input13),"");

}




void
on_buttonretour154_clicked             (GtkWidget      *objet,
                                        gpointer         user_data)
{GtkWidget *window1;
GtkWidget *window2;
GtkWidget *tree;
window1=lookup_widget(objet,"modvol");
window2=create_vols_allerretour();
gtk_widget_hide(window1);
gtk_widget_show(window2);
tree=lookup_widget(window2,"volsdispo_allerretour");
afficher_vols_ar(tree);

}


void
on_supprimer114_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *input101;
GtkWidget *output102;
vole b;
char reference[20];
input101=lookup_widget(objet_graphique,"refvol21");
output102=lookup_widget(objet_graphique,"label1184");
strcpy(reference,gtk_entry_get_text(GTK_ENTRY(input101)));
if(verifier_reference(reference)==0)
gtk_label_set_text(GTK_LABEL(output102),"Vol inexistante");
else
{
supprimer_vols_ar(reference);
gtk_label_set_text(GTK_LABEL(output102),"Vol supprimé");


}
}

void
on_buttonretour156_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *window15,*window16;
GtkWidget *treeview1;
window15=lookup_widget(objet_graphique,"sup_vol");
window16=create_vols_allerretour();
gtk_widget_hide(window15);
gtk_widget_show(window16);
treeview1=lookup_widget(window16,"volsdispo_allerretour");
afficher_vols_ar(treeview1);

}


void
on_buttonmodifier152_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char ref[20];
int test;
vole b;
GtkWidget *input14,*input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*input10,*input11,*input12,*input13;
GtkWidget *window1,*window2;
GtkWidget *output;
window1=lookup_widget(objet_graphique,"modvolar");
window2=create_modvol();
input14=lookup_widget(objet_graphique,"refvol20");
input1=lookup_widget(window2,"depart130");
input2=lookup_widget(window2,"arrivee130");
input3=lookup_widget(window2,"date130");
input4=lookup_widget(window2,"hd130");
input5=lookup_widget(window2,"ha130");
input6=lookup_widget(window2,"depart131");
input7=lookup_widget(window2,"arrivee131");
input8=lookup_widget(window2,"date131");
input9=lookup_widget(window2,"hd131");
input10=lookup_widget(window2,"ha131");
input11=lookup_widget(window2,"com131");
input12=lookup_widget(window2,"prix131");
input13=lookup_widget(window2,"ref131");
output= lookup_widget(objet_graphique,"label1185");
strcpy(ref,gtk_entry_get_text(GTK_ENTRY(input14)));
if (verifier_reference(ref)==0)
gtk_label_set_text(GTK_LABEL(output),"Vol inexistante");
else
{
FILE *f2;
f2=fopen("vols_ar.txt","r"); 
if (f2!=NULL)
{while (fscanf(f2,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",b.depart_aller,b.arrivee_aller,b.date_aller,b.hd_aller,b.ha_aller,b.depart_retour,b.arrivee_retour,b.date_retour,b.hd_retour,b.ha_retour,b.com_aer,b.priix,b.ref_vols)!=EOF)
{if (strcmp(b.ref_vols,ref)==0) 
{ gtk_widget_show(window2);
gtk_entry_set_text(GTK_ENTRY(input1),b.depart_aller) ;
gtk_entry_set_text(GTK_ENTRY(input2),b.arrivee_aller) ;
gtk_entry_set_text(GTK_ENTRY(input3),b.date_aller) ;
gtk_entry_set_text(GTK_ENTRY(input4),b.hd_aller) ;
gtk_entry_set_text(GTK_ENTRY(input5),b.hd_retour) ;
gtk_entry_set_text(GTK_ENTRY(input6),b.depart_retour) ;
gtk_entry_set_text(GTK_ENTRY(input7),b.arrivee_retour) ;
gtk_entry_set_text(GTK_ENTRY(input8),b.date_retour) ;
gtk_entry_set_text(GTK_ENTRY(input9),b.hd_retour) ;
gtk_entry_set_text(GTK_ENTRY(input10),b.ha_retour) ;
gtk_entry_set_text(GTK_ENTRY(input11),b.com_aer) ;
gtk_entry_set_text(GTK_ENTRY(input12),b.priix) ;
gtk_entry_set_text(GTK_ENTRY(input13),b.ref_vols) ;
gtk_widget_hide(window1);
break ;}}
}
fclose(f2);
}}



void
on_buttonretour152_clicked             (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window15,*window16;
GtkWidget *treeview1;
window15=lookup_widget(objet_graphique,"modvolar");
window16=create_vols_allerretour();
gtk_widget_hide(window15);
gtk_widget_show(window16);
treeview1=lookup_widget(window16,"volsdispo_allerretour");
afficher_vols_ar(treeview1);
}


void
on_buttonsupprimer142_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window10,*window11;

window10=lookup_widget(objet_graphique,"vols_allerretour");
window11=create_sup_vol();
gtk_widget_hide(window10);
gtk_widget_show(window11);

}








void
on_treeviewvolsdisponible_row_activated (GtkWidget    *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{gchar *depart;
  	gchar *arrivee;
	gchar *date;
	gchar *heure_dep;
	gchar *heure_arr; 
	gchar *comp;
	gchar *prix;
	gchar *ref;
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *listview;
GtkTreeIter iter;

listview=lookup_widget(objet_graphique,"treeviewvolsdisponible");

window1=lookup_widget(objet_graphique,"vols_disponible_allersimple");
GtkTreeModel *model = gtk_tree_view_get_model (GTK_TREE_VIEW(lookup_widget(objet_graphique,"treeviewvolsdisponible")));
if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&depart,1,&arrivee,2,&date,3,&heure_dep,4,&heure_arr,5,&comp,6,&prix,7,&ref,-1);}
window2=create_info_passagers();
FILE *f;
f=fopen("passagers.txt","a+");
if (f!=NULL)
{ 
fprintf(f,"%s %s %s %s %s %s %s %s ",depart,arrivee,date,heure_dep,heure_arr,comp,prix,ref);
fclose(f);
}
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_volsallerdisponible_row_activated   (GtkWidget *objet_graphique,GtkTreePath *path,GtkTreeViewColumn *column, gpointer  user_data)
{
	{gchar *depart_a;
  	gchar *arrivee_a;
	gchar *date_a;
	gchar *heure_dep_a;
	gchar *heure_arr_a; 
	gchar *depart_r;
	gchar *arrivee_r;
	gchar *date_r;	
	gchar *heure_dep_r;
	gchar *heure_arr_r;
	gchar *comp;
	gchar *prix;
	gchar *ref;
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *listview;
GtkTreeIter iter;

listview=lookup_widget(objet_graphique,"volsallerdisponible");

window1=lookup_widget(objet_graphique,"vols_disponible_aller_retour");
GtkTreeModel *model = gtk_tree_view_get_model (GTK_TREE_VIEW(lookup_widget(objet_graphique,"volsallerdisponible")));
if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&depart_a,1,&arrivee_a,2,&date_a,3,&heure_dep_a,4,&heure_arr_a,5,&depart_r,6,&arrivee_r,7,&date_r,8,&heure_dep_r,9,&heure_arr_r,10,&comp,11,&prix,12,&ref,-1);}
window2=create_passagers_ar();
FILE *f;
f=fopen("pass.txt","a+");
if (f!=NULL)
{ 
fprintf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s ",depart_a,arrivee_a,date_a,heure_dep_a,heure_arr_a,depart_r,arrivee_r,date_r,heure_dep_r,heure_arr_r,comp,prix,ref);
fclose(f);
}
gtk_widget_show(window2);
gtk_widget_hide(window1);
}
}


void
on_buttonretour160_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_confirmerreservation_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *input1,*input2,*input3,*input4,*combobox1,*combobox2,*combobox3;

GtkWidget *window1,*window2;
pass p;
window1=lookup_widget(objet_graphique,"passagers_ar");
window2=create_reservationreussite();
input1=lookup_widget(objet_graphique,"nom111");
input2=lookup_widget(objet_graphique,"prenom111");
input3=lookup_widget(objet_graphique,"nationalite111");
input4=lookup_widget(objet_graphique,"passeport111");
combobox1=lookup_widget(objet_graphique,"jour11");
combobox2=lookup_widget(objet_graphique,"mois11");
combobox3=lookup_widget(objet_graphique,"annee11");

strcpy(p.Nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.Prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.Nat,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(p.Passeport,gtk_entry_get_text(GTK_ENTRY(input4)));
p.dt_naiss.Jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(combobox1));
p.dt_naiss.Mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(combobox2));
p.dt_naiss.Annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(combobox3));
ajouter_pas(p);
gtk_widget_show(window2);
gtk_widget_hide(window1);



}


void
on_radiobuttonalar_toggled           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window10,*window11;
GtkWidget *treev;
window10=lookup_widget(objet_graphique,"liste_des_clients11");
window11=create_clientallerretour();
gtk_widget_hide(window10);
gtk_widget_show(window11);
treev=lookup_widget(window11,"treeviewclinetar");
afficher_client_ar(treev);

}


void
on_retour14111_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_radiobuttonall_toggled              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window10,*window11;
GtkWidget *treeview;
window10=lookup_widget(objet_graphique,"clientallerretour");
window11=create_liste_des_clients11();
gtk_widget_hide(window10);
gtk_widget_show(window11);
treeview=lookup_widget(window11,"liste_des_clients") ; 
afficher_client(treeview);
}










void
on_treeviewclinetar_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
}




void
on_liste_des_clients_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{gchar *Nom;
gchar *Prenom;
gchar *Date;
gchar *nationalite;
gchar *passeport;
gchar *depart;
gchar *arrivee;
gchar *date;
gchar *heure_dep;
gchar *heure_arr; 
gchar *comp;
gchar *prix;
gchar *ref;
GtkTreeIter iter;
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output7;
GtkWidget *output8;
GtkWidget *output9;
GtkWidget *output10;
GtkWidget *output11;
GtkWidget *output12;
GtkWidget *output13;
GtkWidget *window1;
GtkWidget *window2;
window1=lookup_widget(treeview,"liste_des_clients11");
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path))
	{
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&Nom,1,&Prenom,2,&Date,3,&nationalite,4,&passeport,5,&depart,6,&arrivee,7,&date,8,&heure_dep,9,&heure_arr,10,&comp,11,&prix,12,&ref,-1);}
window2 = create_modsuppclien();
gtk_widget_hide (window1);
gtk_widget_show (window2);
output1=lookup_widget(window2,"nom130");
output2=lookup_widget(window2,"prenom130");
output3=lookup_widget(window2,"date666");
output4=lookup_widget(window2,"nat30");
output5=lookup_widget(window2,"pass30");
output6=lookup_widget(window2,"dep30");
output7=lookup_widget(window2,"arr30");
output8=lookup_widget(window2,"dat30");
output9=lookup_widget(window2,"hd366");
output10=lookup_widget(window2,"ha366");
output11=lookup_widget(window2,"comm");
output12=lookup_widget(window2,"prix444");
output13=lookup_widget(window2,"ref444");
gtk_entry_set_text(GTK_ENTRY(output1),Nom);
gtk_entry_set_text(GTK_ENTRY(output2),Prenom);
gtk_entry_set_text(GTK_ENTRY(output3),Date);
gtk_entry_set_text(GTK_ENTRY(output4),nationalite);
gtk_entry_set_text(GTK_ENTRY(output5),passeport);
gtk_entry_set_text(GTK_ENTRY(output6),depart);
gtk_entry_set_text(GTK_ENTRY(output7),arrivee);
gtk_entry_set_text(GTK_ENTRY(output8),date);
gtk_entry_set_text(GTK_ENTRY(output9),heure_dep);
gtk_entry_set_text(GTK_ENTRY(output10),heure_arr);
gtk_entry_set_text(GTK_ENTRY(output11),comp);
gtk_entry_set_text(GTK_ENTRY(output12),prix);
gtk_entry_set_text(GTK_ENTRY(output13),ref);


}


void
on_buttonrrr_enter                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *window1, *window2;
GtkWidget *treeview;
window1=lookup_widget(objet_graphique,"modsuppclien");
gtk_widget_hide(window1);
window2 = create_liste_des_clients11();
gtk_widget_show (window2);
treeview=lookup_widget(window2,"liste_des_clients");
afficher_client(treeview);

}


void
on_buttonmmm_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input14,*input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*input10,*input11,*input12,*input13;
GtkWidget *output;
GtkWidget *window1;
char daaa[20];
passagers v;
window1=lookup_widget(objet_graphique,"modsuppclien");
input1=lookup_widget(objet_graphique,"nom130");
input2=lookup_widget(objet_graphique,"prenom130");
input3=lookup_widget(objet_graphique,"date666");
input4=lookup_widget(objet_graphique,"nat30");
input5=lookup_widget(objet_graphique,"pass30");
input6=lookup_widget(objet_graphique,"dep30");
input7=lookup_widget(objet_graphique,"arr30");
input8=lookup_widget(objet_graphique,"dat30");
input9=lookup_widget(objet_graphique,"hd366");
input10=lookup_widget(objet_graphique,"ha366");
input11=lookup_widget(objet_graphique,"comm");
input12=lookup_widget(objet_graphique,"prix444");
input13=lookup_widget(objet_graphique,"ref444");
output=lookup_widget(objet_graphique,"label1219");
strcpy(v.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(v.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(daaa,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(v.nat,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(v.passeport,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(v.departt,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(v.arrives,gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(v.datte,gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(v.h_dep,gtk_entry_get_text(GTK_ENTRY(input9)));
strcpy(v.h_arr,gtk_entry_get_text(GTK_ENTRY(input10)));
strcpy(v.compagnie,gtk_entry_get_text(GTK_ENTRY(input11)));
strcpy(v.Prix,gtk_entry_get_text(GTK_ENTRY(input12)));
strcpy(v.Ref,gtk_entry_get_text(GTK_ENTRY(input13)));
modifier_client(v,daaa);
gtk_label_set_text(GTK_LABEL(output),"Modifier avec succés") ;
	gtk_entry_set_text(GTK_ENTRY(input1),"");
	gtk_entry_set_text(GTK_ENTRY(input2),"");
	gtk_entry_set_text(GTK_ENTRY(input3),"");
	gtk_entry_set_text(GTK_ENTRY(input4),"");
	gtk_entry_set_text(GTK_ENTRY(input5),"");
	gtk_entry_set_text(GTK_ENTRY(input6),"");
	gtk_entry_set_text(GTK_ENTRY(input7),"");
	gtk_entry_set_text(GTK_ENTRY(input8),"");
	gtk_entry_set_text(GTK_ENTRY(input9),"");
	gtk_entry_set_text(GTK_ENTRY(input10),"");
	gtk_entry_set_text(GTK_ENTRY(input11),"");
	gtk_entry_set_text(GTK_ENTRY(input12),"");
	gtk_entry_set_text(GTK_ENTRY(input13),"");

}


void
on_buttonsss_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *window1,*window9;
GtkWidget *input1;
GtkWidget *treeview;
char pass[20];

window1=lookup_widget(objet_graphique,"modsuppclien");
input1 = lookup_widget(objet_graphique,"pass30");
strcpy(pass, gtk_entry_get_text(GTK_ENTRY(input1)));
supprimer_client(pass);;
window9 = create_liste_des_clients11();
gtk_widget_show(window9);
gtk_widget_hide(window1);
treeview=lookup_widget(window9,"liste_des_clients");
afficher_client(treeview);
}


void
on_rrrr111_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_rech144_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1;
GtkWidget *window1;
GtkWidget *output;
GtkWidget *treeview;
char passeport[20];
int test=0;
window1=lookup_widget(objet_graphique,"liste_des_clients11");
treeview=lookup_widget(objet_graphique,"liste_des_clients");
input1=lookup_widget(objet_graphique,"rechh14");
output=lookup_widget(objet_graphique,"label1223");
strcpy(passeport,gtk_entry_get_text(GTK_ENTRY(input1)));
if(ver_client(passeport)==0)
{gtk_label_set_text(GTK_LABEL(output),"client indisponible");
afficher_client(treeview);}
else {
rechercher_client(treeview,passeport);
gtk_label_set_text(GTK_LABEL(output),"");
}}


void
on_rechercherr144_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *input1;
GtkWidget *window1;
GtkWidget *output;
GtkWidget *treeview;
char ref[20];
int test=0;
window1=lookup_widget(objet_graphique,"liste_des_vols");
treeview=lookup_widget(objet_graphique,"vols_disponible");
input1=lookup_widget(objet_graphique,"ree144");
output=lookup_widget(objet_graphique,"label1222");
strcpy(ref, gtk_entry_get_text(GTK_ENTRY(input1)));

if(ver_vols(ref)==0)
{gtk_label_set_text(GTK_LABEL(output),"vol indisponible");
afficher_vols_agent(treeview);}
else {
rechercher_vols(treeview,ref);
gtk_label_set_text(GTK_LABEL(output),"");
}}


void
on_afficher14_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *treeview;
GtkWidget *window1;
GtkWidget *output;
output=lookup_widget(objet_graphique,"label1222");
window1=lookup_widget(objet_graphique,"liste_des_vols");
treeview=lookup_widget(objet_graphique,"vols_disponible");

afficher_vols_agent(treeview);
gtk_label_set_text(GTK_LABEL(output),"");
}


void
on_AFF144_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *treeview;
GtkWidget *window1;
GtkWidget *output;
window1=lookup_widget(objet_graphique,"liste_des_clients11");
treeview=lookup_widget(objet_graphique,"liste_des_clients");
output=lookup_widget(objet_graphique,"label1223");
afficher_client(treeview);
gtk_label_set_text(GTK_LABEL(output),"");
}


void
on_buttonMODDD_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonSUPP_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Retour1444_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Rechercher447_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *input1;
GtkWidget *window1;
GtkWidget *output;
GtkWidget *treeview;
char ref[20];
int test=0;
window1=lookup_widget(objet_graphique,"vols_allerretour");
treeview=lookup_widget(objet_graphique,"volsdispo_allerretour");
input1=lookup_widget(objet_graphique,"rechercher22");
output=lookup_widget(objet_graphique,"label1244");
strcpy(ref, gtk_entry_get_text(GTK_ENTRY(input1)));

if(ver_volar(ref)==0)
{gtk_label_set_text(GTK_LABEL(output),"vol indisponible");
afficher_vols_ar(treeview);

}
else {
aff_vols_ar(treeview,ref);
gtk_label_set_text(GTK_LABEL(output),"");

}}


void
on_afficher999_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *treeview;
GtkWidget *window1;
GtkWidget *output;
window1=lookup_widget(objet_graphique,"clientallerretour");
treeview=lookup_widget(objet_graphique,"treeviewclinetar");
output=lookup_widget(objet_graphique,"label1247");
afficher_client_ar(treeview);
gtk_label_set_text(GTK_LABEL(output),"");

}


void
on_rech999_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1;
GtkWidget *window1;
GtkWidget *output;
GtkWidget *treeview;
char passeport[20];
int test=0;
window1=lookup_widget(objet_graphique,"clientallerretour");
treeview=lookup_widget(objet_graphique,"treeviewclinetar");
input1=lookup_widget(objet_graphique,"rech99");
output=lookup_widget(objet_graphique,"label1247");
strcpy(passeport,gtk_entry_get_text(GTK_ENTRY(input1)));
if(ver_clienar(passeport)==0)
{gtk_label_set_text(GTK_LABEL(output),"client indisponible");
afficher_client_ar(treeview);}
else {
afficher_client_allerretour(treeview,passeport);
gtk_label_set_text(GTK_LABEL(output),"");
}
}




void
on_afficher400_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *treeview;
GtkWidget *window1;
GtkWidget *output;
output=lookup_widget(objet_graphique,"label1244");

window1=lookup_widget(objet_graphique,"vols_alleretour");
treeview=lookup_widget(objet_graphique,"volsdispo_allerretour");

afficher_client_ar(treeview);
gtk_label_set_text(GTK_LABEL(output),"");


}

