#include <gtk/gtk.h>


int verifier_vols(char dep[],char arr[],char da[]);
void afficher_vols(GtkWidget *liste,char depar[],char arri[],char Dat[]);

void rechercher_vols(GtkWidget *liste,char ref[]);
int ver_vols(char ref[]);

