#include <gtk/gtk.h>

void rechercher_client(GtkWidget *liste,char passeport[]);
int ver_client(char passe[]);
