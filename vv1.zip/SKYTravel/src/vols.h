#include<gtk/gtk.h>

typedef struct
{ 
char depart[20];
char arrivee[20];
char date[50];
char compagnie_aerienne[20];
char heure_depart[20];
char heure_arrivee[20];
char prix[20];
char reference_vols[20];
}vols;

void ajouter_vol(vols v);
void afficher_vols_agent(GtkWidget *liste);
int verifier_ref(char ref[]);
void modifier_vol(vols m);
int supprimer_vols(char vol[]);



