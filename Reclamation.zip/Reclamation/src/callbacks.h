#include <gtk/gtk.h>


void
on_buttonpresedent_clicked             (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_buttonenvoyer_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonpresedent3_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonenvoyer1_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonsupprimer_clicked             (GtkWidget      *objet,
                                        gpointer         user_data);
void
on_buttonretour_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonretour1_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonvalider_clicked               (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_buttonreponder1_clicked             (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_buttonenvoyer2_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonafficher_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonretour4_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonquitter_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonajouter_rec_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonrep_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonafficher4_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonretour5_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);
