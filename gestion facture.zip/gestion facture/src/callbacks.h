#include <gtk/gtk.h>



void
on_buttonretour_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonmodifier_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonretour2_clicked               (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_buttonvalider_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonrefuser_clicked               (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_buttonconfirmer_clicked             (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_buttonajouter_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonafficher_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonconfirmer1_clicked            (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_buttonsupprimer_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttoncomfirmer2_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretour3_clicked               (GtkWidget      *objet_graphique,
                                        gpointer         user_data);


