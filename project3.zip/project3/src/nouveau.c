#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include "nouveau.h"

enum 
{
NOM,
PRENOM,
PHONE,
CIN,
DATE_NAISSANCE,
LIEU_NAISSANCE,
MOT_PASSE1,
MOT_PASSE2,
COLUMNS
};

void ajouter_nouveau (nouveau C)
{
FILE *f;
f=fopen("nouveauclient.txt","a+");
if (f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s %s %s\n",C.nom,C.prenom,C.phone,C.cin,C.date_naissance,C.lieu_naissance,C.mot_passe,C.mot_passe2);
fclose(f);
}}
void ajouter_login()
{
char login[20];
char passe[20];
nouveau C;
FILE *f,*f1;
int role=2;
f=fopen("nouveauclient.txt","r");
f1=fopen("Users.txt","a+");
if ((f!=NULL)&&(f1!=NULL)) 
{
while (fscanf(f,"%s %s %s %s %s %s %s %s\n",C.nom,C.prenom,C.phone,C.cin,C.date_naissance,C.lieu_naissance,C.mot_passe,C.mot_passe2)!=EOF)
{ fprintf(f1,"%s %s %d\n",C.nom,C.mot_passe2,role);
}
fclose(f) ; 
fclose(f1);}}





