#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include "hotelet.h"

enum 
{
CODE1,
DESTINATION,
HOTELSET,
LIEU1,
PRIX1,
COLUMNS
};

void ajouter_ghet (ghet E)
{
FILE *f;
f=fopen("gestion_hotels_ET.txt","a+");
if (f!=NULL)
{
fprintf(f,"%s %s %s %s %s\n",E.code1,E.destination,E.hotelsET,E.lieu1,E.prix1);
fclose(f);
}}
void afficher_ghet(GtkWidget *liste)
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char Code1[20];
char Destination [20];
char HotelsET[20];
char Lieu1[50];
char Prix1[20];
FILE*f;
store==NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("code1",renderer,"text",CODE1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("destination",renderer,"text",DESTINATION,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("hotelsET",renderer,"text",HOTELSET,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("lieu1",renderer,"text",LIEU1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("prix1",renderer,"text",PRIX1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

}
store=gtk_list_store_new (5, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f = fopen("gestion_hotels_ET.txt","r");
if (f==NULL)
{ return; }
else 
{ 
f= fopen("gestion_hotels_ET.txt","a+");
while (fscanf(f,"%s %s %s %s %s \n",Code1,Destination,HotelsET,Lieu1,Prix1)!=EOF)
{ 
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,CODE1,Code1,DESTINATION,Destination,HOTELSET,HotelsET,LIEU1,Lieu1,PRIX1,Prix1,-1);}
fclose(f);
}
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}

int verifier_ref2(char ref2[])
{ghet m;
FILE *f;
int test = 0 ; 
f=fopen("gestion_hotels_ET.txt","r");
if(f!=NULL) { 
while(fscanf(f,"%s %s %s %s %s\n",m.code1,m.destination,m.hotelsET,m.lieu1,m.prix1)!=EOF) 
{ 
if((strcmp(m.code1,ref2)==0))
test=1 ;
 } }
fclose(f);
 
return test;
}

void modifier_ghet(ghet m)
{
ghet a ;
FILE *f;
FILE *f2;
f=fopen("gestion_hotels_ET.txt","r");
f2=fopen("hotel_tmp2.txt","a+"); 
if (f!=NULL)
{
if (f2!=NULL)

{ 
     while (fscanf(f,"%s %s %s %s %s\n",a.code1,a.destination,a.hotelsET,a.lieu1,a.prix1)!=EOF)
    { 
	if (strcmp(a.code1,m.code1)==0)
{    fprintf(f2,"%s %s %s %s %s\n",m.code1,m.destination,m.hotelsET,m.lieu1,m.prix1);
}
	else 	
{	    fprintf(f2,"%s %s %s %s %s\n",a.code1,a.destination,a.hotelsET,a.lieu1,a.prix1);
     }

}}
fclose(f2);
fclose(f);
remove("gestion_hotels_ET.txt");
rename("hotel_tmp2.txt","gestion_hotels_ET.txt");

}
}

int supprimer_ghet(char H[])
{
FILE *f,*f1;
ghet r;
 
f=fopen("gestion_hotels_ET.txt","r"); 
f1=fopen("tmp2.txt","w");
 if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f,"%s %s %s %s %s\n",r.code1,r.destination,r.hotelsET,r.lieu1,r.prix1)!=EOF) 
{
if(strcmp(H,r.code1)!=0)
{
fprintf(f1,"%s %s %s %s %s\n",r.code1,r.destination,r.hotelsET,r.lieu1,r.prix1);
}}
fclose(f) ; 
fclose(f1);}
 
f=fopen("gestion_hotels_ET.txt","w"); 
f1=fopen("tmp2.txt","r");
if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f1,"%s %s %s %s %s\n",r.code1,r.destination,r.hotelsET,r.lieu1,r.prix1)!=EOF) 
{
if(strcmp(H,r.code1)!=0)
{
fprintf(f,"%s %s %s %s %s\n",r.code1,r.destination,r.hotelsET,r.lieu1,r.prix1);
}}
fclose(f) ; 
fclose(f1);
}}
