#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include "hoteltn_c.h"
#include "hoteltn.h"

enum 
{
CODE,
HOTELSTN,
LIEU,
PRIX,
COLUMNS
};

int verifier_reflieu(char reflieu[])
{ghtn m;
FILE *f;
int test = 0 ; 
f=fopen("gestion_hotels_TN.txt","r");
if(f!=NULL) { 
while(fscanf(f,"%s %s %s %s\n",m.code,m.hotelsTN,m.lieu,m.prix)!=EOF) 
{ 
if((strcmp(m.lieu,reflieu)==0))
test=1 ;
 } }
fclose(f);
 
return test;
}

void afficher_ghtnc(GtkWidget *liste, char L[])
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char Code[20];
char HotelsTN[20];
char Lieu[50];
char Prix[20];
FILE*f;
store==NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("code",renderer,"text",CODE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("hotelsTN",renderer,"text",HOTELSTN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("lieu",renderer,"text",LIEU,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("prix",renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

}
store=gtk_list_store_new (4, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f = fopen("gestion_hotels_TN.txt","r");
if (f==NULL)
{ return; }
else 
{ 
f= fopen("gestion_hotels_TN.txt","a+");
while (fscanf(f,"%s %s %s %s \n",Code,HotelsTN,Lieu,Prix)!=EOF)
{ 
if (strcmp(Lieu,L)==0)
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,CODE,Code,HOTELSTN,HotelsTN,LIEU,Lieu,PRIX,Prix,-1);}
fclose(f);
}
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}

