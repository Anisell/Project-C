
#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include "hoteltn.h"

enum 
{
CODE,
HOTELSTN,
LIEU,
PRIX,
COLUMNS
};

void ajouter_ghtn (ghtn T)
{
FILE *f;
f=fopen("gestion_hotels_TN.txt","a+");
if (f!=NULL)
{
fprintf(f,"%s %s %s %s\n",T.code,T.hotelsTN,T.lieu,T.prix);
fclose(f);
}}
void afficher_ght(GtkWidget *liste)
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char Code[20];
char HotelsTN[20];
char Lieu[50];
char Prix[20];
FILE*f;
store==NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("code",renderer,"text",CODE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("hotelsTN",renderer,"text",HOTELSTN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("lieu",renderer,"text",LIEU,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("prix",renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

}
store=gtk_list_store_new (4, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f = fopen("gestion_hotels_TN.txt","r");
if (f==NULL)
{ return; }
else 
{ 
f= fopen("gestion_hotels_TN.txt","a+");
while (fscanf(f,"%s %s %s %s \n",Code,HotelsTN,Lieu,Prix)!=EOF)
{ 
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,CODE,Code,HOTELSTN,HotelsTN,LIEU,Lieu,PRIX,Prix,-1);}
fclose(f);
}
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}




int verifier_ref(char ref[])
{ghtn m;
FILE *f;
int test = 0 ; 
f=fopen("gestion_hotels_TN.txt","r");
if(f!=NULL) { 
while(fscanf(f,"%s %s %s %s\n",m.code,m.hotelsTN,m.lieu,m.prix)!=EOF) 
{ 
if((strcmp(m.code,ref)==0))
test=1 ;
 } }
fclose(f);
 
return test;
}

void modifier_ghtn(ghtn m)
{
ghtn a ;
FILE *f;
FILE *f2;
f=fopen("gestion_hotels_TN.txt","r");
f2=fopen("hotel_tmp.txt","a+"); 
if (f!=NULL)
{
if (f2!=NULL)

{ 
     while (fscanf(f,"%s %s %s %s\n",a.code,a.hotelsTN,a.lieu,a.prix)!=EOF)
    { 
	if (strcmp(a.code,m.code)==0)
{    fprintf(f2,"%s %s %s %s\n",m.code,m.hotelsTN,m.lieu,m.prix);
}
	else 	
{	    fprintf(f2,"%s %s %s %s\n",a.code,a.hotelsTN,a.lieu,a.prix);
     }

}}
fclose(f2);
fclose(f);
remove("gestion_hotels_TN.txt");
rename("hotel_tmp.txt","gestion_hotels_TN.txt");

}
}

int supprimer_ghtn(char H[])
{
FILE *f,*f1;
ghtn r;
 
f=fopen("gestion_hotels_TN.txt","r"); 
f1=fopen("tmp.txt","w");
 if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f,"%s %s %s %s\n",r.code,r.hotelsTN,r.lieu,r.prix)!=EOF) 
{
if(strcmp(H,r.code)!=0)
{
fprintf(f1,"%s %s %s %s\n",r.code,r.hotelsTN,r.lieu,r.prix);
}}
fclose(f) ; 
fclose(f1);}
 
f=fopen("gestion_hotels_TN.txt","w"); 
f1=fopen("tmp.txt","r");
if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f1,"%s %s %s %s\n",r.code,r.hotelsTN,r.lieu,r.prix)!=EOF) 
{
if(strcmp(H,r.code)!=0)
{
fprintf(f,"%s %s %s %s\n",r.code,r.hotelsTN,r.lieu,r.prix);
}}
fclose(f) ; 
fclose(f1);
}}
