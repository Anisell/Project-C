#include <gtk/gtk.h>


void
on_Quitte_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_H__bergement_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Vols_clicked                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Voyage_Organis___clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Promo_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_E_Ticket_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Location_des_voitures_clicked       (GtkWidget      *objet_graphique,
                                        gpointer         user_data);



void
on_Contact_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Se_connecter_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Quitte1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_Valider_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Mot_de_passe_oublier_clicked        (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_Cr__e_un_nouveau_compte_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Quitte2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Quitte3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Hotels_en_Tunisie_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_Hotels____l___trang__re_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Envoyer_clicked                     (GtkButton       *button,
                                        gpointer         user_data);



void
on_Quitte5_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Valider1_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_Quitte6_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Valider2_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Quitte7_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Valider3_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Valider4_clicked                    (GtkButton       *button,
                                        gpointer         user_data);


void
on_Quitte9_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_valider5_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_gestion_Hotels_TN_clicked           (GtkWidget       *onjet_graphique,
                                        gpointer         user_data);


void
on_gestion_hotels_ET_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Quitte10_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Quitter11_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Supprimer_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Ajouter_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_valider6_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_Quitte12_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Valider7_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_Supprimer1_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifier1_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ajouter1_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_Quitte13_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Valider8_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifer2_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Supprimer2_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Ajouter2_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_quittecode_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_validercode_clicked                 (GtkButton       *button,
                                        gpointer         user_data);


                                      
void
on_Contactclient_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_Localition_des_voituresclient_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_E_Ticketclient_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_Promoclient_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_Voyage_Organiseclient_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Volsclient_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_Hebergementclient_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Quitteclient_clicked                (GtkWidget      *objet_graphique,
                                        gpointer         user_data);


void
on_quitte_sky_agent_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_contact_sky_agent_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_Hebergement_sky_agnet_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_vols_sky_agent_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_voyage_sky_agent_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_location_sky_agent_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_ticket_sky_agent_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_promo_sky_agent_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_hebergement_sky_admin_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_voks_sky_admin_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_quiite_sky_admin_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_voyage_sky_admin_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_promo_sky_admin_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_ticket_sky_admin_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_location_sky_admin_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_espace_admin_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_contact_sky_admin_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_Quitte_ajout_TN_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Done_clicked                        (GtkButton       *button,
                                        gpointer         user_data);


void
on_quitte_ajout_ET_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ajout_ET3_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_confirmer_ghtn_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_quitte_ghtn_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_validation_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_validation_ghtn_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_quitte_validation_ghtn_clicked      (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_supprimercode_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_quittesupp_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_confirmation_ghet_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_quitte_ghet_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_cofirmation_codeET_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_quitte_codeET_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitte_v_ghet_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_confirmation_v_ghet_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_codeETS_confirmation_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_codeETS_quitte_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_RS_quitte_hotel_tunis_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ajouter1000000_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeviewhh_row_activated            (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_afficher_reservationTN_clicked      (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button1666_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_quittefinal_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_suppfinal_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_modfinal_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_supp_re_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_quitte_RE_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitte152478_clicked                (GtkButton       *button,
                                        gpointer         user_data);
