#include<stdio.h>
#include<string.h>
#include"clienttn.h"
#include <gtk/gtk.h>
enum 
{
CODE,
NOM,
PRENOM,
DT_D,
DT_R,
NB,
NBC,
HOTEL,
LIEUX,
PRIX,
COLUMNS
};


void ajouter_clienttn(clienttn p)
{FILE *f;
f=fopen("clienttunis.txt","a+");
if (f!=NULL)
{ 
fprintf(f,"%s %s %d/%d/%d %d/%d/%d %d %d\n",p.nom,p.prenom,p.dt_d.jour,p.dt_d.mois,p.dt_d.annee,p.dt_r.jour,p.dt_r.mois,p.dt_r.annee,p.nb,p.nbc);
fclose(f);
}
}



int verifier_nom(char N[])
{
FILE *f;
char code[20];
char nom[20];
char prenom[20];
char Date1[50];
char Date2[50];
char nb[20];
char nbc[20];
char hotel[20];
char lieux[20];
char prix[20];
int test = 0 ; 
f=fopen("clienttunis.txt","r");
if(f!=NULL) { 
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s\n",code,hotel,lieux,prix,nom,prenom,Date1,Date2,nb,nbc)!=EOF) 
{ 
if((strcmp(nom,N)==0))
test=1 ;
 } }
fclose(f);
 
return test;
}



void afficher_client1(GtkWidget *liste,char x[])
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char code[20];
char nom[20];
char prenom[20];
char Date1[50];
char Date2[50];
char nb[20];
char nbc[20];
char hotel[20];
char lieux[20];
char prix[20];

FILE*f;
store==NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("code",renderer,"text",CODE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date_depart",renderer,"text",DT_D,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date_retour",renderer,"text",DT_R,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("nombre de personne",renderer,"text",NB,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("nombre de chambre",renderer,"text",NBC,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("hotel",renderer,"text",HOTEL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("lieu",renderer,"text",LIEUX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("prix",renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);




}
store=gtk_list_store_new (10, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING);
f = fopen("clienttunis.txt","r");
if (f==NULL)
{ return; }
else 
{ 
f= fopen("clienttunis.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s\n",code,hotel,lieux,prix,nom,prenom,Date1,Date2,nb,nbc)!=EOF)
{ 
if (strcmp(nom,x)==0)
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,CODE,code,NOM,nom,PRENOM,prenom,DT_D,Date1,DT_R,Date2,NB,nb,NBC,nbc,HOTEL,hotel,LIEUX,lieux,PRIX,prix,-1);}
fclose(f);}
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}

/*int supprimer_client(char R[])
{
FILE *f,*f1;
clienttn r;
 
f=fopen("clienttunis.txt","r"); 
f1=fopen("tmp3.txt","w");
 if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f,"%s %s %s %s %d %d\n",r.nom,r.prenom,r.dt_d,r.dt_r,r.nb,r.nbc)!=EOF) 
{
if(strcmp(R,r.nom)!=0)
{
fprintf(f1,"%s %s %s %s %d %d\n",r.nom,r.prenom,r.dt_d,r.dt_r,r.nb,r.nbc);
}}
fclose(f) ; 
fclose(f1);}
 
f=fopen("clienttunis.txt","w"); 
f1=fopen("tmp3.txt","r");
if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f1,"%s %s %s %s %d %d\n",r.nom,r.prenom,r.dt_d,r.dt_r,r.nb,r.nbc)!=EOF) 
{
if(strcmp(R,r.nom)!=0)
{
fprintf(f,"%s %s %s %s %d %d\n",r.nom,r.prenom,r.dt_d,r.dt_r,r.nb,r.nbc);
}}
fclose(f) ; 
fclose(f1);
}}*/

