#include <gtk/gtk.h>


int verifier_reflieu(char reflieu[]);
void afficher_ghtnc(GtkWidget *liste,char L []);

