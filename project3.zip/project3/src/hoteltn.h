#include <gtk/gtk.h>


typedef struct
{

char code [20];
char hotelsTN [20];
char lieu [20];
char prix[20];

}ghtn;

void ajouter_ghtn(ghtn T);
void afficher_ght(GtkWidget *liste);
int verifier_ref(char ref[]);
void modifier_ghtn(ghtn m);
int supprimer_ghtn(char H[]);


