#include<gtk/gtk.h>
typedef struct
{
int jour;
int mois;
int annee;
}date;

typedef struct
{
char nom[20];
char prenom[20];
date dt_d;
date dt_r;
int nb;
int nbc;
}clienttn;

void ajouter_clienttn(clienttn p);
void afficher_clienttn(GtkWidget *liste);
int verifier_nom(char N[]);
void afficher_client1(GtkWidget *liste, char x[]);

