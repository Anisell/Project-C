#include <gtk/gtk.h>


typedef struct
{

char nom [20];
char prenom [20];
char phone [20];
char cin [20];
char date_naissance[20];
char lieu_naissance[20];
char mot_passe[20];
char mot_passe2[20];
 
}nouveau;

void ajouter_nouveau(nouveau C);
void ajouter_login();

