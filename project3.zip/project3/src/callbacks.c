#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdio.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "hoteltn.h"
#include "hotelet.h"
#include "hoteltn_c.h"
#include "clienttn.h"
#include "nouveau.h"

int verifier(char username [], char password [])
{
FILE*f;
int r;
int a=0;
char user[20],pass[20];
f=fopen("Users.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %s %d\n",user,pass,&r)!=EOF){
if((strcmp(username,user)==0) && (strcmp(password,pass)==0))
{a=r;}

}}
fclose(f);
return (a) ;
}

void
on_Quitte_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_H__bergement_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Sky_Travel");
window2=create_Se_connecter();
gtk_widget_show(window2);
gtk_widget_hide(window2);
}


void
on_Vols_clicked                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Sky_Travel");
window2=create_Se_connecter();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_Voyage_Organis___clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Sky_Travel");
window2=create_Se_connecter();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_Promo_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Sky_Travel");
window2=create_Se_connecter();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_E_Ticket_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Sky_Travel");
window2=create_Se_connecter();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_Location_des_voitures_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Sky_Travel");

window2=create_Se_connecter();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}





void
on_Contact_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Sky_Travel");
window2=create_Contact();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_Se_connecter_clicked                (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Sky_Travel");
window2=create_Se_connecter();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_Quitte1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Contact");
window2=create_Sky_Travel();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}





void
on_Valider_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{


        GtkWidget *input1,*input2, *output;
	GtkWidget *window1, *window2, *window3;
	int role=0;
	int a=0;
	char username[20], password[20];

	output=lookup_widget(objet_graphique,"labelError");
	window1=lookup_widget(objet_graphique,"Se_connecter");
	input1 = lookup_widget(objet_graphique, "entryUsername");
	input2 = lookup_widget(objet_graphique, "entryPassword");

	strcpy(username, gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(password, gtk_entry_get_text(GTK_ENTRY(input2)));
	role=verifier(username,password);
		if(role == 0)
		{
		gtk_label_set_text(GTK_LABEL(output),"mot de passe ou nom d'utilisateur incorrect");
		gtk_entry_set_text(GTK_ENTRY(input1),"");
		gtk_entry_set_text(GTK_ENTRY(input2),"");
		}
		else if (role == 1)
		{
		
		window2 = create_Sky_travel_admin();
		gtk_widget_show (window2);
		gtk_widget_hide (window1);
		}
		else if (role == 2)
		{
		
		window2 = create_Sky_travel_client();
		gtk_widget_show (window2);
		gtk_widget_hide (window1);
		}
		else if (role == 3)
		{
		
		window3 = create_Sky_travel_agent();
		gtk_widget_show (window3);
		gtk_widget_hide (window1);
		}
}
	


void
on_Mot_de_passe_oublier_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Se_connecter");
window2=create_Mot_de_passe_oublier_();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_Cr__e_un_nouveau_compte_clicked     (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{


GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Se_connecter");
window2=create_Nouveau_Compte();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_Quitte2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Se_connecter");
window2=create_Sky_Travel();
gtk_widget_show(window2);
gtk_widget_hide(window1);

}


void
on_Quitte3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Hebergement");
window2=create_Sky_travel_client();
gtk_widget_show(window2);
gtk_widget_hide(window1);

}

void
on_Hotels_en_Tunisie_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Hebergement");
window2=create_Recherche_hotels_en_Tunisie();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}





void
on_Hotels____l___trang__re_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Hebergement");
window2=create_Hotels_etrangere_();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_Envoyer_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Quitte5_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Mot_de_passe_oublier");
window2=create_Se_connecter();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_Valider1_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Quitte6_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Nouveau_Compte");
window2=create_Se_connecter();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_Valider2_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
nouveau C;

GtkWidget *input1, *input2, *input3, *input4, *input5, *input6, *input7, *input8;
GtkWidget *output;
GtkWidget *window;


window=lookup_widget(objet_graphique,"Se_connecter");

input1=lookup_widget(objet_graphique,"entry14");
input2=lookup_widget(objet_graphique,"entry13");
input3=lookup_widget(objet_graphique,"entry30");
input4=lookup_widget(objet_graphique,"entry15");
input5=lookup_widget(objet_graphique,"entry86");
input6=lookup_widget(objet_graphique,"entry17");
input7=lookup_widget(objet_graphique,"entry18");
input8=lookup_widget(objet_graphique,"entry19");
output=lookup_widget(objet_graphique,"label164");
strcpy(C.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(C.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(C.phone,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(C.cin,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(C.date_naissance,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(C.lieu_naissance,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(C.mot_passe,gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(C.mot_passe2,gtk_entry_get_text(GTK_ENTRY(input8)));
gtk_label_set_text(GTK_LABEL(output),"bienvenue a Sky Travel");

ajouter_nouveau(C);
ajouter_login();

}


void
on_Quitte7_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"hotels_en_Tunisie");
window2=create_Hebergement();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_Valider3_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *input1;
GtkWidget *treeview1;
GtkWidget *output;
ghtn m;
char LL[20];
int test;
window1=lookup_widget(objet_graphique,"Recherche_hotels_en_Tunisie");
window2=create_RS_hotel_en_Tunisie();
input1=lookup_widget(objet_graphique,"entry20");
output=lookup_widget(objet_graphique,"label155");
strcpy(LL,gtk_entry_get_text(GTK_ENTRY(input1)));
if (verifier_reflieu(LL)==0)
gtk_label_set_text(GTK_LABEL(output),"hotels indisponible");
else {
FILE *f1;
f1=fopen("gestion_hotels_TN.txt","r"); 
if (f1!=NULL)
{
while (fscanf(f1,"%s %s %s %s\n",m.code,m.hotelsTN,m.lieu,m.prix)!=EOF)
{if ((strcmp(m.lieu,LL)==0))
{gtk_widget_show(window2);
gtk_widget_hide(window1);
treeview1=lookup_widget(window2,"treeviewhh");
afficher_ghtnc(treeview1,LL);
break;}}}
fclose(f1);
}
}


void
on_Valider4_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}




void
on_Quitte9_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"hotels_etrangere");
window2=create_Hebergement();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_valider5_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_gestion_Hotels_TN_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *treeview1;

window1=lookup_widget(objet_graphique,"Hebergement_Agent");


window2=create_Getion_hotels_TN();
gtk_widget_show(window2);
gtk_widget_hide(window1);
treeview1=lookup_widget(window2,"treeview1");

afficher_ght(treeview1);
}




void
on_gestion_hotels_ET_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *treeview2;

window1=lookup_widget(objet_graphique,"Hebergement_Agent");
window2=create_Gestion_hotels_ET();
gtk_widget_show(window2);
gtk_widget_hide(window1);

treeview2=lookup_widget(window2,"treeview2");

afficher_ghet(treeview2);
}


void
on_Quitte10_clicked                    (GtkWidget       *objet_graphique ,
                                        gpointer         user_data)
{
GtkWidget *Hebergement_agent;
GtkWidget *Sky_travel_agent;

Hebergement_agent=lookup_widget(objet_graphique,"Hebergement_agent");
gtk_widget_destroy(Hebergement_agent);
Sky_travel_agent=lookup_widget(objet_graphique,"Sky_travel_agent");
Sky_travel_agent=create_Sky_travel_agent();
gtk_widget_show(Sky_travel_agent);
}


void
on_Quitter11_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Gestion_hotels_TN;
GtkWidget *Hebergement_Agent;

Gestion_hotels_TN=lookup_widget(objet_graphique,"Gestion_hotels_TN");
gtk_widget_destroy(Gestion_hotels_TN);
Hebergement_Agent=lookup_widget(objet_graphique,"Hebergement_Agent");
Hebergement_Agent=create_Hebergement_Agent();
gtk_widget_show(Hebergement_Agent);
}


void
on_modifier_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
window1=lookup_widget(objet_graphique,"Getion_hotels_TN");
window2=create_codetn();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_Supprimer_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Getion_hotels_TN");
window2=create_codetns();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_Ajouter_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Getion_hotels_TN");
window2=create_ajout_ghtn();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}



void
on_valider6_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Quitte12_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Gestion_maison_d_hotes;
GtkWidget *Hebergement_Agent;

Gestion_maison_d_hotes=lookup_widget(objet_graphique,"Gestion_maison_d_hotes");
gtk_widget_destroy(Gestion_maison_d_hotes);
Hebergement_Agent=lookup_widget(objet_graphique,"Hebergement_Agent");
Hebergement_Agent=create_Hebergement_Agent();
gtk_widget_show(Hebergement_Agent);
}


void
on_Valider7_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Supprimer1_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Modifier1_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Ajouter1_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Quitte13_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Gestion_hotels_ET;
GtkWidget *Hebergement_Agent;

Gestion_hotels_ET=lookup_widget(objet_graphique,"Gestion_hotels_ET");
gtk_widget_destroy(Gestion_hotels_ET);
Hebergement_Agent=lookup_widget(objet_graphique,"Hebergement_Agent");
Hebergement_Agent=create_Hebergement_Agent();
gtk_widget_show(Hebergement_Agent);
}


void
on_Valider8_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_modifer2_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
window1=lookup_widget(objet_graphique,"Gestion_hotels_ET");
window2=create_codeET();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_Supprimer2_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Gestion_hotels_ET");
window2=create_codeETS();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_Ajouter2_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Gestion_hotels_ET");
window2=create_ajout_ghet();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_quittecode_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *code_envoyer;
GtkWidget *Mot_de_passe_oublier;

code_envoyer=lookup_widget(objet_graphique,"code_envoyer");
gtk_widget_destroy(code_envoyer);
Mot_de_passe_oublier=lookup_widget(objet_graphique,"Mot_de_passe_oublier");
Mot_de_passe_oublier=create_Mot_de_passe_oublier_();
gtk_widget_show(Mot_de_passe_oublier);
}

void
on_validercode_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
}






void
on_Contactclient_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Sky_travel_client;
GtkWidget *Contact;

Sky_travel_client=lookup_widget(objet_graphique,"Sky_travel_client");
gtk_widget_destroy(Sky_travel_client);
Contact=lookup_widget(objet_graphique,"Contact");
Contact=create_Contact();
gtk_widget_show(Contact);
gtk_widget_hide(Sky_travel_client);
}






void
on_Localition_des_voituresclient_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_E_Ticketclient_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Promoclient_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Voyage_Organiseclient_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Volsclient_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Hebergementclient_clicked           (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Sky_travel_client;
GtkWidget *Hebergement;

Sky_travel_client=lookup_widget(objet_graphique,"Sky_travel_client");
gtk_widget_destroy(Sky_travel_client);
Hebergement=lookup_widget(objet_graphique,"Hebergement");
Hebergement=create_Hebergement();
gtk_widget_show(Hebergement);
gtk_widget_hide(Sky_travel_client);
}


void
on_Quitteclient_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Sky_travel_client;
GtkWidget *Se_connecter;

Sky_travel_client=lookup_widget(objet_graphique,"Sky_travel_client");
gtk_widget_destroy(Sky_travel_client);
Se_connecter=lookup_widget(objet_graphique,"Se_connecter");
Se_connecter=create_Se_connecter();
gtk_widget_show(Se_connecter);
}





void
on_quitte_sky_agent_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Sky_travel_agent;
GtkWidget *Se_connecter;

Sky_travel_agent=lookup_widget(objet_graphique,"Sky_travel_agent");
gtk_widget_destroy(Sky_travel_agent);
Se_connecter=lookup_widget(objet_graphique,"Se_connecter");
Se_connecter=create_Se_connecter();
gtk_widget_show(Se_connecter);
}


void
on_contact_sky_agent_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Hebergement_sky_agnet_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Sky_travel_agent;
GtkWidget *Hebergement_Agent;

Sky_travel_agent=lookup_widget(objet_graphique,"Sky_travel_agent");
gtk_widget_destroy(Sky_travel_agent);
Hebergement_Agent=lookup_widget(objet_graphique,"Hebergement_Agent");
Hebergement_Agent=create_Hebergement_Agent();
gtk_widget_show(Hebergement_Agent);
}


void
on_vols_sky_agent_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_voyage_sky_agent_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_location_sky_agent_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ticket_sky_agent_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_promo_sky_agent_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_hebergement_sky_admin_clicked       (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Sky_travel_admin");
window2=create_Hebergement_Agent();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_voks_sky_admin_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_quiite_sky_admin_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"Sky_travel_admin");
window2=create_Se_connecter();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_voyage_sky_admin_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_promo_sky_admin_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ticket_sky_admin_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_location_sky_admin_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_espace_admin_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_contact_sky_admin_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Quitte_ajout_TN_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"fenetre_ajout_TN");
window2=create_Getion_hotels_TN();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_Done_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{

}








void
on_quitte_ajout_ET_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout_ET;
GtkWidget *Gestion_hotels_ET;

fenetre_ajout_ET=lookup_widget(objet_graphique,"fenetre_ajout_ET");
gtk_widget_destroy(fenetre_ajout_ET);
Gestion_hotels_ET=lookup_widget(objet_graphique,"Gestion_hotels_ET");
Gestion_hotels_ET=create_Gestion_hotels_ET();
gtk_widget_show(Gestion_hotels_ET);
}


void
on_ajout_ET3_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_confirmer_ghtn_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
ghtn T;

GtkWidget *input1, *input2, *input3, *input4;
GtkWidget *output;
GtkWidget *window;


window=lookup_widget(objet_graphique,"ajout_ghtn");


input1=lookup_widget(objet_graphique,"entry59");
input2=lookup_widget(objet_graphique,"entry60");
input3=lookup_widget(objet_graphique,"entry61");
input4=lookup_widget(objet_graphique,"entry62");
output=lookup_widget(objet_graphique,"label123");
strcpy(T.code,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(T.hotelsTN,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(T.lieu,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(T.prix,gtk_entry_get_text(GTK_ENTRY(input4)));
gtk_label_set_text(GTK_LABEL(output),"ajouter avec succée");

ajouter_ghtn(T);

}


void
on_quitte_ghtn_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *treeview1;

window1=lookup_widget(objet_graphique,"ajout_ghtn");
window2=create_Getion_hotels_TN();
gtk_widget_show(window2);
gtk_widget_hide(window1);
treeview1=lookup_widget(window2,"treeview1");

afficher_ght(treeview1);
}

void
on_validation_clicked                  (GtkWidget       *objet_graphique,
						gpointer         user_data)
{
char ref[20];
int test;
ghtn T;
GtkWidget *input14,*input1,*input2,*input3,*input4;
GtkWidget *window1,*window2;
GtkWidget *output;
window1=lookup_widget(objet_graphique,"codetn");
window2=create_v_ghtn();
input14=lookup_widget(objet_graphique,"entry63");
input1=lookup_widget(window2,"entry64");
input2=lookup_widget(window2,"entry65");
input3=lookup_widget(window2,"entry66");
input4=lookup_widget(window2,"entry67");

output= lookup_widget(objet_graphique,"ERREUR");
strcpy(ref,gtk_entry_get_text(GTK_ENTRY(input14)));
if (verifier_ref(ref)==0)
gtk_label_set_text(GTK_LABEL(output),"hotel inexistante");
else
{
FILE *f2;
f2=fopen("gestion_hotels_TN.txt","r"); 
if (f2!=NULL)
{while (fscanf(f2,"%s %s %s %s \n",T.code,T.hotelsTN,T.lieu,T.prix)!=EOF)
{if (strcmp(T.code,ref)==0) 
{ gtk_widget_show(window2);
gtk_entry_set_text(GTK_ENTRY(input1),T.code) ;
gtk_entry_set_text(GTK_ENTRY(input2),T.hotelsTN) ;
gtk_entry_set_text(GTK_ENTRY(input3),T.lieu) ;
gtk_entry_set_text(GTK_ENTRY(input4),T.prix) ;

gtk_widget_hide(window1);
break ;}}
}
fclose(f2);
} }                                     
void
on_validation_ghtn_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
ghtn T;
GtkWidget *input1,*input2,*input3,*input4;
GtkWidget *output;
input1=lookup_widget(objet_graphique,"entry64");
input2=lookup_widget(objet_graphique,"entry65");
input3=lookup_widget(objet_graphique,"entry66");
input4=lookup_widget(objet_graphique,"entry67");
output=lookup_widget(objet_graphique,"succes");
strcpy(T.code,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(T.hotelsTN,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(T.lieu,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(T.prix,gtk_entry_get_text(GTK_ENTRY(input4)));

modifier_ghtn(T);
gtk_label_set_text(GTK_LABEL(output),"modifié avec succés") ;
}


void
on_quitte_validation_ghtn_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *treeview1;

window1=lookup_widget(objet_graphique,"v_ghtn");
window2=create_Getion_hotels_TN();
gtk_widget_show(window2);
gtk_widget_hide(window1);
treeview1=lookup_widget(window2,"treeview1");

afficher_ght(treeview1);
}


void
on_supprimercode_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1;
GtkWidget *output2;
ghtn b;
char reference[20];
input1=lookup_widget(objet_graphique,"entry68");
output2=lookup_widget(objet_graphique,"label125");
strcpy(reference,gtk_entry_get_text(GTK_ENTRY(input1)));
if(verifier_ref(reference)==0)
gtk_label_set_text(GTK_LABEL(output2),"hotel inexistante");
else
{
supprimer_ghtn(reference);
gtk_label_set_text(GTK_LABEL(output2),"hotel supprimé");
}
}

void
on_quittesupp_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *treeview1;

window1=lookup_widget(objet_graphique,"codetns");
window2=create_Getion_hotels_TN();
gtk_widget_show(window2);
gtk_widget_hide(window1);
treeview1=lookup_widget(window2,"treeview1");

afficher_ght(treeview1);
}


void
on_confirmation_ghet_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
ghet E;

GtkWidget *input1, *input2, *input3, *input4, *input5;
GtkWidget *output;
GtkWidget *window;


window=lookup_widget(objet_graphique,"ajout_ghet");


input1=lookup_widget(objet_graphique,"entry69");
input2=lookup_widget(objet_graphique,"entry70");
input3=lookup_widget(objet_graphique,"entry71");
input4=lookup_widget(objet_graphique,"entry72");
input5=lookup_widget(objet_graphique,"entry73");
output=lookup_widget(objet_graphique,"label132");
strcpy(E.code1,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(E.destination,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(E.hotelsET,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(E.lieu1,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(E.prix1,gtk_entry_get_text(GTK_ENTRY(input5)));
gtk_label_set_text(GTK_LABEL(output),"ajouter avec succée");

ajouter_ghet(E);
}


void
on_quitte_ghet_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *treeview2;

window1=lookup_widget(objet_graphique,"ajout_ghet");
window2=create_Gestion_hotels_ET();
gtk_widget_show(window2);
gtk_widget_hide(window1);
treeview2=lookup_widget(window2,"treeview2");

afficher_ghet(treeview2);
}


void
on_cofirmation_codeET_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char ref2[20];
int test;
ghet E;
GtkWidget *input14,*input1,*input2,*input3,*input4, *input5;
GtkWidget *window1,*window2;
GtkWidget *output;
window1=lookup_widget(objet_graphique,"codeET");
window2=create_v_ghet();
input14=lookup_widget(objet_graphique,"entry74");
input1=lookup_widget(window2,"entry75");
input2=lookup_widget(window2,"entry76");
input3=lookup_widget(window2,"entry77");
input4=lookup_widget(window2,"entry78");
input5=lookup_widget(window2,"entry79");

output= lookup_widget(objet_graphique,"label142");
strcpy(ref2,gtk_entry_get_text(GTK_ENTRY(input14)));
if (verifier_ref2(ref2)==0)
gtk_label_set_text(GTK_LABEL(output),"hotel inexistante");
else
{
FILE *f2;
f2=fopen("gestion_hotels_ET.txt","r"); 
if (f2!=NULL)
{while (fscanf(f2,"%s %s %s %s %s \n",E.code1,E.destination,E.hotelsET,E.lieu1,E.prix1)!=EOF)
{if (strcmp(E.code1,ref2)==0) 
{ gtk_widget_show(window2);
gtk_entry_set_text(GTK_ENTRY(input1),E.code1) ;
gtk_entry_set_text(GTK_ENTRY(input2),E.destination) ;
gtk_entry_set_text(GTK_ENTRY(input3),E.hotelsET) ;
gtk_entry_set_text(GTK_ENTRY(input4),E.lieu1) ;
gtk_entry_set_text(GTK_ENTRY(input5),E.prix1) ;

gtk_widget_hide(window1);
break ;}}
}
fclose(f2);
}}


void
on_quitte_codeET_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_quitte_v_ghet_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *treeview2;

window1=lookup_widget(objet_graphique,"v_ghet");
window2=create_Gestion_hotels_ET();
gtk_widget_show(window2);
gtk_widget_hide(window1);
treeview2=lookup_widget(window2,"treeview2");

afficher_ghet(treeview2);
}


void
on_confirmation_v_ghet_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
ghet E;
GtkWidget *input1,*input2,*input3,*input4, *input5;
GtkWidget *output;
input1=lookup_widget(objet_graphique,"entry75");
input2=lookup_widget(objet_graphique,"entry76");
input3=lookup_widget(objet_graphique,"entry77");
input4=lookup_widget(objet_graphique,"entry78");
input5=lookup_widget(objet_graphique,"entry79");
output=lookup_widget(objet_graphique,"label141");
strcpy(E.code1,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(E.destination,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(E.hotelsET,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(E.lieu1,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(E.prix1,gtk_entry_get_text(GTK_ENTRY(input5)));

modifier_ghet(E);
gtk_label_set_text(GTK_LABEL(output),"modifié avec succés") ;
}


void
on_codeETS_confirmation_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1;
GtkWidget *output2;
ghet b;
char reference2[20];
input1=lookup_widget(objet_graphique,"entry80");
output2=lookup_widget(objet_graphique,"label145");
strcpy(reference2,gtk_entry_get_text(GTK_ENTRY(input1)));
if(verifier_ref2(reference2)==0)
gtk_label_set_text(GTK_LABEL(output2),"hotel inexistante");
else
{
supprimer_ghet(reference2);
gtk_label_set_text(GTK_LABEL(output2),"hotel supprimé");
}
}


void
on_codeETS_quitte_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *treeview2;

window1=lookup_widget(objet_graphique,"codeETS");
window2=create_Gestion_hotels_ET();
gtk_widget_show(window2);
gtk_widget_hide(window1);
treeview2=lookup_widget(window2,"treeview2");

afficher_ghet(treeview2);
}


void
on_RS_quitte_hotel_tunis_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"RS_hotel_en_Tunisie");
window2=create_Recherche_hotels_en_Tunisie();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_ajouter1000000_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
clienttn p;
date dt_d;
date dt_r;
GtkWidget *input1, *input2, *input3, *input4, *input5, *input6, *input7, *input8, *input9, *input10;
GtkWidget *output;
GtkWidget *window1;
GtkWidget *window2;


window1=lookup_widget(objet_graphique,"RS_hotel_en_Tunisie");


input1=lookup_widget(objet_graphique,"entry81");
input2=lookup_widget(objet_graphique,"entry82");
input3=lookup_widget(objet_graphique,"spinbutton20");
input4=lookup_widget(objet_graphique,"spinbutton18");
input5=lookup_widget(objet_graphique,"spinbutton19");
input6=lookup_widget(objet_graphique,"spinbutton21");
input7=lookup_widget(objet_graphique,"spinbutton23");
input8=lookup_widget(objet_graphique,"spinbutton22");
input9=lookup_widget(objet_graphique,"spinbutton15");
input10=lookup_widget(objet_graphique,"spinbutton16");
output=lookup_widget(objet_graphique,"label158");
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
p.dt_d.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (input3));
p.dt_d.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (input4));
p.dt_d.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (input5));
p.dt_r.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (input6));
p.dt_r.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (input7));
p.dt_r.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (input8));
p.nb=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (input9));
p.nbc=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (input10));
gtk_label_set_text(GTK_LABEL(output),"ajouter avec succée");

ajouter_clienttn(p);

window2=create_reservation_TN();
gtk_widget_show(window2);
gtk_widget_hide(window1);

}


void
on_treeviewhh_row_activated            (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *depart;
  	gchar *code;
	gchar *hotelsTN;
	gchar *lieu;
	gchar *prix; 
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *listview;
GtkTreeIter iter;

listview=lookup_widget(objet_graphique,"treeviewhh");

window1=lookup_widget(objet_graphique,"RS_hotel_en_Tunisie");
GtkTreeModel *model = gtk_tree_view_get_model (GTK_TREE_VIEW(lookup_widget(objet_graphique,"treeviewhh")));
if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&code,1,&hotelsTN,2,&lieu,3,&prix,-1);}
window2=create_ajout_client_hotel_tn();
FILE *f;
f=fopen("clienttunis.txt","a+");
if (f!=NULL)
{ 
fprintf(f,"%s %s %s %s ",code,hotelsTN,lieu,prix);
fclose(f);
}
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_afficher_reservationTN_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *input1;
GtkWidget *output2;
GtkWidget *window2;
GtkWidget *window1;
GtkWidget *treeview1;

char N2[20];
window1=lookup_widget(objet_graphique,"reservation_TN");

treeview1=lookup_widget(window2,"treeview4a");
input1=lookup_widget(objet_graphique,"entry84");
output2=lookup_widget(objet_graphique,"label159");
strcpy(N2,gtk_entry_get_text(GTK_ENTRY(input1)));

if(verifier_nom(N2)==0)
gtk_label_set_text(GTK_LABEL(output2),"reservation inexistante");


else
{
window2=create_RS_hotel_en_Tunisie();
gtk_widget_show(window2);
gtk_widget_hide(window1);
afficher_client1(treeview1,N2);
}
}


void
on_button1666_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_quittefinal_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_suppfinal_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(objet_graphique,"reservationfinal");
window2=create_code_supp_final();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_modfinal_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_supp_re_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1;
GtkWidget *output2;
clienttn b;
char reference2[20];
input1=lookup_widget(objet_graphique,"entryRE");
output2=lookup_widget(objet_graphique,"label162r");
strcpy(reference2,gtk_entry_get_text(GTK_ENTRY(input1)));
if(verifier_ref2(reference2)==0)
gtk_label_set_text(GTK_LABEL(output2),"réservation inexistante");
else
{
/*supprimer_client(reference2);*/
gtk_label_set_text(GTK_LABEL(output2),"réservation supprimé");

}}


void
on_quitte_RE_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_quitte152478_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}

