#include <gtk/gtk.h>


typedef struct
{

char code1 [20];
char destination [20];
char hotelsET [20];
char lieu1 [20];
char prix1[20];
 
}ghet;

void ajouter_ghet(ghet E);
void afficher_ghet(GtkWidget *liste);
int verifier_ref2(char ref2[]);
void modifier_ghet(ghet m);
int supprimer_ghet(char H[]);
