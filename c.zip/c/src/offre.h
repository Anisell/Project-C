#include <gtk/gtk.h>
typedef struct
{
char Destination[20];
char Prix[20];
char Pays[50];
char OffreID[50];
char Date[20];

}offre;
void ajouter_offres(offre o);
void afficher_offres(GtkWidget *liste);
void ajouter_vols(offre v);
void afficher_vols(GtkWidget *liste);
void ajouter_enfant(offre e);
void afficher_enfants(GtkWidget *liste);

void ajouter_gastronomie(offre g);
void afficher_gastronomies(GtkWidget *liste);

void ajouter_bienetre(offre b);
void afficher_bienetres(GtkWidget *liste);
void ajouter_circuit(offre c);
void afficher_circuit(GtkWidget *liste);
int verifier_hot(char hot[20]);
void supprimer_hot(char hot[]);
void supprimer_vol(char vol[]);
int verifier_vol(char vol[20]);
void supprimer_gastro(char gastro[]);
int verifier_gastronomi(char gastronomi[20]);
int verifier_bien(char bien[20]);
void supprimer_bien(char bien[]);
int verifier_hotel(char hotel[20]);
void modifier_offress(offre f);
