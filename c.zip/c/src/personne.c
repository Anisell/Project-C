#include <stdio.h>
#include <string.h>
#include "personne.h"
#include <gtk/gtk.h>
enum
{
	NOM,
	PRENOM,
	EMAIL,
	CIN,
	NUM,
	DATE,
	COLUMNS,
};
void ajouter_personne(personne p)
{
FILE *f;
f=fopen("personne.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s\n",p.Nom,p.Prenom,p.Email,p.cin,p.Num,p.Date);
fclose(f);
}}
void afficher_personne(GtkWidget *af)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;

	GtkListStore *store;

char Nom[30];
char Prenom[30];
char Email[30];
char cin[30];
char Num[30];
char Date[30];
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(af);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Nom",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Prenom",renderer, "text",PRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Email",renderer, "text",EMAIL,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" cin",renderer, "text",CIN,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Num",renderer, "text",NUM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
}
	store=gtk_list_store_new(6,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("personne.txt","r");
if(f==NULL)
{
return;
}
else
{
 f=fopen("personne.txt","a+");
	while(fscanf(f,"%s %s %s %s %s %s\n",Nom,Prenom,Email,cin,Num,Date)!=EOF)
	{
	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,NOM,Nom,PRENOM,Prenom,EMAIL,Email,CIN,cin,NUM,Num,DATE,Date,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(af), GTK_TREE_MODEL(store));
	g_object_unref(store);
	
}
}
int verifier_id(char ID[20])
{personne p;
FILE *f;
int test = 0 ; 
f=fopen("personne.txt","r");
if(f!=NULL) { 
while(fscanf(f,"%s %s %s %s %s %s\n",p.Nom,p.Prenom,p.Email,p.cin,p.Num,p.Date)!=EOF) 
{ 
if((strcmp(p.cin,ID)==0))
test=1 ;
 } }
fclose(f);
 
return test;
}

void modifier_personne(personne a)
{
personne m ;
FILE *f;
FILE *f2;
f=fopen("personne.txt","r");
f2=fopen("personne_tmp.txt","w"); 
if (f!=NULL)
{
if (f2!=NULL)

{ 
     while (fscanf(f,"%s %s %s %s %s %s\n",m.Nom,m.Prenom,m.Email,m.cin,m.Num,m.Date)!=EOF)
    { 
	if (strcmp(a.cin,m.cin)==0){
   fprintf(f2,"%s %s %s %s %s %s\n",a.Nom,a.Prenom,a.Email,a.cin,a.Num,a.Date);
}
	else 	
{	    fprintf(f2,"%s %s %s %s %s %s\n",m.Nom,m.Prenom,m.Email,m.cin,m.Num,m.Date);
     }

}}
fclose(f2);
fclose(f);

remove("personne.txt");
rename("personne_tmp.txt","personne.txt");
}
}
void personne_vols(personne v)
{
FILE *f;
f=fopen("personnevols.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s\n",v.Nom,v.Prenom,v.Email,v.cin,v.Num,v.Date);
fclose(f);
}}

void afficher_personne_vols(GtkWidget *vols)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;

	GtkListStore *store;

char Nom [30];
char Prenom [30];
char Email [30];
char cin[30];
char Num[30];
char Date[30];
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(vols);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Nom",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (vols),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Prenom",renderer, "text",PRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (vols),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Email",renderer, "text",EMAIL,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (vols),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" cin",renderer, "text",CIN,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (vols),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Num",renderer, "text",NUM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (vols),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (vols),column);
	renderer = gtk_cell_renderer_text_new();
}
	store=gtk_list_store_new(6,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("personnevols.txt","r");
if(f==NULL)
{
return;
}
else
{
 f=fopen("personnevols.txt","a+");
	while(fscanf(f,"%s %s %s %s %s %s\n",Nom,Prenom,Email,cin,Num,Date)!=EOF)
	{
	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,NOM,Nom,PRENOM,Prenom,EMAIL,Email,CIN,cin,NUM,Num,DATE,Date,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(vols), GTK_TREE_MODEL(store));
	g_object_unref(store);
	
}
}
void personne_promo(personne r)
{
FILE *f;
f=fopen("personnepromo.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s\n",r.Nom,r.Prenom,r.Email,r.cin,r.Num,r.Date);
fclose(f);
}
}


void afficher_personne_promo(GtkWidget *promo)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;

	GtkListStore *store;

char Nom[30];
char Prenom[30];
char Email[30];
char cin[30];
char Num[30];
char Date[30];
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(promo);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Nom",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (promo),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Prenom",renderer, "text",PRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (promo),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Email",renderer, "text",EMAIL,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (promo),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" cin",renderer, "text",CIN,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (promo),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Num",renderer, "text",NUM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (promo),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (promo),column);
	renderer = gtk_cell_renderer_text_new();
}
	store=gtk_list_store_new(6,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("personnepromo.txt","r");
if(f==NULL)
{
return;
}
else
{
 f=fopen("personnepromo.txt","a+");
	while(fscanf(f,"%s %s %s %s %s %s\n",Nom,Prenom,Email,cin,Num,Date)!=EOF)
	{
	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,NOM,Nom,PRENOM,Prenom,EMAIL,Email,CIN,cin,NUM,Num,DATE,Date,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(promo), GTK_TREE_MODEL(store));
	g_object_unref(store);
	
}
}

void personne_Gastronomie(personne g)
{
FILE *f;
f=fopen("personneGastronomie.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s\n",g.Nom,g.Prenom,g.Email,g.cin,g.Num,g.Date);
fclose(f);
}}

void afficher_personne_Gastronomie(GtkWidget *Gastronomie)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;

	GtkListStore *store;

char Nom [30];
char Prenom [30];
char Email [30];
char cin[30];
char Num[30];
char Date[30];
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(Gastronomie);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Nom",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (Gastronomie),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Prenom",renderer, "text",PRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (Gastronomie),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Email",renderer, "text",EMAIL,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (Gastronomie),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" cin",renderer, "text",CIN,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (Gastronomie),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Num",renderer, "text",NUM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (Gastronomie),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (Gastronomie),column);
	renderer = gtk_cell_renderer_text_new();
}
	store=gtk_list_store_new(6,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("personneGastronomie.txt","r");
if(f==NULL)
{
return;
}
else
{
 f=fopen("personneGastronomie.txt","a+");
	while(fscanf(f,"%s %s %s %s %s %s\n",Nom,Prenom,Email,cin,Num,Date)!=EOF)
	{
	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,NOM,Nom,PRENOM,Prenom,EMAIL,Email,CIN,cin,NUM,Num,DATE,Date,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(Gastronomie), GTK_TREE_MODEL(store));
	g_object_unref(store);
	
}
}
void personne_bienetre(personne b)
{
FILE *f;
f=fopen("personnebienetre.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s\n",b.Nom,b.Prenom,b.Email,b.cin,b.Num,b.Date);
fclose(f);
}}

void afficher_personne_bienetre(GtkWidget *bienetre)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;

	GtkListStore *store;

char Nom [30];
char Prenom [30];
char Email [30];
char cin[30];
char Num[30];
char Date[30];
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(bienetre);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Nom",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (bienetre),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Prenom",renderer, "text",PRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (bienetre),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Email",renderer, "text",EMAIL,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (bienetre),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" cin",renderer, "text",CIN,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (bienetre),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Num",renderer, "text",NUM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (bienetre),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (bienetre),column);
	renderer = gtk_cell_renderer_text_new();
}
	store=gtk_list_store_new(6,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("personnebienetre.txt","r");
if(f==NULL)
{
return;
}
else
{
 f=fopen("personnebienetre.txt","a+");
	while(fscanf(f,"%s %s %s %s %s %s\n",Nom,Prenom,Email,cin,Num,Date)!=EOF)
	{
	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,NOM,Nom,PRENOM,Prenom,EMAIL,Email,CIN,cin,NUM,Num,DATE,Date,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(bienetre), GTK_TREE_MODEL(store));
	g_object_unref(store);
	
}
}

void personne_circuit(personne c)
{
FILE *f;
f=fopen("personnecircuit.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s\n",c.Nom,c.Prenom,c.Email,c.cin,c.Num,c.Date);
fclose(f);
}}

void afficher_personne_circuit(GtkWidget *circuit)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;

	GtkListStore *store;

char Nom [30];
char Prenom [30];
char Email [30];
char cin[30];
char Num[30];
char Date[30];
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(circuit);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Nom",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (circuit),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Prenom",renderer, "text",PRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (circuit),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Email",renderer, "text",EMAIL,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (circuit),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" cin",renderer, "text",CIN,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (circuit),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Num",renderer, "text",NUM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (circuit),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (circuit),column);
	renderer = gtk_cell_renderer_text_new();
}
	store=gtk_list_store_new(6,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("personnecircuit.txt","r");
if(f==NULL)
{
return;
}
else
{
 f=fopen("personnecircuit.txt","a+");
	while(fscanf(f,"%s %s %s %s %s %s\n",Nom,Prenom,Email,cin,Num,Date)!=EOF)
	{
	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,NOM,Nom,PRENOM,Prenom,EMAIL,Email,CIN,cin,NUM,Num,DATE,Date,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(circuit), GTK_TREE_MODEL(store));
g_object_unref(store);
}}




void supprimer_hotel(char refer[])
{
FILE *f,*f1;
personne p;
 
f=fopen("personne.txt","r"); 
f1=fopen("tmp_hotel.txt","w");
 if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f,"%s %s %s %s %s %s\n",p.Nom,p.Prenom,p.Email,p.cin,p.Num,p.Date)!=EOF) 
{
if(strcmp(refer,p.cin)!=0)
{
fprintf(f1,"%s %s %s %s %s %s\n",p.Nom,p.Prenom,p.Email,p.cin,p.Num,p.Date);
}}
fclose(f) ; 
fclose(f1);}
 
f=fopen("personne.txt","w"); 
f1=fopen("tmp_hotel.txt","r");
if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f1,"%s %s %s %s %s %s\n",p.Nom,p.Prenom,p.Email,p.cin,p.Num,p.Date)!=EOF) 
{
if(strcmp(refer,p.cin)!=0)
{
fprintf(f,"%s %s %s %s %s %s\n",p.Nom,p.Prenom,p.Email,p.cin,p.Num,p.Date);
}}
fclose(f) ; 
fclose(f1);
}}


void supprimer_vool(char vool[])
{
FILE *f,*f1;
personne v;
 
f=fopen("personnevols.txt","r"); 
f1=fopen("tmp_vools.txt","w");
 if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f,"%s %s %s %s %s %s\n",v.Nom,v.Prenom,v.Email,v.cin,v.Num,v.Date)!=EOF) 
{
if(strcmp(vool,v.cin)!=0)
{
fprintf(f1,"%s %s %s %s %s %s\n",v.Nom,v.Prenom,v.Email,v.cin,v.Num,v.Date);
}}
fclose(f) ; 
fclose(f1);}
 
f=fopen("personnevols.txt","w"); 
f1=fopen("tmp_vools.txt","r");
if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f1,"%s %s %s %s %s %s\n",v.Nom,v.Prenom,v.Email,v.cin,v.Num,v.Date)!=EOF) 
{
if(strcmp(vool,v.cin)!=0)
{
fprintf(f,"%s %s %s %s %s %s\n",v.Nom,v.Prenom,v.Email,v.cin,v.Num,v.Date);
}}
fclose(f) ; 
fclose(f1);
}}



void supprimer_pr(char pr[])
{
FILE *f,*f1;
personne h;
 
f=fopen("personnepromo.txt","r"); 
f1=fopen("tmp_promo.txt","w");
 if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f,"%s %s %s %s %s %s\n",h.Nom,h.Prenom,h.Email,h.cin,h.Num,h.Date)!=EOF) 
{
if(strcmp(pr,h.cin)!=0)
{
fprintf(f1,"%s %s %s %s %s %s\n",h.Nom,h.Prenom,h.Email,h.cin,h.Num,h.Date);
}}
fclose(f) ; 
fclose(f1);}
 
f=fopen("personnepromo.txt","w"); 
f1=fopen("tmp_promo.txt","r");
if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f1,"%s %s %s %s %s %s\n",h.Nom,h.Prenom,h.Email,h.cin,h.Num,h.Date)!=EOF) 
{
if(strcmp(pr,h.cin)!=0)
{
fprintf(f,"%s %s %s %s %s %s\n",h.Nom,h.Prenom,h.Email,h.cin,h.Num,h.Date);
}}
fclose(f) ; 
fclose(f1);
}}


void supprimer_gastro(char gastro[])
{
FILE *f,*f1;
personne g;
 
f=fopen("personneGastronomie.txt","r"); 
f1=fopen("tmp_Gastronomie.txt","w");
 if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f,"%s %s %s %s %s %s\n",g.Nom,g.Prenom,g.Email,g.cin,g.Num,g.Date)!=EOF) 
{
if(strcmp(gastro,g.cin)!=0)
{
fprintf(f1,"%s %s %s %s %s %s\n",g.Nom,g.Prenom,g.Email,g.cin,g.Num,g.Date);
}}
fclose(f) ; 
fclose(f1);}
 
f=fopen("personneGastronomie.txt","w"); 
f1=fopen("tmp_Gastronomie.txt","r");
if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f1,"%s %s %s %s %s %s\n",g.Nom,g.Prenom,g.Email,g.cin,g.Num,g.Date)!=EOF) 
{
if(strcmp(gastro,g.cin)!=0)
{
fprintf(f,"%s %s %s %s %s %s\n",g.Nom,g.Prenom,g.Email,g.cin,g.Num,g.Date);
}}
fclose(f) ; 
fclose(f1);
}}

int verifier_vool(char vool[20])
{personne v;
FILE *a;
int test = 0 ; 
a=fopen("personnevols.txt","r");
if(a!=NULL) { 
while(fscanf(a,"%s %s %s %s %s %s\n",v.Nom,v.Prenom,v.Email,v.cin,v.Num,v.Date)!=EOF) 
{ 
if((strcmp(v.cin,vool)==0))
test=1 ;
 } }
fclose(a);
 return test;
}

int verifier_pr(char pr[20])
{personne r;
FILE *a;
int test = 0 ; 
a=fopen("personnepromo.txt","r");
if(a!=NULL) { 
while(fscanf(a,"%s %s %s %s %s %s\n",r.Nom,r.Prenom,r.Email,r.cin,r.Num,r.Date)!=EOF) 
{ 
if((strcmp(r.cin,pr)==0))
test=1 ;
 } }
fclose(a);
 return test;
}

int verifier_gastro(char gastro[20])
{personne r;
FILE *a;
int test = 0 ; 
a=fopen("personneGastronomie.txt","r");
if(a!=NULL) { 
while(fscanf(a,"%s %s %s %s %s %s\n",r.Nom,r.Prenom,r.Email,r.cin,r.Num,r.Date)!=EOF) 
{ 
if((strcmp(r.cin,gastro)==0))
test=1 ;
 } }
fclose(a);
 return test;
}



