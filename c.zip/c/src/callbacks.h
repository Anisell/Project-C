#include <gtk/gtk.h>


void
on_button43_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button44_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button45_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button159_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button160_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button161_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button162_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button164_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button165_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttom163_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button0_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button15_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button16_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
on_button17_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button18_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button19_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button20_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button147_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button148_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button149_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button21_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button22_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button23_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button24_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button25_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button26_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button27_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button28_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button29_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button30_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button166_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button176_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button177_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button34_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button35_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button36_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button37_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button38_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button39_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button40_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button41_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button42_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button46_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button179_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonajout_personne_vols_clicked   (GtkWidget       *objet_grapgique,
                                        gpointer         user_data);

void
on_buttonafficher_personne_vols_clicked (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonsupprimer_personne_vols_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonmodifier_personne_promo_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonafficher_personne_promo_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonsupprimer_personne_promo_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonajouter_personne_gastronomie_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonmodifier_personne_gastronomie_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonafficher_personne_gastronomie_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonsupprimer_personne_gastronomie_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonajouter_bienetre_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonmodifier_bienetre_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonafficher_personne_bienetre_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonsupprimer_personne_bienetre_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonajouter_escapade_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonmodifier_personne_supprimer_escapade_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonafficher_personne_circuit_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonsupprimer_personne_circuit_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodifier_personne_vols_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonajouter_Modifier_Supprimer_personne_promo_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonajouter_Modifier_Supprimer_Personne_promo_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouter_Modifier_Supprimer_Personne_promo_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_promopersonne_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAjouter_offre_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAjouter_vols_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonModifier_vols_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAfficher_vols_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonSupprimer_vols_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAjouter_promo_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonModifier_promo_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAfficher_promo_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonSupprimer_promo_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAJouter_Gastronomie_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonModifier_Gastronomie_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAfficher_Gastronomie_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonSupprimer_Gastronomie_clicked (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAjouter_bienetre_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonModifier_bienetre_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAfficher_bienetre_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonSupprimer_bienetre_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAjouter_circuit_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonModifier_circuit_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAfficher_circruit_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonSupprimer_circuit_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button179_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_valider_changer_personne_vols_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonModifier_hotel_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_modifier400_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_reserverclientvol_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_reserverpromoclient_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_reservergastronomie_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_reserverclientcircuit_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_reserverclientbienetre_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_quittergastro_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_quittercircuit_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_quitterbienetre_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_quittervolss_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_quitterppromo_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_precedentvol_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_precedentpromo_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_precedentgastro_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_precedentcircuit_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_precedentbienetre_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview24_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview14_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview19_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview20_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview17_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview18_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_rechercherpersonnehotel_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_recherchervols_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
