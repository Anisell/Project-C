#include <gtk/gtk.h>

#include <gtk/gtk.h>
typedef struct
{
char Nom[20];
char Prenom[20];
char Email[50];
char cin[50];
char Num[20];
char Date[30];

}personnehotel;


void rechercher_personnehotel(GtkWidget *af,char ID[]);
int ver_personnehotel(char ID[]);
void afficher_personnehotel(GtkWidget *af);
typedef struct
{
char Nom[20];
char Prenom[20];
char Email[50];
char cin[50];
char Num[20];
char Date[30];

}personnevols;
void rechercher_personnevols(GtkWidget *af,char ID[]);
int ver_personnevols(char ID[]);
void afficher_personnevols(GtkWidget *af);




