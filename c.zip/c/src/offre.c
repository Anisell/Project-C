#include <stdio.h>
#include <string.h>
#include "offre.h"
#include <gtk/gtk.h>
enum
{
	DESTINATION,
	PRIX,
	PAYS,
	OFFREID,
	DATE,
	COLUMS
};
void ajouter_offres(offre o)
{
FILE *f;
f=fopen("offre.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s\n",o.Destination,o.Prix,o.Pays,o.OffreID,o.Date);
fclose(f);
}}
void afficher_offres(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;

	GtkListStore *store;

char Destination [30];
char Prix [30];
char Pays [30];
char OffreID[30];
char Date[30];
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Destination",renderer, "text",DESTINATION,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Prix",renderer, "text",PRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Pays",renderer, "text",PAYS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" OffreID",renderer, "text",OFFREID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	renderer = gtk_cell_renderer_text_new();
}
	store=gtk_list_store_new(5,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("offre.txt","r");
if(f==NULL)
{
return;
}
else
{
 f=fopen("offre.txt","a+");
	while(fscanf(f,"%s %s %s %s %s\n",Destination,Prix,Pays,OffreID,Date)!=EOF)
	{
	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,DESTINATION,Destination,PRIX,Prix,PAYS,Pays,OFFREID,OffreID,DATE,Date,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	
}
}
void ajouter_vols(offre v)
{
FILE *f;
f=fopen("vols.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s\n",v.Destination,v.Prix,v.Pays,v.OffreID,v.Date);
fclose(f);
}}
void afficher_vols(GtkWidget *vol)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;

	GtkListStore *store;

char Destination [30];
char Prix [30];
char Pays [30];
char OffreID[30];
char Date[30];
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(vol);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Destination",renderer, "text",DESTINATION,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (vol),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Prix",renderer, "text",PRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (vol),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Pays",renderer, "text",PAYS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (vol),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" OffreID",renderer, "text",OFFREID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (vol),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (vol),column);
	renderer = gtk_cell_renderer_text_new();
}
	store=gtk_list_store_new(5,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("vols.txt","r");
if(f==NULL)
{
return;
}
else
{
 f=fopen("vols.txt","a+");
	while(fscanf(f,"%s %s %s %s %s\n",Destination,Prix,Pays,OffreID,Date)!=EOF)
	{
	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,DESTINATION,Destination,PRIX,Prix,PAYS,Pays,OFFREID,OffreID,DATE,Date,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(vol), GTK_TREE_MODEL(store));
	g_object_unref(store);
	
}
}

void ajouter_enfant(offre e)
{
FILE *f;
f=fopen("enfant.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s\n",e.Destination,e.Prix,e.Pays,e.OffreID,e.Date);
fclose(f);
}}
void afficher_enfants(GtkWidget *enfant)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;

	GtkListStore *store;

char Destination [30];
char Prix [30];
char Pays [30];
char OffreID[30];
char Date[30];
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(enfant);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Destination",renderer, "text",DESTINATION,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (enfant),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Prix",renderer, "text",PRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (enfant),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Pays",renderer, "text",PAYS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (enfant),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" OffreID",renderer, "text",OFFREID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (enfant),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (enfant),column);
	renderer = gtk_cell_renderer_text_new();
}
	store=gtk_list_store_new(5,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("enfant.txt","r");
if(f==NULL)
{
return;
}
else
{
 f=fopen("enfant.txt","a+");
	while(fscanf(f,"%s %s %s %s %s\n",Destination,Prix,Pays,OffreID,Date)!=EOF)
	{
	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,DESTINATION,Destination,PRIX,Prix,PAYS,Pays,OFFREID,OffreID,DATE,Date,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(enfant), GTK_TREE_MODEL(store));
	g_object_unref(store);
	
}
}

void ajouter_gastronomie(offre g)
{
FILE *f;
f=fopen("gastronomie.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s\n",g.Destination,g.Prix,g.Pays,g.OffreID,g.Date);
fclose(f);
}}
void afficher_gastronomies(GtkWidget *gastronomie)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;

	GtkListStore *store;

char Destination [30];
char Prix [30];
char Pays [30];
char OffreID[30];
char Date[30];
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(gastronomie);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Destination",renderer, "text",DESTINATION,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (gastronomie),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Prix",renderer, "text",PRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (gastronomie),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Pays",renderer, "text",PAYS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (gastronomie),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" OffreID",renderer, "text",OFFREID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (gastronomie),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (gastronomie),column);
	renderer = gtk_cell_renderer_text_new();
}
	store=gtk_list_store_new(5,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("gastronomie.txt","r");
if(f==NULL)
{
return;
}
else
{
 f=fopen("gastronomie.txt","a+");
	while(fscanf(f,"%s %s %s %s %s\n",Destination,Prix,Pays,OffreID,Date)!=EOF)
	{
	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,DESTINATION,Destination,PRIX,Prix,PAYS,Pays,OFFREID,OffreID,DATE,Date,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(gastronomie), GTK_TREE_MODEL(store));
	g_object_unref(store);
	
}
}


void ajouter_bienetre(offre b)
{
FILE *f;
f=fopen("bienetre.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s\n",b.Destination,b.Prix,b.Pays,b.OffreID,b.Date);
fclose(f);
}}
void afficher_bienetres(GtkWidget *bienetre)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;

	GtkListStore *store;

char Destination [30];
char Prix [30];
char Pays [30];
char OffreID[30];
char Date[30];
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(bienetre);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Destination",renderer, "text",DESTINATION,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (bienetre),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Prix",renderer, "text",PRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (bienetre),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Pays",renderer, "text",PAYS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (bienetre),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" OffreID",renderer, "text",OFFREID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (bienetre),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (bienetre),column);
	renderer = gtk_cell_renderer_text_new();
}
	store=gtk_list_store_new(5,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("bienetre.txt","r");
if(f==NULL)
{
return;
}
else
{
 f=fopen("bienetre.txt","a+");
	while(fscanf(f,"%s %s %s %s %s\n",Destination,Prix,Pays,OffreID,Date)!=EOF)
	{
	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,DESTINATION,Destination,PRIX,Prix,PAYS,Pays,OFFREID,OffreID,DATE,Date,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(bienetre), GTK_TREE_MODEL(store));
	g_object_unref(store);
	
}
}
void ajouter_circuit(offre c)
{
FILE *f;
f=fopen("circuit.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s\n",c.Destination,c.Prix,c.Pays,c.OffreID,c.Date);
fclose(f);
}}
void afficher_circuits(GtkWidget *circuit)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;

	GtkListStore *store;

char Destination [30];
char Prix [30];
char Pays [30];
char OffreID[30];
char Date[30];
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(circuit);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Destination",renderer, "text",DESTINATION,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (circuit),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Prix",renderer, "text",PRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (circuit),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Pays",renderer, "text",PAYS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (circuit),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" OffreID",renderer, "text",OFFREID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (circuit),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (circuit),column);
	renderer = gtk_cell_renderer_text_new();
}
	store=gtk_list_store_new(5,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("circuit.txt","r");
if(f==NULL)
{
return;
}
else
{
 f=fopen("circuit.txt","a+");
	while(fscanf(f,"%s %s %s %s %s\n",Destination,Prix,Pays,OffreID,Date)!=EOF)
	{
	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,DESTINATION,Destination,PRIX,Prix,PAYS,Pays,OFFREID,OffreID,DATE,Date,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(circuit), GTK_TREE_MODEL(store));
	g_object_unref(store);
	
}
}


int verifier_hot(char hot[20])
{offre h;
FILE *a;
int test = 0 ; 
a=fopen("offre.txt","r");
if(a!=NULL) { 
while(fscanf(a,"%s %s %s %s %s\n",h.Destination,h.Prix,h.Pays,h.OffreID,h.Date)!=EOF) 
{
if((strcmp(h.OffreID,hot)==0))
test=1 ;
 } }
fclose(a);
 return test;
}

void supprimer_hot(char hot[])
{
FILE *f,*f1;
offre h;
 
f=fopen("offre.txt","r"); 
f1=fopen("tmp_hotel.txt","w");
 if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f,"%s %s %s %s %s\n",h.Destination,h.Prix,h.Pays,h.OffreID,h.Date)!=EOF) 
{
if(strcmp(hot,h.OffreID)!=0)
{
fprintf(f1,"%s %s %s %s %s\n",h.Destination,h.Prix,h.Pays,h.OffreID,h.Date);
}}
fclose(f) ; 
fclose(f1);}
 
f=fopen("offre.txt","w"); 
f1=fopen("tmp_hotel.txt","r");
if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f1,"%s %s %s %s %s\n",h.Destination,h.Prix,h.Pays,h.OffreID,h.Date)!=EOF) 
{
if(strcmp(hot,h.OffreID)!=0)
{
fprintf(f,"%s %s %s %s %s\n",h.Destination,h.Prix,h.Pays,h.OffreID,h.Date);
}}
fclose(f) ; 
fclose(f1);
}}


int verifier_vol(char vol[20])
{offre v;
FILE *a;
int test = 0 ; 
a=fopen("vols.txt","r");
if(a!=NULL) { 
while(fscanf(a,"%s %s %s %s %s\n",v.Destination,v.Prix,v.Pays,v.OffreID,v.Date)!=EOF) 
{
if((strcmp(v.OffreID,vol)==0))
test=1 ;
 } }
fclose(a);
 return test;
}

void supprimer_vol(char vol[])
{
FILE *f,*f1;
offre v;
 
f=fopen("vols.txt","r"); 
f1=fopen("tmp_vol.txt","w");
 if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f,"%s %s %s %s %s\n",v.Destination,v.Prix,v.Pays,v.OffreID,v.Date)!=EOF) 
{
if(strcmp(vol,v.OffreID)!=0)
{
fprintf(f1,"%s %s %s %s %s \n",v.Destination,v.Prix,v.Pays,v.OffreID,v.Date);
}}
fclose(f) ; 
fclose(f1);}
 
f=fopen("vols.txt","w"); 
f1=fopen("tmp_vol.txt","r");
if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f1,"%s %s %s %s %s\n",v.Destination,v.Prix,v.Pays,v.OffreID,v.Date)!=EOF) 
{
if(strcmp(vol,v.OffreID)!=0)
{
fprintf(f,"%s %s %s %s %s\n",v.Destination,v.Prix,v.Pays,v.OffreID,v.Date);
}}
fclose(f) ; 
fclose(f1);
}}

int verifier_gastronomi(char gastronomi[20])
{offre g;
FILE *a;
int test = 0 ; 
a=fopen("gastronomie.txt","r");
if(a!=NULL) { 
while(fscanf(a,"%s %s %s %s %s\n",g.Destination,g.Prix,g.Pays,g.OffreID,g.Date)!=EOF) 
{
if((strcmp(g.OffreID,gastronomi)==0))
test=1 ;
 } }
fclose(a);
 return test;
}

void supprimer_gastr(char gastr[])
{
FILE *f,*f1;
offre g;
 
f=fopen("gastronomie.txt","r"); 
f1=fopen("tmp_gastro.txt","w");
 if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f,"%s %s %s %s %s\n",g.Destination,g.Prix,g.Pays,g.OffreID,g.Date)!=EOF) 
{
if(strcmp(gastr,g.OffreID)!=0)
{
fprintf(f1,"%s %s %s %s %s \n",g.Destination,g.Prix,g.Pays,g.OffreID,g.Date);
}}
fclose(f) ; 
fclose(f1);}
 
f=fopen("gastronomie.txt","w"); 
f1=fopen("tmp_gastro.txt","r");
if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f1,"%s %s %s %s %s\n",g.Destination,g.Prix,g.Pays,g.OffreID,g.Date)!=EOF) 
{
if(strcmp(gastr,g.OffreID)!=0)
{
fprintf(f,"%s %s %s %s %s\n",g.Destination,g.Prix,g.Pays,g.OffreID,g.Date);
}}
fclose(f) ; 
fclose(f1);
}}

int verifier_bien(char bien[20])
{offre b;
FILE *a;
int test = 0 ; 
a=fopen("bienetre.txt","r");
if(a!=NULL) { 
while(fscanf(a,"%s %s %s %s %s\n",b.Destination,b.Prix,b.Pays,b.OffreID,b.Date)!=EOF) 
{
if((strcmp(b.OffreID,bien)==0))
test=1 ;
 } }
fclose(a);
 return test;
}

void supprimer_bien(char bien[])
{
FILE *f,*f1;
offre b;
 
f=fopen("bienetre.txt","r"); 
f1=fopen("tmp_bien.txt","w");
 if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f,"%s %s %s %s %s\n",b.Destination,b.Prix,b.Pays,b.OffreID,b.Date)!=EOF) 
{
if(strcmp(bien,b.OffreID)!=0)
{
fprintf(f1,"%s %s %s %s %s \n",b.Destination,b.Prix,b.Pays,b.OffreID,b.Date);
}}
fclose(f) ; 
fclose(f1);}
 
f=fopen("bienetre.txt","w"); 
f1=fopen("tmp_bien.txt","r");
if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f1,"%s %s %s %s %s\n",b.Destination,b.Prix,b.Pays,b.OffreID,b.Date)!=EOF) 
{
if(strcmp(bien,b.OffreID)!=0)
{
fprintf(f,"%s %s %s %s %s\n",b.Destination,b.Prix,b.Pays,b.OffreID,b.Date);
}}
fclose(f) ; 
fclose(f1);
}}

int verifier_hotel(char id[20])
{offre h;
FILE *a;
int test = 0 ; 
a=fopen("offre.txt","r");
if(a!=NULL) { 
while(fscanf(a,"%s %s %s %s %s\n",h.Destination,h.Prix,h.Pays,h.OffreID,h.Date)!=EOF) 
{
if((strcmp(h.OffreID,id)==0))
test=1 ;
 } }
fclose(a);
 return test;
}
void modifier_offress(offre a)
{
offre h ;
FILE *f;
FILE *f2;
f=fopen("offre.txt","r");
f2=fopen("hotel_tmp.txt","w"); 
if (f!=NULL)
{
if (f2!=NULL)

{ 
     while (fscanf(f,"%s %s %s %s %s\n",h.Destination,h.Prix,h.Pays,h.OffreID,h.Date)!=EOF)
    { 
	if (strcmp(h.OffreID,a.OffreID)==0){
   fprintf(f2,"%s %s %s %s %s\n",a.Destination,a.Prix,a.Pays,a.OffreID,a.Date);
}
	else 	
{	    fprintf(f2,"%s %s %s %s %s\n",h.Destination,h.Prix,h.Pays,h.OffreID,h.Date);
     }

}}
fclose(f2);
fclose(f);

remove("offre.txt");
rename("hotel_tmp.txt","offre.txt");
}
}

