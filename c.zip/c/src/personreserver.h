#include <gtk/gtk.h>
typedef struct
{
int Jour;
int Mois;
int annee;
}date;


typedef struct
{
char Nom[20];
char Prenom[20];
date dt_nai;
char Email[50];
char cin[50];
char Num[20];
int nb;
}hotel;
void ajouter_hotelperson(hotel h);
typedef struct
{
char Nom[20];
char Prenom[20];
date dt_nai;
char Email[50];
char cin[50];
char Num[20];
int nb;
}vol;
void ajouter_volperson(vol v);

typedef struct
{
char Nom[20];
char Prenom[20];
date dt_nai;
char Email[50];
char cin[50];
char Num[20];
int nb;
}promo;
void ajouter_promoperson(promo p);

typedef struct
{
char Nom[20];
char Prenom[20];
date dt_nai;
char Email[50];
char cin[50];
char Num[20];
int nb;
}gastro;
void ajouter_gastroperson(gastro g);

typedef struct
{
char Nom[20];
char Prenom[20];
date dt_nai;
char Email[50];
char cin[50];
char Num[20];
int nb;
}circuit;
void ajouter_circuitperson(circuit c);

typedef struct
{
char Nom[20];
char Prenom[20];
date dt_nai;
char Email[50];
char cin[50];
char Num[20];
int nb;
}bienetre;
void ajouter_bienetreperson(bienetre b);


