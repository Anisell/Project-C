#include <stdio.h>
#include <string.h>
#include "personreserver.h"
#include <gtk/gtk.h>
enum
{
	NOM,
	PRENOM,
	EMAIL,
	CIN,
	NUM,
	COLUMNS,
};
void ajouter_hotelperson(hotel h)
{
FILE *f;
f=fopen("personne.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s %d/%d/%d %d\n",h.Nom,h.Prenom,h.Email,h.cin,h.Num,h.dt_nai.Jour,h.dt_nai.Mois,h.dt_nai.annee,h.nb);
fclose(f);
}}

void ajouter_volperson(vol v)
{
FILE *f;
f=fopen("personnevols.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s %d/%d/%d %d\n",v.Nom,v.Prenom,v.Email,v.cin,v.Num,v.dt_nai.Jour,v.dt_nai.Mois,v.dt_nai.annee,v.nb);
fclose(f);
}}

void ajouter_promoperson(promo p)
{
FILE *f;
f=fopen("personnepromo.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s %d/%d/%d %d\n",p.Nom,p.Prenom,p.Email,p.cin,p.Num,p.dt_nai.Jour,p.dt_nai.Mois,p.dt_nai.annee,p.nb);
fclose(f);
}}


void ajouter_gastroperson(gastro g)
{
FILE *f;
f=fopen("personnegastronomie.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s %d/%d/%d %d\n",g.Nom,g.Prenom,g.Email,g.cin,g.Num,g.dt_nai.Jour,g.dt_nai.Mois,g.dt_nai.annee,g.nb);
fclose(f);
}}


void ajouter_circuitperson(circuit c)
{
FILE *f;
f=fopen("personnecircuit.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s %d/%d/%d %d\n",c.Nom,c.Prenom,c.Email,c.cin,c.Num,c.dt_nai.Jour,c.dt_nai.Mois,c.dt_nai.annee,c.nb);
fclose(f);
}}


void ajouter_bienetreperson(bienetre b)
{
FILE *f;
f=fopen("personnebienetre.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s %d/%d/%d %d\n",b.Nom,b.Prenom,b.Email,b.cin,b.Num,b.dt_nai.Jour,b.dt_nai.Mois,b.dt_nai.annee,b.nb);
fclose(f);
}}




