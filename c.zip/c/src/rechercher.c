#include<stdio.h>
#include<string.h>
#include"rechercher.h"
#include <gtk/gtk.h>

enum 
{
	NOM,
	PRENOM,
	EMAIL,
	CIN,
	NUM,
	DATE,
	COLUMNS,
};


int ver_personnehotel(char ID[])
{personnehotel p;
FILE *f;
int test = 0 ; 
f=fopen("personne.txt","r");
if(f!=NULL) { 
while(fscanf(f,"%s %s %s %s %s %s\n",p.Nom,p.Prenom,p.Email,p.cin,p.Num,p.Date)!=EOF) 
{ 
if((strcmp(p.cin,ID)==0))
test=1 ;
 } }
fclose(f);
 
return test;
}


void afficher_personnehotel(GtkWidget *af)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;

	GtkListStore *store;

char Nom[30];
char Prenom[30];
char Email[30];
char cin[30];
char Num[30];
char Date[30];
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(af);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Nom",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Prenom",renderer, "text",PRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Email",renderer, "text",EMAIL,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" cin",renderer, "text",CIN,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Num",renderer, "text",NUM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
}
	store=gtk_list_store_new(6,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("personne.txt","r");
if(f==NULL)
{
return;
}
else
{
 f=fopen("personne.txt","a+");
	while(fscanf(f,"%s %s %s %s %s %s\n",Nom,Prenom,Email,cin,Num,Date)!=EOF)
	{
	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,NOM,Nom,PRENOM,Prenom,EMAIL,Email,CIN,cin,NUM,Num,DATE,Date,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(af), GTK_TREE_MODEL(store));
	g_object_unref(store);
	
}
}


void rechercher_personnehotel(GtkWidget *af,char ID[])
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;

	GtkListStore *store;

char Nom[30];
char Prenom[30];
char Email[30];
char cin[30];
char Num[30];
char Date[30];
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(af);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Nom",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Prenom",renderer, "text",PRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Email",renderer, "text",EMAIL,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" cin",renderer, "text",CIN,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Num",renderer, "text",NUM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
}
	store=gtk_list_store_new(6,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("personne.txt","r");
if(f==NULL)
{
return;
}
else
{
 f=fopen("personne.txt","a+");
	while(fscanf(f,"%s %s %s %s %s %s\n",Nom,Prenom,Email,cin,Num,Date)!=EOF)
	{
if(strcmp(cin,ID)==0)
{	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,NOM,Nom,PRENOM,Prenom,EMAIL,Email,CIN,cin,NUM,Num,DATE,Date,-1);
	}}
	fclose(f);}
	gtk_tree_view_set_model(GTK_TREE_VIEW(af), GTK_TREE_MODEL(store));
	g_object_unref(store);
	

}

void afficher_personnevols(GtkWidget *af)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;

	GtkListStore *store;

char Nom[30];
char Prenom[30];
char Email[30];
char cin[30];
char Num[30];
char Date[30];
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(af);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Nom",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Prenom",renderer, "text",PRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Email",renderer, "text",EMAIL,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" cin",renderer, "text",CIN,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Num",renderer, "text",NUM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
}
	store=gtk_list_store_new(6,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("personnevols.txt","r");
if(f==NULL)
{
return;
}
else
{
 f=fopen("personnevols.txt","a+");
	while(fscanf(f,"%s %s %s %s %s %s\n",Nom,Prenom,Email,cin,Num,Date)!=EOF)
	{
	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,NOM,Nom,PRENOM,Prenom,EMAIL,Email,CIN,cin,NUM,Num,DATE,Date,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(af), GTK_TREE_MODEL(store));
	g_object_unref(store);
	
}
}


void rechercher_personnevols(GtkWidget *af,char ID[])
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;

	GtkListStore *store;

char Nom[30];
char Prenom[30];
char Email[30];
char cin[30];
char Num[30];
char Date[30];
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(af);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Nom",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Prenom",renderer, "text",PRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Email",renderer, "text",EMAIL,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" cin",renderer, "text",CIN,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Num",renderer, "text",NUM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date",renderer,"text",DATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (af),column);
	renderer = gtk_cell_renderer_text_new();
}
	store=gtk_list_store_new(6,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("personnevols.txt","r");
if(f==NULL)
{
return;
}
else
{
 f=fopen("personnevols.txt","a+");
	while(fscanf(f,"%s %s %s %s %s %s\n",Nom,Prenom,Email,cin,Num,Date)!=EOF)
	{
if(strcmp(cin,ID)==0)
{	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,NOM,Nom,PRENOM,Prenom,EMAIL,Email,CIN,cin,NUM,Num,DATE,Date,-1);
	}}
	fclose(f);}
	gtk_tree_view_set_model(GTK_TREE_VIEW(af), GTK_TREE_MODEL(store));
	g_object_unref(store);
	

}
int ver_personnevols(char ID[])
{personnevols v;
FILE *f;
int test = 0 ; 
f=fopen("personnevols.txt","r");
if(f!=NULL) { 
while(fscanf(f,"%s %s %s %s %s %s\n",v.Nom,v.Prenom,v.Email,v.cin,v.Num,v.Date)!=EOF) 
{ 
if((strcmp(v.cin,ID)==0))
test=1 ;
 } }
fclose(f);
 
return test;
}
