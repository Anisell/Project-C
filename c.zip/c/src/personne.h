#include <gtk/gtk.h>
typedef struct
{
char Nom[20];
char Prenom[20];
char Email[50];
char cin[50];
char Num[20];
char Date[30];

}personne;

void ajouter_personne(personne p);
void afficher_personne(GtkWidget *af);
int verifier_id(char ID[20]);
void modifier_personne(personne p);
void personne_vols(personne v);
void afficher_personne_vols(GtkWidget *vols);
void personne_promo(personne r);
void afficher_personne_promo(GtkWidget *promo);
void personne_Gastronomie(personne g);
void afficher_personne_Gastronomie(GtkWidget *Gastronomie);
void personne_bienetre(personne b);
void afficher_personne_bienetre(GtkWidget *bienetre);
void personne_circuit(personne c);
void afficher_personne_circuit(GtkWidget *circuit);
void supprimer_hotel(char refer[]);
void supprimer_vool(char vool[]);
void supprimer_promo(char refer[]);
void supprimer_gastronomie(char refer[]);
int verifier_vool(char vool[20]);
int verifier_pr(char pr[20]);
int verifier_gastro(char gastro[20]);
