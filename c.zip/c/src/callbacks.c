#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "offre.h"
#include "personne.h"
#include "personreserver.h"
#include "rechercher.h"


void
on_button43_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
hotel h;
GtkWidget *nomm, *prenom, *email ,*cin ,*num, *jour,*mois,*Annee,*nombre;
GtkWidget *window1;
GtkWidget *output300;
window1=lookup_widget(objet_graphique,"Reserveraaa");
output300=lookup_widget(objet_graphique,"label664");
nomm=lookup_widget(objet_graphique,"Nomres");
prenom=lookup_widget(objet_graphique,"Prenom");
email=lookup_widget(objet_graphique,"Email");
cin=lookup_widget(objet_graphique,"cin");
num=lookup_widget(objet_graphique,"Num");
jour=lookup_widget(objet_graphique,"Jour");
mois=lookup_widget(objet_graphique,"Mois");
Annee=lookup_widget(objet_graphique,"annee");
nombre=lookup_widget(objet_graphique,"nombre");
strcpy(h.Nom,gtk_entry_get_text(GTK_ENTRY(nomm)));
strcpy(h.Prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(h.Email,gtk_entry_get_text(GTK_ENTRY(email)));
strcpy(h.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(h.Num,gtk_entry_get_text(GTK_ENTRY(num)));

h.dt_nai.Jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
h.dt_nai.Mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
h.dt_nai.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Annee));
h.nb=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (nombre));

if((strcmp(h.Nom,"")==0) || (strcmp(h.Prenom,"")==0) || (strcmp(h.Email,"")==0) || (strcmp(h.cin,"")==0) || (strcmp(h.Num,"")==0))
gtk_label_set_text(GTK_LABEL(output300),"Missing informations");
else
gtk_label_set_text(GTK_LABEL(output300),"Veuillez confirmer votre reservation dans notre agence");
ajouter_hotelperson(h);
}


void
on_button44_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *reserver, *Interface_Client;


reserver=lookup_widget(objet_graphique,"Reserveraaa");
Interface_Client=create_Interface_Client();
gtk_widget_show(Interface_Client);
gtk_widget_hide(reserver);
}


void
on_button45_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *reserver, *Interface_Client;


reserver=lookup_widget(objet_graphique,"Reserveraaa");
Interface_Client=create_Interface_Client();
gtk_widget_show(Interface_Client);
gtk_widget_hide(reserver);
}


void
on_button159_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Offre_agents_nterface1, *Valider_button_Reclamation;


Offre_agents_nterface1=lookup_widget(objet_graphique,"Offre_agents_nterface1");
gtk_widget_destroy(Valider_button_Reclamation);
Offre_agents_nterface1=create_Offre_agents_nterface1();
gtk_widget_show(Offre_agents_nterface1);
gtk_widget_hide(Valider_button_Reclamation);
}


void
on_button160_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button161_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button162_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button164_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button165_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttom163_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button0_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;


window1=lookup_widget(objet_graphique,"Offre_agents_nterface1");

window2=create_Ajouter_Modifier_supprimer_offre();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_button1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;


window1=lookup_widget(objet_graphique,"Offre_agents_nterface1");
window2=create_Ajouter_Modifier_Supprimer_Personne();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_button2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
{
GtkWidget *Ajouter_Modifier_vols, *Offre_agents_nterface1;


Ajouter_Modifier_vols=lookup_widget(objet_graphique,"Offre_agents_nterface1");
gtk_widget_destroy(Offre_agents_nterface1);
Ajouter_Modifier_vols=lookup_widget(objet_graphique,"Ajouter_Modifier_vols");
Ajouter_Modifier_vols=create_Ajouter_Modifier_vols();
gtk_widget_show(Ajouter_Modifier_vols);
gtk_widget_hide(Offre_agents_nterface1);
}
}


void
on_button3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;


window1=lookup_widget(objet_graphique,"Offre_agents_nterface1");

window2=create_Ajouter_Modifier_Supprimer_Personne_Vols();
gtk_widget_show(window2);
gtk_widget_hide(window1);

}


void
on_button5_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;


window1=lookup_widget(objet_graphique,"Offre_agents_nterface1");

window2=create_Ajouter_Modifier_Supprimer_Personne_promo();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_button4_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;


window1=lookup_widget(objet_graphique,"Offre_agents_nterface1");

window2=create_Ajouter_Modifier_promo();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_button6_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Ajouter_Modifier_Gastronomie, *Offre_agents_nterface1;


Offre_agents_nterface1=lookup_widget(objet_graphique,"Offre_agents_nterface1");
gtk_widget_destroy(Offre_agents_nterface1);
Ajouter_Modifier_Gastronomie=lookup_widget(objet_graphique,"Ajouter_Modifier_Gastronomie");
Ajouter_Modifier_Gastronomie=create_Ajouter_Modifier_Gastronomie();
gtk_widget_show(Ajouter_Modifier_Gastronomie);
gtk_widget_hide(Offre_agents_nterface1);
}


void
on_button7_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Ajouter_Modifier_Supprimer_Personne_Gastronomie, *Offre_agents_nterface1;


Offre_agents_nterface1=lookup_widget(objet_graphique,"Offre_agents_nterface1");
gtk_widget_destroy(Offre_agents_nterface1);
Ajouter_Modifier_Supprimer_Personne_Gastronomie=lookup_widget(objet_graphique,"Ajouter_Modifier_Supprimer_Personne_Gastronomie");
Ajouter_Modifier_Supprimer_Personne_Gastronomie=create_Ajouter_Modifier_Supprimer_Personne_Gastronomie();
gtk_widget_show(Ajouter_Modifier_Supprimer_Personne_Gastronomie);
}


void
on_button8_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Ajouter_Modifier_bienetre, *Offre_agents_nterface1;


Offre_agents_nterface1=lookup_widget(objet_graphique,"Offre_agents_nterface1");
gtk_widget_destroy(Offre_agents_nterface1);
Ajouter_Modifier_bienetre=lookup_widget(objet_graphique,"Ajouter_Modifier_bienetre");
Ajouter_Modifier_bienetre=create_Ajouter_Modifier_bienetre();
gtk_widget_show(Ajouter_Modifier_bienetre);
gtk_widget_hide(Offre_agents_nterface1);
}


void
on_button9_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Ajouter_Modifier_Supprimer_bienetre, *Offre_agents_nterface1;


Offre_agents_nterface1=lookup_widget(objet_graphique,"Offre_agents_nterface1");
gtk_widget_destroy(Offre_agents_nterface1);
Ajouter_Modifier_Supprimer_bienetre=lookup_widget(objet_graphique,"Ajouter_Modifier_Supprimer_bienetre");
Ajouter_Modifier_Supprimer_bienetre=create_Ajouter_Modifier_Supprimer_bienetre();
gtk_widget_show(Ajouter_Modifier_Supprimer_bienetre);
}


void
on_button11_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_button10_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Ajouter_Modifier_Supprimer_Circuit, *Offre_agents_nterface1;


Offre_agents_nterface1=lookup_widget(objet_graphique,"Offre_agents_nterface1");
gtk_widget_destroy(Offre_agents_nterface1);
Ajouter_Modifier_Supprimer_Circuit=lookup_widget(objet_graphique,"Ajouter_Modifier_Supprimer_Circuit");
Ajouter_Modifier_Supprimer_Circuit=create_Ajouter_Modifier_Supprimer_circuit();
gtk_widget_show(Ajouter_Modifier_Supprimer_Circuit);
}


void
on_button12_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Valider_buttom_Reclamation, *Offre_agents_nterface1;


Offre_agents_nterface1=lookup_widget(objet_graphique,"Offre_agents_nterface1");
gtk_widget_destroy(Offre_agents_nterface1);
Valider_buttom_Reclamation=lookup_widget(objet_graphique,"Valider_buttom_Reclamation");
Valider_buttom_Reclamation=create_Valider_buttom_Reclamation();
gtk_widget_show(Valider_buttom_Reclamation);
}


void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button15_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Reserver, *Interface_Client;


Interface_Client=lookup_widget(objet_graphique,"Interface_Client");
gtk_widget_destroy(Interface_Client);
Reserver=lookup_widget(objet_graphique,"Reserveraaa");
Reserver=create_Reserveraaa();
gtk_widget_show(Reserver);
}


void
on_button16_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Reserver, *Interface_Client;


Interface_Client=lookup_widget(objet_graphique,"Interface_Client");
gtk_widget_destroy(Interface_Client);
Reserver=lookup_widget(objet_graphique,"Reserveraaa");
Reserver=create_Reserveraaa();
gtk_widget_show(Reserver);
}


void
on_button17_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Reserver, *Interface_Client;


Interface_Client=lookup_widget(objet_graphique,"Interface_Client");
gtk_widget_destroy(Interface_Client);
Reserver=lookup_widget(objet_graphique,"Reserveraaa");
Reserver=create_Reserveraaa();
gtk_widget_show(Reserver);
}


void
on_button18_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;


window1=lookup_widget(objet_graphique,"Interface_Client");
window2=create_reserverclientvool();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_button19_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;


window1=lookup_widget(objet_graphique,"Interface_Client");
window2=create_reserverclientvool();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_button20_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;


window1=lookup_widget(objet_graphique,"Interface_Client");
window2=create_reserverclientvool();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_button147_clicked                   (GtkWidget        *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;


window1=lookup_widget(objet_graphique,"Interface_Client");
window2=create_reserverclientpromo();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_button148_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;


window1=lookup_widget(objet_graphique,"Interface_Client");
window2=create_reserverclientpromo();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_button149_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;


window1=lookup_widget(objet_graphique,"Interface_Client");
window2=create_reserverclientpromo();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_button21_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;


window1=lookup_widget(objet_graphique,"Interface_Client");
window2=create_reserverclientgastronomie();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_button22_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;


window1=lookup_widget(objet_graphique,"Interface_Client");
window2=create_reserverclientgastronomie();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_button23_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;


window1=lookup_widget(objet_graphique,"Interface_Client");
window2=create_reserverclientgastronomie();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_button24_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;


window1=lookup_widget(objet_graphique,"Interface_Client");
window2=create_reserverclientbienetre();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_button25_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;


window1=lookup_widget(objet_graphique,"Interface_Client");
window2=create_reserverclientbienetre();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_button26_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;


window1=lookup_widget(objet_graphique,"Interface_Client");
window2=create_reserverclientbienetre();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_button27_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;


window1=lookup_widget(objet_graphique,"Interface_Client");
window2=create_reserverclientcircuit();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_button28_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;


window1=lookup_widget(objet_graphique,"Interface_Client");
window2=create_reserverclientcircuit();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_button29_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;


window1=lookup_widget(objet_graphique,"Interface_Client");
window2=create_reserverclientcircuit();
gtk_widget_show(window2);
gtk_widget_hide(window1);
}


void
on_button30_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button166_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button176_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button177_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button34_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
personne p;
GtkWidget *Nom, *Prenom, *Email ,*Cin,*Num,*Date;
GtkWidget *window1;
window1=lookup_widget(objet_graphique,"Ajouter_Modifier_Supprimer_Personne");
Nom=lookup_widget(objet_graphique,"Nom");
Prenom=lookup_widget(objet_graphique,"Prenom");
Email=lookup_widget(objet_graphique,"Email");
Cin=lookup_widget(objet_graphique,"cin");
Num=lookup_widget(objet_graphique,"Num");
Date=lookup_widget(objet_graphique,"Date");
strcpy(p.Nom,gtk_entry_get_text(GTK_ENTRY(Nom)));
strcpy(p.Prenom,gtk_entry_get_text(GTK_ENTRY(Prenom)));
strcpy(p.Email,gtk_entry_get_text(GTK_ENTRY(Email)));
strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(Cin)));
strcpy(p.Num,gtk_entry_get_text(GTK_ENTRY(Num)));
strcpy(p.Date,gtk_entry_get_text(GTK_ENTRY(Date)));
ajouter_personne(p);
}


void
on_button35_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char id[20];
int test;
personne p;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7;
GtkWidget *window1,*window2;
GtkWidget *output;
window2=create_modifier_personne();
input1=lookup_widget(objet_graphique,"entry24");
input2=lookup_widget(window2,"modifiernom");
input3=lookup_widget(window2,"modifierprenom");
input4=lookup_widget(window2,"modifieremail");
input5=lookup_widget(window2,"modifiercin");
input6=lookup_widget(window2,"modifiernum");
input7=lookup_widget(window2,"modifierdate");

output= lookup_widget(objet_graphique,"label441");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(input1)));
if (verifier_id(id)==0) 
gtk_label_set_text(GTK_LABEL(output),"Personne n'existe pas");
else
{
FILE *f2;
f2=fopen("personne.txt","r"); 
if (f2!=NULL)
{while (fscanf(f2,"%s %s %s %s %s %s\n",p.Nom,p.Prenom,p.Email,p.cin,p.Num,p.Date)!=EOF)
{if (strcmp(p.cin,id)==0) 
{ gtk_widget_show(window2);
gtk_entry_set_text(GTK_ENTRY(input2),p.Nom) ;
gtk_entry_set_text(GTK_ENTRY(input3),p.Prenom) ;
gtk_entry_set_text(GTK_ENTRY(input4),p.Email) ;
gtk_entry_set_text(GTK_ENTRY(input5),p.cin) ;
gtk_entry_set_text(GTK_ENTRY(input6),p.Num) ;
gtk_entry_set_text(GTK_ENTRY(input7),p.Date) ;
gtk_widget_hide(window1);
break ;}}
}
fclose(f2);
}}






void
on_button36_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview22;

treeview22=lookup_widget(objet_graphique,"treeview22");
afficher_personne(treeview22);
}


void
on_button37_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)


{GtkWidget *input100;
GtkWidget *output100;
personne b;
char refer[20];
input100=lookup_widget(objet_graphique,"entry25");
output100=lookup_widget(objet_graphique,"label612");
strcpy(refer,gtk_entry_get_text(GTK_ENTRY(input100)));
if(verifier_id(refer)==0)
gtk_label_set_text(GTK_LABEL(output100),"Personne inexistante");
else
{
supprimer_hotel(refer);
gtk_label_set_text(GTK_LABEL(output100),"Personne supprimé");
}}






void
on_button38_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_button39_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;


window1=lookup_widget(objet_graphique,"Ajouter_Modifier_supprimer_offre");
gtk_widget_destroy(window1);
window2=create_Modifier();
gtk_widget_show(window2);
}


void
on_button40_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview23;

treeview23=lookup_widget(objet_graphique,"treeview23");
afficher_offres(treeview23);
}


void
on_button41_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
{GtkWidget *input300;
GtkWidget *output300;
personne v;
char hot[20];
input300=lookup_widget(objet_graphique,"entry34");
output300=lookup_widget(objet_graphique,"label613");
strcpy(hot,gtk_entry_get_text(GTK_ENTRY(input300)));
if(verifier_hot(hot)==0)
gtk_label_set_text(GTK_LABEL(output300),"offre inexistante");
else
{
supprimer_hot(hot);
gtk_label_set_text(GTK_LABEL(output300),"offre supprimé");
}
}
}


void
on_button42_clicked                    (GtkButton       *button,
                                        gpointer         user_data)

{

}


void
on_button46_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_buttonajout_personne_vols_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
personne v;
GtkWidget *Nom, *Prenom, *Email ,*Cin,*Num,*Date;
GtkWidget *window1;
window1=lookup_widget(objet_graphique,"Ajouter_Modifier_Supprimer_Personne_Vols");
Nom=lookup_widget(objet_graphique,"Nom");
Prenom=lookup_widget(objet_graphique,"Prenom");
Email=lookup_widget(objet_graphique,"Email");
Cin=lookup_widget(objet_graphique,"cin");
Num=lookup_widget(objet_graphique,"Num");
Date=lookup_widget(objet_graphique,"Date");
strcpy(v.Nom,gtk_entry_get_text(GTK_ENTRY(Nom)));
strcpy(v.Prenom,gtk_entry_get_text(GTK_ENTRY(Prenom)));
strcpy(v.Email,gtk_entry_get_text(GTK_ENTRY(Email)));
strcpy(v.cin,gtk_entry_get_text(GTK_ENTRY(Cin)));
strcpy(v.Num,gtk_entry_get_text(GTK_ENTRY(Num)));
strcpy(v.Date,gtk_entry_get_text(GTK_ENTRY(Date)));
personne_vols(v);
}


void
on_buttonafficher_personne_vols_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview25;

treeview25=lookup_widget(objet_graphique,"treeview25");
afficher_personne_vols(treeview25);
}


void
on_buttonsupprimer_personne_vols_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
{GtkWidget *input300;
GtkWidget *output300;
personne v;
char vool[20];
input300=lookup_widget(objet_graphique,"entry50");
output300=lookup_widget(objet_graphique,"label611");
strcpy(vool,gtk_entry_get_text(GTK_ENTRY(input300)));
if(verifier_vool(vool)==0)
gtk_label_set_text(GTK_LABEL(output300),"Personne inexistante");
else
{
supprimer_vool(vool);
gtk_label_set_text(GTK_LABEL(output300),"Personne supprimé");
}}
}


void
on_buttonmodifier_personne_promo_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonafficher_personne_promo_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview27;

treeview27=lookup_widget(objet_graphique,"treeview27");
afficher_personne_promo(treeview27);
}


void
on_buttonsupprimer_personne_promo_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
{GtkWidget *input200;
GtkWidget *output200;
personne r;
char pr[20];
input200=lookup_widget(objet_graphique,"entry66");
output200=lookup_widget(objet_graphique,"label492");
strcpy(pr,gtk_entry_get_text(GTK_ENTRY(input200)));
if(verifier_pr(pr)==0)
gtk_label_set_text(GTK_LABEL(output200),"Personne inexistante");
else
{
supprimer_pr(pr);
gtk_label_set_text(GTK_LABEL(output200),"Personne supprimé");
}}
}


void
on_buttonajouter_personne_gastronomie_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
personne g;
GtkWidget *Nom, *Prenom, *Email ,*Cin,*Num,*Date;
GtkWidget *Ajouter_Modifier_Supprimer_Personne_Gastronomie;
Ajouter_Modifier_Supprimer_Personne_Gastronomie=lookup_widget(objet_graphique,"Ajouter_Modifier_Supprimer_Personne_Gastronomie");
Nom=lookup_widget(objet_graphique,"Nom");
Prenom=lookup_widget(objet_graphique,"Prenom");
Email=lookup_widget(objet_graphique,"Email");
Cin=lookup_widget(objet_graphique,"cin");
Num=lookup_widget(objet_graphique,"Num");
Date=lookup_widget(objet_graphique,"Date");
strcpy(g.Nom,gtk_entry_get_text(GTK_ENTRY(Nom)));
strcpy(g.Prenom,gtk_entry_get_text(GTK_ENTRY(Prenom)));
strcpy(g.Email,gtk_entry_get_text(GTK_ENTRY(Email)));
strcpy(g.cin,gtk_entry_get_text(GTK_ENTRY(Cin)));
strcpy(g.Num,gtk_entry_get_text(GTK_ENTRY(Num)));
strcpy(g.Date,gtk_entry_get_text(GTK_ENTRY(Date)));
personne_Gastronomie(g);
}


void
on_buttonmodifier_personne_gastronomie_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonafficher_personne_gastronomie_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview26;

treeview26=lookup_widget(objet_graphique,"treeview26");
afficher_personne_Gastronomie(treeview26);
}


void
on_buttonsupprimer_personne_gastronomie_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
{GtkWidget *input100;
GtkWidget *output100;
personne b;
char gastro[20];
input100=lookup_widget(objet_graphique,"entry58");
output100=lookup_widget(objet_graphique,"label475");
strcpy(gastro,gtk_entry_get_text(GTK_ENTRY(input100)));
if(verifier_gastro(gastro)==0)
gtk_label_set_text(GTK_LABEL(output100),"Personne inexistante");
else
{
supprimer_gastro(gastro);
gtk_label_set_text(GTK_LABEL(output100),"Personne supprimé");
}}
}


void
on_buttonajouter_bienetre_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
personne b;
GtkWidget *Nom, *Prenom, *Email ,*Cin,*Num,*Date;
GtkWidget *Ajouter_Modifier_Supprimer_bienetre;
Ajouter_Modifier_Supprimer_bienetre=lookup_widget(objet_graphique,"Ajouter_Modifier_Supprimer_bienetre");
Nom=lookup_widget(objet_graphique,"Nom");
Prenom=lookup_widget(objet_graphique,"Prenom");
Email=lookup_widget(objet_graphique,"Email");
Cin=lookup_widget(objet_graphique,"cin");
Num=lookup_widget(objet_graphique,"Num");
Date=lookup_widget(objet_graphique,"Date");
strcpy(b.Nom,gtk_entry_get_text(GTK_ENTRY(Nom)));
strcpy(b.Prenom,gtk_entry_get_text(GTK_ENTRY(Prenom)));
strcpy(b.Email,gtk_entry_get_text(GTK_ENTRY(Email)));
strcpy(b.cin,gtk_entry_get_text(GTK_ENTRY(Cin)));
strcpy(b.Num,gtk_entry_get_text(GTK_ENTRY(Num)));
strcpy(b.Date,gtk_entry_get_text(GTK_ENTRY(Date)));
personne_bienetre(b);
}


void
on_buttonmodifier_bienetre_clicked     (GtkButton        *button,
                                        gpointer         user_data)
{

}


void
on_buttonafficher_personne_bienetre_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview28;

treeview28=lookup_widget(objet_graphique,"treeview28");
afficher_personne_bienetre(treeview28);
}


void
on_buttonsupprimer_personne_bienetre_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonajouter_escapade_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
personne c;
GtkWidget *Nom, *Prenom, *Email ,*Cin,*Num,*Date;
GtkWidget *Ajouter_Modifier_Supprimer_circuit;
Ajouter_Modifier_Supprimer_circuit=lookup_widget(objet_graphique,"Ajouter_Modifier_Supprimer_circuit");
Nom=lookup_widget(objet_graphique,"Nom");
Prenom=lookup_widget(objet_graphique,"Prenom");
Email=lookup_widget(objet_graphique,"Email");
Cin=lookup_widget(objet_graphique,"cin");
Num=lookup_widget(objet_graphique,"Num");
Date=lookup_widget(objet_graphique,"Date");
strcpy(c.Nom,gtk_entry_get_text(GTK_ENTRY(Nom)));
strcpy(c.Prenom,gtk_entry_get_text(GTK_ENTRY(Prenom)));
strcpy(c.Email,gtk_entry_get_text(GTK_ENTRY(Email)));
strcpy(c.cin,gtk_entry_get_text(GTK_ENTRY(Cin)));
strcpy(c.Num,gtk_entry_get_text(GTK_ENTRY(Num)));
strcpy(c.Date,gtk_entry_get_text(GTK_ENTRY(Date)));
personne_circuit(c);
}


void
on_buttonmodifier_personne_supprimer_escapade_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonafficher_personne_circuit_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview29;

treeview29=lookup_widget(objet_graphique,"treeview29");
afficher_personne_circuit(treeview29);
}


void
on_buttonsupprimer_personne_circuit_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonmodifier_personne_vols_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}



void
on_buttonajouter_Modifier_Supprimer_personne_promo_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonajouter_Modifier_Supprimer_Personne_promo_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ajouter_Modifier_Supprimer_Personne_promo_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_promopersonne_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
personne r;
GtkWidget *Nom, *Prenom, *Email ,*Cin,*Num,*Date;
GtkWidget *Ajouter_Modifier_Supprimer_Personne_promo;
Ajouter_Modifier_Supprimer_Personne_promo=lookup_widget(objet_graphique,"Ajouter_Modifier_Supprimer_Personne_promo");
Nom=lookup_widget(objet_graphique,"Nom");
Prenom=lookup_widget(objet_graphique,"Prenom");
Email=lookup_widget(objet_graphique,"Email");
Cin=lookup_widget(objet_graphique,"cin");
Num=lookup_widget(objet_graphique,"Num");
Date=lookup_widget(objet_graphique,"Date");
strcpy(r.Nom,gtk_entry_get_text(GTK_ENTRY(Nom)));
strcpy(r.Prenom,gtk_entry_get_text(GTK_ENTRY(Prenom)));
strcpy(r.Email,gtk_entry_get_text(GTK_ENTRY(Email)));
strcpy(r.cin,gtk_entry_get_text(GTK_ENTRY(Cin)));
strcpy(r.Num,gtk_entry_get_text(GTK_ENTRY(Num)));
strcpy(r.Date,gtk_entry_get_text(GTK_ENTRY(Date)));
personne_promo(r);
}


void
on_buttonAjouter_offre_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
offre o;
GtkWidget *Destination, *Prix, *Pays ,*OffreID,*Date;
GtkWidget *Ajouter_Modifier_supprimer_offre;
Ajouter_Modifier_supprimer_offre=lookup_widget(objet_graphique,"Ajouter_Modifier_supprimer_offre");
Destination=lookup_widget(objet_graphique,"Destination200");
Prix=lookup_widget(objet_graphique,"Prix200");
Pays=lookup_widget(objet_graphique,"Pays200");
OffreID=lookup_widget(objet_graphique,"OffreID200");
Date=lookup_widget(objet_graphique,"Date200");
strcpy(o.Destination,gtk_entry_get_text(GTK_ENTRY(Destination)));
strcpy(o.Prix,gtk_entry_get_text(GTK_ENTRY(Prix)));
strcpy(o.Pays,gtk_entry_get_text(GTK_ENTRY(Pays)));
strcpy(o.OffreID,gtk_entry_get_text(GTK_ENTRY(OffreID)));
strcpy(o.Date,gtk_entry_get_text(GTK_ENTRY(Date)));
ajouter_offres(o);
}


void
on_buttonAjouter_vols_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
offre v;
GtkWidget *Destination, *Prix, *Pays ,*OffreID,*Date;
GtkWidget *Ajouter_Modifier_vols;
Ajouter_Modifier_vols=lookup_widget(objet_graphique,"Ajouter_Modifier_vols");
Destination=lookup_widget(objet_graphique,"Destination300");
Prix=lookup_widget(objet_graphique,"Prix300");
Pays=lookup_widget(objet_graphique,"Pays300");
OffreID=lookup_widget(objet_graphique,"OffreID300");
Date=lookup_widget(objet_graphique,"Date300");
strcpy(v.Destination,gtk_entry_get_text(GTK_ENTRY(Destination)));
strcpy(v.Prix,gtk_entry_get_text(GTK_ENTRY(Prix)));
strcpy(v.Pays,gtk_entry_get_text(GTK_ENTRY(Pays)));
strcpy(v.OffreID,gtk_entry_get_text(GTK_ENTRY(OffreID)));
strcpy(v.Date,gtk_entry_get_text(GTK_ENTRY(Date)));
ajouter_vols(v);
}



void
on_buttonAfficher_vols_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview30;

treeview30=lookup_widget(objet_graphique,"treeview30");
afficher_vols(treeview30);
}


void
on_buttonSupprimer_vols_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
{GtkWidget *input300;
GtkWidget *output300;
char vol[20];
input300=lookup_widget(objet_graphique,"entry89");
output300=lookup_widget(objet_graphique,"label614");
strcpy(vol,gtk_entry_get_text(GTK_ENTRY(input300)));
if(verifier_vol(vol)==0)
gtk_label_set_text(GTK_LABEL(output300),"offre inexistante");
else
{
supprimer_vol(vol);
gtk_label_set_text(GTK_LABEL(output300),"offre supprimé");
}}}


void
on_buttonAjouter_promo_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
offre e;
GtkWidget *Destination, *Prix, *Pays ,*OffreID,*Date;
GtkWidget *Ajouter_Modifier_promo;
Ajouter_Modifier_promo=lookup_widget(objet_graphique,"Ajouter_Modifier_promo");
Destination=lookup_widget(objet_graphique,"Destination400");
Prix=lookup_widget(objet_graphique,"Prix400");
Pays=lookup_widget(objet_graphique,"Pays400");
OffreID=lookup_widget(objet_graphique,"OffreID400");
Date=lookup_widget(objet_graphique,"Date400");
strcpy(e.Destination,gtk_entry_get_text(GTK_ENTRY(Destination)));
strcpy(e.Prix,gtk_entry_get_text(GTK_ENTRY(Prix)));
strcpy(e.Pays,gtk_entry_get_text(GTK_ENTRY(Pays)));
strcpy(e.OffreID,gtk_entry_get_text(GTK_ENTRY(OffreID)));
strcpy(e.Date,gtk_entry_get_text(GTK_ENTRY(Date)));
ajouter_enfant(e);
}


void
on_buttonModifier_promo_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonAfficher_promo_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview1;

treeview1=lookup_widget(objet_graphique,"treeview31");
afficher_enfants(treeview1);
}


void
on_buttonSupprimer_promo_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonAJouter_Gastronomie_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
offre g;
GtkWidget *Destination, *Prix, *Pays ,*OffreID,*Date;
GtkWidget *Ajouter_Modifier_promo;
Ajouter_Modifier_promo=lookup_widget(objet_graphique,"Ajouter_Modifier_promo");
Destination=lookup_widget(objet_graphique,"Destination500");
Prix=lookup_widget(objet_graphique,"Prix500");
Pays=lookup_widget(objet_graphique,"Pays500");
OffreID=lookup_widget(objet_graphique,"OffreID500");
Date=lookup_widget(objet_graphique,"Date500");
strcpy(g.Destination,gtk_entry_get_text(GTK_ENTRY(Destination)));
strcpy(g.Prix,gtk_entry_get_text(GTK_ENTRY(Prix)));
strcpy(g.Pays,gtk_entry_get_text(GTK_ENTRY(Pays)));
strcpy(g.OffreID,gtk_entry_get_text(GTK_ENTRY(OffreID)));
strcpy(g.Date,gtk_entry_get_text(GTK_ENTRY(Date)));
ajouter_gastronomie(g);
}


void
on_buttonModifier_Gastronomie_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonAfficher_Gastronomie_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview251;

treeview251=lookup_widget(objet_graphique,"treeview32");
afficher_gastronomies(treeview251);
}


void
on_buttonSupprimer_Gastronomie_clicked (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
{GtkWidget *input300;
GtkWidget *output300;
char gastr[20];
input300=lookup_widget(objet_graphique,"entry103");
output300=lookup_widget(objet_graphique,"label615");
strcpy(gastr,gtk_entry_get_text(GTK_ENTRY(input300)));
if(verifier_gastronomi(gastr)==0)
gtk_label_set_text(GTK_LABEL(output300),"offre inexistante");
else
{
supprimer_gastr(gastr);
gtk_label_set_text(GTK_LABEL(output300),"offre supprimé");
}
}}

void
on_buttonAjouter_bienetre_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
offre b;
GtkWidget *Destination, *Prix, *Pays ,*OffreID,*Date;
GtkWidget *Ajouter_Modifier_promo;
Ajouter_Modifier_promo=lookup_widget(objet_graphique,"Ajouter_Modifier_promo");
Destination=lookup_widget(objet_graphique,"Destination600");
Prix=lookup_widget(objet_graphique,"Prix600");
Pays=lookup_widget(objet_graphique,"Pays600");
OffreID=lookup_widget(objet_graphique,"OffreID600");
Date=lookup_widget(objet_graphique,"Date600");
strcpy(b.Destination,gtk_entry_get_text(GTK_ENTRY(Destination)));
strcpy(b.Prix,gtk_entry_get_text(GTK_ENTRY(Prix)));
strcpy(b.Pays,gtk_entry_get_text(GTK_ENTRY(Pays)));
strcpy(b.OffreID,gtk_entry_get_text(GTK_ENTRY(OffreID)));
strcpy(b.Date,gtk_entry_get_text(GTK_ENTRY(Date)));
ajouter_bienetre(b);
}


void
on_buttonModifier_bienetre_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonAfficher_bienetre_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview253;

treeview253=lookup_widget(objet_graphique,"treeview33");
afficher_bienetres(treeview253);
}


void
on_buttonSupprimer_bienetre_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
{GtkWidget *input300;
GtkWidget *output300;
char bien[20];
input300=lookup_widget(objet_graphique,"entry110");
output300=lookup_widget(objet_graphique,"label616");
strcpy(bien,gtk_entry_get_text(GTK_ENTRY(input300)));
if(verifier_bien(bien)==0)
gtk_label_set_text(GTK_LABEL(output300),"offre inexistante");
else
{
supprimer_bien(bien);
gtk_label_set_text(GTK_LABEL(output300),"offre supprimé");
}
}}

void
on_buttonAjouter_circuit_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
offre c;
GtkWidget *Destination, *Prix, *Pays ,*OffreID,*Date;
GtkWidget *Ajouter_Modifier_promo;
Ajouter_Modifier_promo=lookup_widget(objet_graphique,"Ajouter_Modifier_promo");
Destination=lookup_widget(objet_graphique,"Destination500");
Prix=lookup_widget(objet_graphique,"Prix500");
Pays=lookup_widget(objet_graphique,"Pays500");
OffreID=lookup_widget(objet_graphique,"OffreID500");
Date=lookup_widget(objet_graphique,"Date500");
strcpy(c.Destination,gtk_entry_get_text(GTK_ENTRY(Destination)));
strcpy(c.Prix,gtk_entry_get_text(GTK_ENTRY(Prix)));
strcpy(c.Pays,gtk_entry_get_text(GTK_ENTRY(Pays)));
strcpy(c.OffreID,gtk_entry_get_text(GTK_ENTRY(OffreID)));
strcpy(c.Date,gtk_entry_get_text(GTK_ENTRY(Date)));
ajouter_circuit(c);
}


void
on_buttonModifier_circuit_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonAfficher_circruit_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview254;

treeview254=lookup_widget(objet_graphique,"treeview34");
afficher_circuits(treeview254);
}


void
on_buttonSupprimer_circuit_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button179_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
personne v;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6;
GtkWidget *output;
input1=lookup_widget(objet_graphique,"modifiernom");
input2=lookup_widget(objet_graphique,"modifierprenom");
input3=lookup_widget(objet_graphique,"modifieremail");
input4=lookup_widget(objet_graphique,"modifiercin");
input5=lookup_widget(objet_graphique,"modifiernum");
input6=lookup_widget(objet_graphique,"modifierdate");
output=lookup_widget(objet_graphique,"label442");
strcpy(v.Nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(v.Prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(v.Email,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(v.cin,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(v.Num,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(v.Date,gtk_entry_get_text(GTK_ENTRY(input6)));

modifier_personne(v);
gtk_label_set_text(GTK_LABEL(output),"modifié avec succés") ;
}


void
on_valider_changer_personne_vols_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonModifier_hotel_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char id[20];
int test;
offre h;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7;
GtkWidget *window1,*window2;
GtkWidget *output;
window2=create_modifier_offre();
input1=lookup_widget(objet_graphique,"entry31");
input2=lookup_widget(window2,"destination500");
input3=lookup_widget(window2,"prix500");
input4=lookup_widget(window2,"pays500");
input5=lookup_widget(window2,"offreid500");
input6=lookup_widget(window2,"date500");

output= lookup_widget(objet_graphique,"label617");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(input1)));
if (verifier_hotel(id)==0)
gtk_label_set_text(GTK_LABEL(output),"offre n'existe pas");
else
{
FILE *f2;
f2=fopen("offre.txt","r"); 
if (f2!=NULL)
{while (fscanf(f2,"%s %s %s %s %s\n",h.Destination,h.Prix,h.Pays,h.OffreID,h.Date)!=EOF)
{if (strcmp(h.OffreID,id)==0) 
{ gtk_widget_show(window2);
gtk_entry_set_text(GTK_ENTRY(input2),h.Destination) ;
gtk_entry_set_text(GTK_ENTRY(input3),h.Prix) ;
gtk_entry_set_text(GTK_ENTRY(input4),h.Pays) ;
gtk_entry_set_text(GTK_ENTRY(input5),h.OffreID) ;
gtk_entry_set_text(GTK_ENTRY(input6),h.Date) ;
gtk_widget_hide(window1);
break ;}}
}
fclose(f2);
}}



void
on_modifier400_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
offre a;
GtkWidget *input1,*input2,*input3,*input4,*input5;
GtkWidget *output;
input1=lookup_widget(objet_graphique,"entry120");
input2=lookup_widget(objet_graphique,"entry118");
input3=lookup_widget(objet_graphique,"entry119");
input4=lookup_widget(objet_graphique,"entry121");
input5=lookup_widget(objet_graphique,"entry122");
output=lookup_widget(objet_graphique,"label618");
strcpy(a.Destination,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(a.Prix,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(a.Pays,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(a.OffreID,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(a.Date,gtk_entry_get_text(GTK_ENTRY(input5)));
modifier_offress(a);
gtk_label_set_text(GTK_LABEL(output),"modifié avec succés") ;
}



void
on_reserverclientvol_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
vol v;
GtkWidget *nomm, *prenom, *email ,*cin ,*num, *jour,*mois,*Annee,*nombre;
GtkWidget *window1;
GtkWidget *output300;
window1=lookup_widget(objet_graphique,"Reserverclientvool");
output300=lookup_widget(objet_graphique,"label671");
nomm=lookup_widget(objet_graphique,"nomvol");
prenom=lookup_widget(objet_graphique,"nomprenom");
email=lookup_widget(objet_graphique,"nomemail");
cin=lookup_widget(objet_graphique,"cinvol");
num=lookup_widget(objet_graphique,"numvol");
jour=lookup_widget(objet_graphique,"Jour1");
mois=lookup_widget(objet_graphique,"Mois1");
Annee=lookup_widget(objet_graphique,"annee1");
nombre=lookup_widget(objet_graphique,"nombre1");
strcpy(v.Nom,gtk_entry_get_text(GTK_ENTRY(nomm)));
strcpy(v.Prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(v.Email,gtk_entry_get_text(GTK_ENTRY(email)));
strcpy(v.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(v.Num,gtk_entry_get_text(GTK_ENTRY(num)));

v.dt_nai.Jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
v.dt_nai.Mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
v.dt_nai.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Annee));
v.nb=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (nombre));

if((strcmp(v.Nom,"")==0) || (strcmp(v.Prenom,"")==0) || (strcmp(v.Email,"")==0) || (strcmp(v.cin,"")==0) || (strcmp(v.Num,"")==0))
gtk_label_set_text(GTK_LABEL(output300),"Missing informations");
else
gtk_label_set_text(GTK_LABEL(output300),"Veuillez confirmer votre reservation dans notre agence");
ajouter_volperson(v);
}


void
on_reserverpromoclient_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
promo p;
GtkWidget *nomm, *prenom, *email ,*cin ,*num, *jour,*mois,*Annee,*nombre;
GtkWidget *window1;
GtkWidget *output300;
window1=lookup_widget(objet_graphique,"reserverclientpromo");
output300=lookup_widget(objet_graphique,"label666");
nomm=lookup_widget(objet_graphique,"nompromo");
prenom=lookup_widget(objet_graphique,"prenompromo");
email=lookup_widget(objet_graphique,"emailpromo");
cin=lookup_widget(objet_graphique,"cinpromo");
num=lookup_widget(objet_graphique,"numpromo");
jour=lookup_widget(objet_graphique,"Jourpromo");
mois=lookup_widget(objet_graphique,"Moispromo");
Annee=lookup_widget(objet_graphique,"anneepromo");
nombre=lookup_widget(objet_graphique,"nombrepromo");
strcpy(p.Nom,gtk_entry_get_text(GTK_ENTRY(nomm)));
strcpy(p.Prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(p.Email,gtk_entry_get_text(GTK_ENTRY(email)));
strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(p.Num,gtk_entry_get_text(GTK_ENTRY(num)));

p.dt_nai.Jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
p.dt_nai.Mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
p.dt_nai.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Annee));
p.nb=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (nombre));

if((strcmp(p.Nom,"")==0) || (strcmp(p.Prenom,"")==0) || (strcmp(p.Email,"")==0) || (strcmp(p.cin,"")==0) || (strcmp(p.Num,"")==0))
gtk_label_set_text(GTK_LABEL(output300),"Missing informations");
else
gtk_label_set_text(GTK_LABEL(output300),"veuillez confirmer votre reservation dans notre agence");
ajouter_promoperson(p);
}


void
on_reservergastronomie_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
gastro g;
GtkWidget *nomm, *prenom, *email ,*cin ,*num, *jour,*mois,*Annee,*nombre;
GtkWidget *window1;
GtkWidget *output300;
window1=lookup_widget(objet_graphique,"reserverclientgastronomie");
output300=lookup_widget(objet_graphique,"label667");
nomm=lookup_widget(objet_graphique,"nomgastro");
prenom=lookup_widget(objet_graphique,"prenomgastro");
email=lookup_widget(objet_graphique,"emailgastro");
cin=lookup_widget(objet_graphique,"cingastro");
num=lookup_widget(objet_graphique,"numgastro");
jour=lookup_widget(objet_graphique,"jourgastro");
mois=lookup_widget(objet_graphique,"moisgastro");
Annee=lookup_widget(objet_graphique,"anneegastro");
nombre=lookup_widget(objet_graphique,"nombregastro");
strcpy(g.Nom,gtk_entry_get_text(GTK_ENTRY(nomm)));
strcpy(g.Prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(g.Email,gtk_entry_get_text(GTK_ENTRY(email)));
strcpy(g.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(g.Num,gtk_entry_get_text(GTK_ENTRY(num)));

g.dt_nai.Jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
g.dt_nai.Mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
g.dt_nai.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Annee));
g.nb=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (nombre));

if((strcmp(g.Nom,"")==0) || (strcmp(g.Prenom,"")==0) || (strcmp(g.Email,"")==0) || (strcmp(g.cin,"")==0) || (strcmp(g.Num,"")==0))
gtk_label_set_text(GTK_LABEL(output300),"Missing informations");
else
gtk_label_set_text(GTK_LABEL(output300),"Vuillez confirmer votre reservation dans notre agence");
ajouter_gastroperson(g);
}


void
on_reserverclientcircuit_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
circuit c;
GtkWidget *nomm, *prenom, *email ,*cin ,*num, *jour,*mois,*Annee,*nombre;
GtkWidget *window1;
GtkWidget *output300;
window1=lookup_widget(objet_graphique,"reserverclientcircuit");
output300=lookup_widget(objet_graphique,"label675");
nomm=lookup_widget(objet_graphique,"nomcircuit");
prenom=lookup_widget(objet_graphique,"prenomcircuit");
email=lookup_widget(objet_graphique,"emailcircuit");
cin=lookup_widget(objet_graphique,"cincircuit");
num=lookup_widget(objet_graphique,"numcircuit");
jour=lookup_widget(objet_graphique,"jourcircuit");
mois=lookup_widget(objet_graphique,"moiscircuit");
Annee=lookup_widget(objet_graphique,"anneecircuit");
nombre=lookup_widget(objet_graphique,"nombrecircuit");
strcpy(c.Nom,gtk_entry_get_text(GTK_ENTRY(nomm)));
strcpy(c.Prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(c.Email,gtk_entry_get_text(GTK_ENTRY(email)));
strcpy(c.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(c.Num,gtk_entry_get_text(GTK_ENTRY(num)));

c.dt_nai.Jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
c.dt_nai.Mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
c.dt_nai.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Annee));
c.nb=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (nombre));

if((strcmp(c.Nom,"")==0) || (strcmp(c.Prenom,"")==0) || (strcmp(c.Email,"")==0) || (strcmp(c.cin,"")==0) || (strcmp(c.Num,"")==0))
gtk_label_set_text(GTK_LABEL(output300),"Missing informations");
else
gtk_label_set_text(GTK_LABEL(output300),"Vuillez confirmer votre reservation dans notre agence");
ajouter_circuitperson(c);
}


void
on_reserverclientbienetre_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
bienetre b;
GtkWidget *nomm, *prenom, *email ,*cin ,*num, *jour,*mois,*Annee,*nombre;
GtkWidget *window1;
GtkWidget *output300;
window1=lookup_widget(objet_graphique,"reserverclientbienetre");
output300=lookup_widget(objet_graphique,"label677");
nomm=lookup_widget(objet_graphique,"nombien");
prenom=lookup_widget(objet_graphique,"prenombien");
email=lookup_widget(objet_graphique,"emailbien");
cin=lookup_widget(objet_graphique,"cinbien");
num=lookup_widget(objet_graphique,"numbien");
jour=lookup_widget(objet_graphique,"jourbien");
mois=lookup_widget(objet_graphique,"moisbien");
Annee=lookup_widget(objet_graphique,"anneebien");
nombre=lookup_widget(objet_graphique,"nombrebien");
strcpy(b.Nom,gtk_entry_get_text(GTK_ENTRY(nomm)));
strcpy(b.Prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(b.Email,gtk_entry_get_text(GTK_ENTRY(email)));
strcpy(b.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(b.Num,gtk_entry_get_text(GTK_ENTRY(num)));

b.dt_nai.Jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
b.dt_nai.Mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
b.dt_nai.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Annee));
b.nb=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (nombre));

if((strcmp(b.Nom,"")==0) || (strcmp(b.Prenom,"")==0) || (strcmp(b.Email,"")==0) || (strcmp(b.cin,"")==0) || (strcmp(b.Num,"")==0))
gtk_label_set_text(GTK_LABEL(output300),"Missing informations");
else
gtk_label_set_text(GTK_LABEL(output300),"Vuillez confirmer votre reservation dans notre agence");
ajouter_bienetreperson(b);
}



void
on_quittergastro_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *reserver, *Interface_Client;


reserver=lookup_widget(objet_graphique,"reserverclientgastronomie");
Interface_Client=create_Interface_Client();
gtk_widget_show(Interface_Client);
gtk_widget_hide(reserver);
}


void
on_quittercircuit_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *reserver, *Interface_Client;


reserver=lookup_widget(objet_graphique,"reserverclientcircuit");
Interface_Client=create_Interface_Client();
gtk_widget_show(Interface_Client);
gtk_widget_hide(reserver);
}


void
on_quitterbienetre_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *reserver, *Interface_Client;


reserver=lookup_widget(objet_graphique,"reserverclientbienetre");
Interface_Client=create_Interface_Client();
gtk_widget_show(Interface_Client);
gtk_widget_hide(reserver);
}


void
on_quittervolss_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *reserver, *Interface_Client;


reserver=lookup_widget(objet_graphique,"reserverclientvool");
Interface_Client=create_Interface_Client();
gtk_widget_show(Interface_Client);
gtk_widget_hide(reserver);
}


void
on_quitterppromo_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *reserver, *Interface_Client;


reserver=lookup_widget(objet_graphique,"reserverclientpromo");
Interface_Client=create_Interface_Client();
gtk_widget_show(Interface_Client);
gtk_widget_hide(reserver);
}


void
on_precedentvol_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *reserver, *Interface_Client;


reserver=lookup_widget(objet_graphique,"reserverclientvool");
Interface_Client=create_Interface_Client();
gtk_widget_show(Interface_Client);
gtk_widget_hide(reserver);
}


void
on_precedentpromo_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *reserver, *Interface_Client;


reserver=lookup_widget(objet_graphique,"reserverclientpromo");
Interface_Client=create_Interface_Client();
gtk_widget_show(Interface_Client);
gtk_widget_hide(reserver);
}


void
on_precedentgastro_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *reserver, *Interface_Client;


reserver=lookup_widget(objet_graphique,"reserverclientgastronomie");
Interface_Client=create_Interface_Client();
gtk_widget_show(Interface_Client);
gtk_widget_hide(reserver);
}


void
on_precedentcircuit_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *reserver, *Interface_Client;


reserver=lookup_widget(objet_graphique,"reserverclientcircuit");
Interface_Client=create_Interface_Client();
gtk_widget_show(Interface_Client);
gtk_widget_hide(reserver);
}


void
on_precedentbienetre_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *reserver, *Interface_Client;


reserver=lookup_widget(objet_graphique,"reserverclientbienetre");
Interface_Client=create_Interface_Client();
gtk_widget_show(Interface_Client);
gtk_widget_hide(reserver);
}


void
on_treeview24_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{/*
	gchar *Destination;
	gchar *Prix;
	gchar *Pays;
	gchar *OffreID;
	gchar *Date;

GtkWidget *Window4;
GtkWidget *Window3;
GtkTreeIter iter;

Window4=lookup_widget(treeview,"window4");

GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&Destination,1,&Prix,2,&Pays,3,&OffreID,4,&Date,-1);}*/
}


void
on_treeview14_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_treeview19_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_treeview20_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_treeview17_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_treeview18_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_rechercherpersonnehotel_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
{GtkWidget *input1;
GtkWidget *window1;
GtkWidget *output;
GtkWidget *treeview;
char ID[20];
int test=0;
window1=lookup_widget(objet_graphique,"Ajouter_Modifier_Supprimer_Personne");
treeview=lookup_widget(objet_graphique,"treeview22");
input1=lookup_widget(objet_graphique,"rechercher");
output=lookup_widget(objet_graphique,"label678");
strcpy(ID, gtk_entry_get_text(GTK_ENTRY(input1)));

if(ver_personnehotel(ID)==0)
{gtk_label_set_text(GTK_LABEL(output),"personne indisponible");
afficher_personnehotel(treeview);}
else {
rechercher_personnehotel(treeview,ID);
}}


}


void
on_recherchervols_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
{GtkWidget *input1;
GtkWidget *window1;
GtkWidget *output;
GtkWidget *treeview;
char ID[20];
int test=0;
window1=lookup_widget(objet_graphique,"Ajouter_Modifier_Supprimer_Personne_Vols");
treeview=lookup_widget(objet_graphique,"treeview25");
input1=lookup_widget(objet_graphique,"recherchepersonnevols");
output=lookup_widget(objet_graphique,"label681");
strcpy(ID, gtk_entry_get_text(GTK_ENTRY(input1)));

if(ver_personnevols(ID)==0)
{gtk_label_set_text(GTK_LABEL(output),"personne indisponible");
afficher_personnevols(treeview);}
else {
rechercher_personnevols(treeview,ID);
}}
}

